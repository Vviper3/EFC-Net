# YOLOv5 🚀 by Ultralytics, GPL-3.0 license
"""
Common modules
"""

import json
import math
import platform
import warnings
from collections import OrderedDict, namedtuple
from copy import copy
from pathlib import Path
from typing import Optional

from mpmath.math2 import INF
from torch.nn import init, Softmax
import torch.nn.functional as F
import cv2
import numpy as np
import pandas as pd
import requests
import torch
import torch.nn as nn
import yaml
from PIL import Image
from torch.cuda import amp

from utils.datasets import exif_transpose, letterbox
from utils.general import (LOGGER, check_requirements, check_suffix, check_version, colorstr, increment_path,
                           make_divisible, non_max_suppression, scale_coords, xywh2xyxy, xyxy2xywh)
from utils.plots import Annotator, colors, save_one_box
from utils.torch_utils import copy_attr, time_sync

from torch.nn.modules.conv import _ConvNd
from torch.nn.modules.utils import _pair

# def autopad(k, p=None):  # kernel, padding
#     # Pad to 'same'
#     if p is None:
#         p = k // 2 if isinstance(k, int) else [x // 2 for x in k]  # auto-pad
#     return p

def autopad(k, p=None, d=1):  # kernel, padding, dilation
    # Pad to 'same' shape outputs
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]  # actual kernel-size
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]  # auto-pad
    return p



class Conv(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
        # self.act = nn.LeakyReLU(0.1) if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
        # self.act = nn.Mish() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

    def forward_fuse(self, x):
        return self.act(self.conv(x))

class RepConve(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        self.conv1 = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.conv2 = nn.Conv2d(c1, c2, 1, s, autopad(1, p), groups=g, bias=False)
        # self.partial_conv1x3 = nn.Conv2d(c1, c2, (1, 3), 1, (0, 1), bias=False)
        # self.partial_conv3x1 = nn.Conv2d(c1, c2, (3, 1), 1, (1, 0), bias=False)
        self.bn = nn.BatchNorm2d(c2)
        # self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
        self.act = nn.LeakyReLU(0.1) if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
        # self.act = nn.Mish() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
    def forward(self, x):
        return self.act(self.bn(self.conv1(x)+self.conv2(x)))

    def forward_fuse(self, x):
        return self.act(self.conv1(x)+self.conv2(x))

# class Convl(nn.Module):
#     # Standard convolution
#     def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
#         super().__init__()
#         self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
#         self.bn = nn.BatchNorm2d(c2)
#         # self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
#         # self.act = nn.LeakyReLU(0.1) if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
#         self.act = nn.Mish() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
#     def forward(self, x):
#         return self.act(self.bn(self.conv(x)))
#
#     def forward_fuse(self, x):
#         return self.act(self.conv(x))

class Convl(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        # self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
        # self.act = nn.LeakyReLU(0.1) if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
        self.act = nn.Mish() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

    def forward_fuse(self, x):
        return self.act(self.conv(x))


class Conv123(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        self.conv1 = nn.Conv2d(c1, c2, (1,3), s, (0,1), groups=g, bias=False)
        self.conv2 = nn.Conv2d(c1, c2, (3,1), s, (1,0), groups=g, bias=False)
        self.conv3 = nn.Conv2d(c1, c2, 3, s, autopad(3, p), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
    def forward(self, x):
        return self.act((self.bn(self.conv1(x)) + self.bn(self.conv2(x)) + self.bn(self.conv3(x)))/3)

    def forward_fuse(self, x):
        # return self.act(self.conv(x))
        return self.act((self.bn(self.conv1(x)) + self.bn(self.conv2(x)) + self.bn(self.conv3(x)))/3)

class Convrep(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        self.conv1 = nn.Conv2d(c1, c2, 1, s, autopad(1, p), groups=g, bias=False)
        self.conv2 = nn.Conv2d(c1, c2, 3, s, autopad(3, p), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
    def forward(self, x):
        return self.act((self.bn(self.conv1(x)) + self.bn(self.conv2(x))))

    def forward_fuse(self, x):
        # return self.act(self.conv(x))
        return self.act((self.bn(self.conv1(x)) + self.bn(self.conv2(x))))

class Ponv(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        self.c_ = c1//2
        self.pconv3 = nn.Conv2d(self.c_, self.c_, 3, s, autopad(3, p), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(self.c_)
        self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())

    def forward(self, x):
        x1, x2 = torch.split(x, [self.c_, self.c_], dim=1)
        y1 = self.act(self.bn(self.pconv3(x1)))
        y2 = torch.cat((y1, x2), 1)
        outy=channel_shuffle(y2,2)
        return outy

    def forward_fuse(self, x):
        x1, x2 = torch.split(x, [self.c_, self.c_], dim=1)
        y1 = self.act(self.bn(self.pconv3(x1)))
        y2 = torch.cat((y1, x2), 1)
        outy = channel_shuffle(y2, 2)
        return outy

class Ponv2(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        self.c_ = c1//2
        self.pconv3 = nn.Conv2d(self.c_, self.c_, 3, s, autopad(3, p), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(self.c_)
        self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())

    def forward(self, x):
        x1, x2 = torch.split(x, [self.c_, self.c_], dim=1)
        y1 = self.act(self.bn(self.pconv3(x1)))
        y2 = torch.cat((y1, x2), 1)
        outy=channel_shuffle(y2,2)
        return outy

    def forward_fuse(self, x):
        x1, x2 = torch.split(x, [self.c_, self.c_], dim=1)
        y1 = self.act(self.bn(self.pconv3(x1)))
        outy = torch.cat((y1, x2), 1)
        return outy

class Conv1x3(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        self.conv1 = nn.Conv2d(c1, c2, (1,3), s, (0,1), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
    def forward(self, x):
        return self.act(self.bn(self.conv1(x)))

    def forward_fuse(self, x):
        return self.act(self.bn(self.conv1(x)))

class Conv3x1(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        self.conv1 = nn.Conv2d(c1, c2, (3,1), s, (1,0), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
    def forward(self, x):
        return self.act(self.bn(self.conv1(x)))

    def forward_fuse(self, x):
        return self.act(self.bn(self.conv1(x)))

class Conv3x3(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        self.conv1 = nn.Conv2d(c1, c2, 3, s, 1, groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
    def forward(self, x):
        return self.act(self.bn(self.conv1(x)))

    def forward_fuse(self, x):
        return self.act(self.bn(self.conv1(x)))




class AConv(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1, d=2,p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        # self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k+d, p), groups=g, bias=False,dilation=d)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
    def forward(self, x):
        return self.act(self.bn(self.conv(x)))
    def forward_fuse(self, x):
        return self.act(self.conv(x))

class AConv1(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=3, s=1, p=None, g=1, act=True,d=1):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        # self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.conv = nn.Conv2d(c1, c2, k, s,autopad(k, p), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.Mish() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
    def forward(self, x):
        return self.act(self.bn(self.conv(x)))
    def forward_fuse(self, x):
        return self.act(self.conv(x))

class AConv2(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=3, s=1, p=None, g=1, act=True,d=2):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        # self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.conv = nn.Conv2d(c1, c2, k, s,  autopad(k+d, p), groups=g, bias=False,dilation=d)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.Mish() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
    def forward(self, x):
        return self.act(self.bn(self.conv(x)))
    def forward_fuse(self, x):
        return self.act(self.conv(x))

class AConv3(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=3, s=1, p=None, g=1, act=True,d=3):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        # self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k+d, p), groups=g, bias=False,dilation=d)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.Mish()if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
    def forward(self, x):
        return self.act(self.bn(self.conv(x)))
    def forward_fuse(self, x):
        return self.act(self.conv(x))

class ADWonv1(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True,d=1):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        # self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k+0, p), groups=c1, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.Mish() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
    def forward(self, x):
        return self.act(self.bn(self.conv(x)))
    def forward_fuse(self, x):
        return self.act(self.conv(x))

class ADWonv2(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True,d=2):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        # self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k+d, p), groups=c1, bias=False,dilation=d)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.Mish() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
    def forward(self, x):
        return self.act(self.bn(self.conv(x)))
    def forward_fuse(self, x):
        return self.act(self.conv(x))

class ADWonv3(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True,d=3):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        # self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k+d, p), groups=c1, bias=False,dilation=d)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.Mish() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
    def forward(self, x):
        return self.act(self.bn(self.conv(x)))
    def forward_fuse(self, x):
        return self.act(self.conv(x))


class CrossConv2d(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):
        super(CrossConv2d, self).__init__()
        self.horizontal_conv = nn.Conv2d(c1, c2, (k, 1), padding=(k // 2, 0),groups=g, bias=False)
        self.vertical_conv = nn.Conv2d(c1, c2, (1, k), padding=(0, k // 2),groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
    def forward(self, x):
        horizontal_output = self.horizontal_conv(x)
        vertical_output = self.vertical_conv(x)
        return self.act(self.bn(horizontal_output + vertical_output))



class myConv(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
    def forward(self, x):
        return self.bn(self.conv(x))

    def forward_fuse(self, x):
        return self.conv(x)

# class myConv(nn.Module):
#     # Standard convolution
#     def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
#         super().__init__()
#         self.conv = nn.Conv2d(c1, c2, k, s, 0, groups=g, bias=False)
#         self.bn = nn.BatchNorm2d(c2)
#         # nn.Conv2d(hidden_dim, oup, 1, 1, 0, bias=False),
#     def forward(self, x):
#         return self.bn(self.conv(x))
#
#     def forward_fuse(self, x):
#         return self.conv(x)


class DWConv(Convl):
    # Depth-wise convolution class
    def __init__(self, c1, c2, k=1, s=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__(c1, c2, k, s, g=math.gcd(c1, c2), act=act)

class myDWConv(myConv):
    # Depth-wise convolution class
    def __init__(self, c1, c2, k=1, s=1):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__(c1, c2, k, s, g=math.gcd(c1//8, c2//8))


class SEDWConv(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=math.gcd(c1, c2), bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.se = SELayer(c2)
        self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())

    def forward(self, x):
        return self.se(self.act(self.bn(self.conv(x))))

    def forward_fuse(self, x):
        return self.se(self.act(self.conv(x)))


class TransformerLayer(nn.Module):
    # Transformer layer https://arxiv.org/abs/2010.11929 (LayerNorm layers removed for better performance)
    def __init__(self, c, num_heads):
        super().__init__()
        self.q = nn.Linear(c, c, bias=False)
        self.k = nn.Linear(c, c, bias=False)
        self.v = nn.Linear(c, c, bias=False)
        self.ma = nn.MultiheadAttention(embed_dim=c, num_heads=num_heads)
        self.fc1 = nn.Linear(c, c, bias=False)
        self.fc2 = nn.Linear(c, c, bias=False)

    def forward(self, x):
        x = self.ma(self.q(x), self.k(x), self.v(x))[0] + x
        x = self.fc2(self.fc1(x)) + x
        return x


class TransformerBlock(nn.Module):
    # Vision Transformer https://arxiv.org/abs/2010.11929
    def __init__(self, c1, c2, num_heads, num_layers):
        super().__init__()
        self.conv = None
        if c1 != c2:
            self.conv = Conv(c1, c2)
        self.linear = nn.Linear(c2, c2)  # learnable position embedding
        self.tr = nn.Sequential(*(TransformerLayer(c2, num_heads) for _ in range(num_layers)))
        self.c2 = c2

    def forward(self, x):
        if self.conv is not None:
            x = self.conv(x)
        b, _, w, h = x.shape
        p = x.flatten(2).permute(2, 0, 1)
        return self.tr(p + self.linear(p)).permute(1, 2, 0).reshape(b, self.c2, w, h)

def drop_path_f(x, drop_prob: float = 0., training: bool = False):
    """Drop paths (Stochastic Depth) per sample (when applied in main path of residual blocks).

    This is the same as the DropConnect impl I created for EfficientNet, etc networks, however,
    the original name is misleading as 'Drop Connect' is a different form of dropout in a separate paper...
    See discussion: https://github.com/tensorflow/tpu/issues/494#issuecomment-532968956 ... I've opted for
    changing the layer and argument names to 'drop path' rather than mix DropConnect as a layer name and use
    'survival rate' as the argument.

    """
    if drop_prob == 0. or not training:
        return x
    keep_prob = 1 - drop_prob
    shape = (x.shape[0],) + (1,) * (x.ndim - 1)  # work with diff dim tensors, not just 2D ConvNets
    random_tensor = keep_prob + torch.rand(shape, dtype=x.dtype, device=x.device)
    random_tensor.floor_()  # binarize
    output = x.div(keep_prob) * random_tensor
    return output


class DropPath(nn.Module):
    """Drop paths (Stochastic Depth) per sample  (when applied in main path of residual blocks).
    """
    def __init__(self, drop_prob=None):
        super(DropPath, self).__init__()
        self.drop_prob = drop_prob

    def forward(self, x):
        return drop_path_f(x, self.drop_prob, self.training)

def window_partition(x, window_size: int):
    """
    将feature map按照window_size划分成一个个没有重叠的window
    Args:
        x: (B, H, W, C)
        window_size (int): window size(M)

    Returns:
        windows: (num_windows*B, window_size, window_size, C)
    """
    B, H, W, C = x.shape
    x = x.view(B, H // window_size, window_size, W // window_size, window_size, C)
    # permute: [B, H//Mh, Mh, W//Mw, Mw, C] -> [B, H//Mh, W//Mh, Mw, Mw, C]
    # view: [B, H//Mh, W//Mw, Mh, Mw, C] -> [B*num_windows, Mh, Mw, C]
    windows = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(-1, window_size, window_size, C)
    return windows

def window_reverse(windows, window_size: int, H: int, W: int):
    """
    将一个个window还原成一个feature map
    Args:
        windows: (num_windows*B, window_size, window_size, C)
        window_size (int): Window size(M)
        H (int): Height of image
        W (int): Width of image

    Returns:
        x: (B, H, W, C)
    """
    B = int(windows.shape[0] / (H * W / window_size / window_size))
    # view: [B*num_windows, Mh, Mw, C] -> [B, H//Mh, W//Mw, Mh, Mw, C]
    x = windows.view(B, H // window_size, W // window_size, window_size, window_size, -1)
    # permute: [B, H//Mh, W//Mw, Mh, Mw, C] -> [B, H//Mh, Mh, W//Mw, Mw, C]
    # view: [B, H//Mh, Mh, W//Mw, Mw, C] -> [B, H, W, C]
    x = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(B, H, W, -1)
    return x

class Mlp(nn.Module):
    """ MLP as used in Vision Transformer, MLP-Mixer and related networks
    """
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features

        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = act_layer()
        self.drop1 = nn.Dropout(drop)
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop2 = nn.Dropout(drop)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop1(x)
        x = self.fc2(x)
        x = self.drop2(x)
        return x

class WindowAttention(nn.Module):
    r""" Window based multi-head self attention (W-MSA) module with relative position bias.
    It supports both of shifted and non-shifted window.

    Args:
        dim (int): Number of input channels.
        window_size (tuple[int]): The height and width of the window.
        num_heads (int): Number of attention heads.
        qkv_bias (bool, optional):  If True, add a learnable bias to query, key, value. Default: True
        attn_drop (float, optional): Dropout ratio of attention weight. Default: 0.0
        proj_drop (float, optional): Dropout ratio of output. Default: 0.0
    """

    def __init__(self, dim, window_size, num_heads, qkv_bias=True, attn_drop=0., proj_drop=0.):

        super().__init__()
        self.dim = dim
        self.window_size = window_size  # [Mh, Mw]
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = head_dim ** -0.5

        # define a parameter table of relative position bias
        self.relative_position_bias_table = nn.Parameter(
            torch.zeros((2 * window_size[0] - 1) * (2 * window_size[1] - 1), num_heads))  # [2*Mh-1 * 2*Mw-1, nH]

        # get pair-wise relative position index for each token inside the window
        coords_h = torch.arange(self.window_size[0])
        coords_w = torch.arange(self.window_size[1])
        coords = torch.stack(torch.meshgrid([coords_h, coords_w], indexing="ij"))  # [2, Mh, Mw]
        coords_flatten = torch.flatten(coords, 1)  # [2, Mh*Mw]
        # [2, Mh*Mw, 1] - [2, 1, Mh*Mw]
        relative_coords = coords_flatten[:, :, None] - coords_flatten[:, None, :]  # [2, Mh*Mw, Mh*Mw]
        relative_coords = relative_coords.permute(1, 2, 0).contiguous()  # [Mh*Mw, Mh*Mw, 2]
        relative_coords[:, :, 0] += self.window_size[0] - 1  # shift to start from 0
        relative_coords[:, :, 1] += self.window_size[1] - 1
        relative_coords[:, :, 0] *= 2 * self.window_size[1] - 1
        relative_position_index = relative_coords.sum(-1)  # [Mh*Mw, Mh*Mw]
        self.register_buffer("relative_position_index", relative_position_index)

        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

        nn.init.trunc_normal_(self.relative_position_bias_table, std=.02)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x, mask: Optional[torch.Tensor] = None):
        """
        Args:
            x: input features with shape of (num_windows*B, Mh*Mw, C)
            mask: (0/-inf) mask with shape of (num_windows, Wh*Ww, Wh*Ww) or None
        """
        # [batch_size*num_windows, Mh*Mw, total_embed_dim]
        B_, N, C = x.shape
        # qkv(): -> [batch_size*num_windows, Mh*Mw, 3 * total_embed_dim]
        # reshape: -> [batch_size*num_windows, Mh*Mw, 3, num_heads, embed_dim_per_head]
        # permute: -> [3, batch_size*num_windows, num_heads, Mh*Mw, embed_dim_per_head]
        qkv = self.qkv(x).reshape(B_, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        # [batch_size*num_windows, num_heads, Mh*Mw, embed_dim_per_head]
        q, k, v = qkv.unbind(0)  # make torchscript happy (cannot use tensor as tuple)

        # transpose: -> [batch_size*num_windows, num_heads, embed_dim_per_head, Mh*Mw]
        # @: multiply -> [batch_size*num_windows, num_heads, Mh*Mw, Mh*Mw]
        q = q * self.scale
        attn = (q @ k.transpose(-2, -1))

        # relative_position_bias_table.view: [Mh*Mw*Mh*Mw,nH] -> [Mh*Mw,Mh*Mw,nH]
        relative_position_bias = self.relative_position_bias_table[self.relative_position_index.view(-1)].view(
            self.window_size[0] * self.window_size[1], self.window_size[0] * self.window_size[1], -1)
        relative_position_bias = relative_position_bias.permute(2, 0, 1).contiguous()  # [nH, Mh*Mw, Mh*Mw]
        attn = attn + relative_position_bias.unsqueeze(0)

        if mask is not None:
            # mask: [nW, Mh*Mw, Mh*Mw]
            nW = mask.shape[0]  # num_windows
            # attn.view: [batch_size, num_windows, num_heads, Mh*Mw, Mh*Mw]
            # mask.unsqueeze: [1, nW, 1, Mh*Mw, Mh*Mw]
            attn = attn.view(B_ // nW, nW, self.num_heads, N, N) + mask.unsqueeze(1).unsqueeze(0)
            attn = attn.view(-1, self.num_heads, N, N)
            attn = self.softmax(attn)
        else:
            attn = self.softmax(attn)

        attn = self.attn_drop(attn)

        # @: multiply -> [batch_size*num_windows, num_heads, Mh*Mw, embed_dim_per_head]
        # transpose: -> [batch_size*num_windows, Mh*Mw, num_heads, embed_dim_per_head]
        # reshape: -> [batch_size*num_windows, Mh*Mw, total_embed_dim]
        x = (attn @ v).transpose(1, 2).reshape(B_, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x

class SwinTransformerLayer(nn.Module):
    # Vision Transformer https://arxiv.org/abs/2010.11929
    def __init__(self, c, num_heads, window_size=7, shift_size=0,
                 mlp_ratio=4, qkv_bias=False, drop=0., attn_drop=0., drop_path=0.,
                 act_layer=nn.GELU, norm_layer=nn.LayerNorm):
        super().__init__()
        if num_heads > 10:
            drop_path = 0.1
        self.window_size = window_size
        self.shift_size = shift_size
        self.mlp_ratio = mlp_ratio

        self.norm1 = norm_layer(c)
        self.attn = WindowAttention(
            c, window_size=(self.window_size, self.window_size), num_heads=num_heads, qkv_bias=qkv_bias,
            attn_drop=attn_drop, proj_drop=drop)

        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(c)
        mlp_hidden_dim = int(c * mlp_ratio)
        self.mlp = Mlp(in_features=c, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)

    def create_mask(self, x, H, W):
        # calculate attention mask for SW-MSA
        # 保证Hp和Wp是window_size的整数倍
        Hp = int(np.ceil(H / self.window_size)) * self.window_size
        Wp = int(np.ceil(W / self.window_size)) * self.window_size
        # 拥有和feature map一样的通道排列顺序，方便后续window_partition
        img_mask = torch.zeros((1, Hp, Wp, 1), device=x.device)  # [1, Hp, Wp, 1]
        h_slices = ((0, -self.window_size),
                    slice(-self.window_size, -self.shift_size),
                    slice(-self.shift_size, None))
        w_slices = (slice(0, -self.window_size),
                    slice(-self.window_size, -self.shift_size),
                    slice(-self.shift_size, None))
        cnt = 0
        for h in h_slices:
            for w in w_slices:
                img_mask[:, h, w, :] = cnt
                cnt += 1

        mask_windows = window_partition(img_mask, self.window_size)  # [nW, Mh, Mw, 1]
        mask_windows = mask_windows.view(-1, self.window_size * self.window_size)  # [nW, Mh*Mw]
        attn_mask = mask_windows.unsqueeze(1) - mask_windows.unsqueeze(2)  # [nW, 1, Mh*Mw] - [nW, Mh*Mw, 1]
        # [nW, Mh*Mw, Mh*Mw]
        attn_mask = attn_mask.masked_fill(attn_mask != 0, torch.tensor(-100.0)).masked_fill(attn_mask == 0,
                                                                                            torch.tensor(0.0))
        return attn_mask

    def forward(self, x):
        b, c, w, h = x.shape
        x = x.permute(0, 3, 2, 1).contiguous()  # [b,h,w,c]

        attn_mask = self.create_mask(x, h, w)  # [nW, Mh*Mw, Mh*Mw]
        shortcut = x
        x = self.norm1(x)

        pad_l = pad_t = 0
        pad_r = (self.window_size - w % self.window_size) % self.window_size
        pad_b = (self.window_size - h % self.window_size) % self.window_size
        x = F.pad(x, (0, 0, pad_l, pad_r, pad_t, pad_b))
        _, hp, wp, _ = x.shape

        if self.shift_size > 0:
            # print(f"shift size: {self.shift_size}")
            shifted_x = torch.roll(x, shifts=(-self.shift_size, -self.shift_size), dims=(1, 2))
        else:
            shifted_x = x
            attn_mask = None

        x_windows = window_partition(shifted_x, self.window_size)  # [nW*B, Mh, Mw, C]
        x_windows = x_windows.view(-1, self.window_size * self.window_size, c)  # [nW*B, Mh*Mw, C]

        attn_windows = self.attn(x_windows, mask=attn_mask)  # [nW*B, Mh*Mw, C]

        attn_windows = attn_windows.view(-1, self.window_size, self.window_size, c)  # [nW*B, Mh, Mw, C]
        shifted_x = window_reverse(attn_windows, self.window_size, hp, wp)  # [B, H', W', C]

        if self.shift_size > 0:
            x = torch.roll(shifted_x, shifts=(self.shift_size, self.shift_size), dims=(1, 2))
        else:
            x = shifted_x

        if pad_r > 0 or pad_b > 0:
            # 把前面pad的数据移除掉
            x = x[:, :h, :w, :].contiguous()

        x = shortcut + self.drop_path(x)
        x = x + self.drop_path(self.mlp(self.norm2(x)))

        x = x.permute(0, 3, 2, 1).contiguous()
        return x  # (b, self.c2, w, h)


class SwinTransformerBlock(nn.Module):
    def __init__(self, c1, c2, num_heads, num_layers, window_size=8):
        super().__init__()
        self.conv = None
        if c1 != c2:
            self.conv = Conv(c1, c2)

        self.window_size = window_size
        self.shift_size = window_size // 2
        self.tr = nn.Sequential(*(SwinTransformerLayer(c2, num_heads=num_heads, window_size=window_size,
                                                       shift_size=0 if (i % 2 == 0) else self.shift_size) for i in
                                  range(num_layers)))

    def forward(self, x):
        if self.conv is not None:
            x = self.conv(x)
        x = self.tr(x)
        return x





class ChannelAttention(nn.Module):
    def __init__(self, channel, reduction=4):
        super().__init__()
        self.maxpool = nn.AdaptiveMaxPool2d(1)
        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.se = nn.Sequential(
            nn.Conv2d(channel, channel // reduction, 1, bias=False),
            nn.ReLU(),
            nn.Conv2d(channel // reduction, channel, 1, bias=False)
        )
        self.sigmoid = nn.Sigmoid()
        self.m=h_swish()

    def forward(self, x):
        max_result = self.maxpool(x)
        avg_result = self.avgpool(x)
        max_out = self.se(max_result)
        avg_out = self.se(avg_result)
        output = self.sigmoid(max_out + avg_out)
        return output


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=3):
        super().__init__()
        self.conv = nn.Conv2d(2, 1, kernel_size=kernel_size, padding=kernel_size // 2)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        max_result, _ = torch.max(x, dim=1, keepdim=True)
        avg_result = torch.mean(x, dim=1, keepdim=True)
        result = torch.cat([max_result, avg_result], 1)
        output = self.conv(result)
        output = self.sigmoid(output)
        return output

class SpatialAttentionx(nn.Module):
    def __init__(self, kernel_size=3):
        super().__init__()
        self.conv = nn.Conv2d(2, 1, kernel_size=kernel_size, padding=kernel_size // 2)
        self.m=h_sigmoid()

    def forward(self, x):
        max_result, _ = torch.max(x, dim=1, keepdim=True)
        avg_result = torch.mean(x, dim=1, keepdim=True)
        result = torch.cat([max_result, avg_result], 1)
        output = self.conv(result)
        output = self.m(output)
        return output

class CBAM(nn.Module):
    def __init__(self, c1,ratio=16,kernel_size=7):
        super(CBAM, self).__init__()
        self.channel_attention = ChannelAttention(c1, ratio)
        self.spatial_attention = SpatialAttention(kernel_size)

    def forward(self, x):
        out = self.channel_attention(x)*x
        out = self.spatial_attention(out) * out
        return out
class CBAMX(nn.Module):
    def __init__(self, c1,ratio=16,kernel_size=3):
        super(CBAMX, self).__init__()
        # self.channel_attention = ChannelAttention(c1, ratio)
        self.channel_attention = SELayer(c1)
        self.spatial_attention = SpatialAttentionx(kernel_size)

    def forward(self, x):
        out = self.channel_attention(x)
        out = self.spatial_attention(out) * out
        return out

class ECBAM(nn.Module):
    def __init__(self, c1,ratio=16,kernel_size=3):
        super(ECBAM, self).__init__()
        self.channel_attention = ChannelAttention(c1, ratio)
        # self.spatial_attention = SpatialAttention(kernel_size)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=kernel_size, padding=(kernel_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x1):
        out = self.channel_attention(x1) * x1
        y = self.avg_pool(out)
        y = self.conv(y.squeeze(-1).transpose(-1, -2)).transpose(-1, -2).unsqueeze(-1)
        y = self.sigmoid(y)
        out = out * y.expand_as(out)
        # print('outchannels:{}'.format(out.shape))
        # out = self.spatial_attention(out) * out
        return out




class CBAMBottleneck(nn.Module):
    # Standard bottleneck
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5,ratio=16,kernel_size=7):  # ch_in, ch_out, shortcut, groups, expansion
        super(CBAMBottleneck,self).__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_, c2, 3, 1, g=g)
        self.add = shortcut and c1 == c2
        self.channel_attention = ChannelAttention(c2, ratio)
        self.spatial_attention = SpatialAttention(kernel_size)
        #self.cbam=CBAM(c1,c2,ratio,kernel_size)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=kernel_size, padding=(kernel_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()
    def forward(self, x):
        x1 = self.cv2(self.cv1(x))
        out = self.channel_attention(x1) * x1
        # print('outchannels:{}'.format(out.shape))
        out = self.spatial_attention(out) * out
        return x + out if self.add else out


class ECABottleneck(nn.Module):
    # Standard bottleneck
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5, ratio=16, k_size=3):  # ch_in, ch_out, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_, c2, 3, 1, g=g)
        self.add = shortcut and c1 == c2
        # self.eca=ECA(c1,c2)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=k_size, padding=(k_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x1 = self.cv2(self.cv1(x))
        # out=self.eca(x1)*x1
        y = self.avg_pool(x1)
        y = self.conv(y.squeeze(-1).transpose(-1, -2)).transpose(-1, -2).unsqueeze(-1)
        y = self.sigmoid(y)
        out = x1 * y.expand_as(x1)

        return x + out if self.add else out

class ECBAMBottleneck(nn.Module):
    # Standard bottleneck
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5,ratio=16,kernel_size=3):  # ch_in, ch_out, shortcut, groups, expansion
        super(ECBAMBottleneck,self).__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_, c2, 3, 1, g=g)
        self.add = shortcut and c1 == c2
        self.channel_attention = ChannelAttention(c2, ratio)

        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=kernel_size, padding=(kernel_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

        # self.spatial_attention = SpatialAttention(kernel_size)
        #self.cbam=CBAM(c1,c2,ratio,kernel_size)

    def forward(self, x):
        x1 = self.cv2(self.cv1(x))
        out = self.channel_attention(x1) * x1

        y = self.avg_pool(out)
        y = self.conv(y.squeeze(-1).transpose(-1, -2)).transpose(-1, -2).unsqueeze(-1)
        y = self.sigmoid(y)
        out = out * y.expand_as(out)

        # print('outchannels:{}'.format(out.shape))
        # out = self.spatial_attention(out) * out
        return x + out if self.add else out






class h_sigmoid(nn.Module):
    def __init__(self, inplace=True):
        super(h_sigmoid, self).__init__()
        self.relu = nn.ReLU6(inplace=inplace)

    def forward(self, x):
        return self.relu(x + 3) / 6


class h_swish(nn.Module):
    def __init__(self, inplace=True):
        super(h_swish, self).__init__()
        self.sigmoid = h_sigmoid(inplace=inplace)

    def forward(self, x):
        return x * self.sigmoid(x)


# class CoordAtt(nn.Module):
#     def __init__(self, inp, oup, reduction=32):
#         super(CoordAtt, self).__init__()
#         self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
#         self.pool_w = nn.AdaptiveAvgPool2d((1, None))
#
#         mip = max(8, inp // reduction)
#
#         self.conv1 = nn.Conv2d(inp, mip, kernel_size=1, stride=1, padding=0)
#         self.bn1 = nn.BatchNorm2d(mip)
#         self.act = h_swish()
#         # self.act1 = h_sigmoid()
#         # self.act = nn.Sigmoid()
#         # self.act = nn.ReLU()
#         # self.act = nn.Mish()
#         self.conv_h = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)
#         self.conv_w = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)
#
#     def forward(self, x):
#         identity = x
#
#         n, c, h, w = x.size()
#         x_h = self.pool_h(x)
#         x_w = self.pool_w(x).permute(0, 1, 3, 2)
#
#         y = torch.cat([x_h, x_w], dim=2)
#         y = self.conv1(y)
#         y = self.bn1(y)
#         y = self.act(y)
#
#         x_h, x_w = torch.split(y, [h, w], dim=2)
#         x_w = x_w.permute(0, 1, 3, 2)
#
#         a_h = self.conv_h(x_h).sigmoid()
#         a_w = self.conv_w(x_w).sigmoid()
#         # a_h = self.act1(self.conv_h(x_h))
#         # a_w = self.act1(self.conv_w(x_w))
#
#         out = identity * a_w * a_h
#
#         return out

class CoordAtt(nn.Module):
    def __init__(self, inp, oup, reduction=32):
        super(CoordAtt, self).__init__()
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))

        mip = max(8, inp // reduction)

        self.conv1 = nn.Conv2d(inp, mip, kernel_size=1, stride=1, padding=0)
        self.bn1 = nn.BatchNorm2d(mip)
        # self.act = h_swish()
        # self.act = nn.Mish()
        self.act = nn.SiLU()
        self.conv_h = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)
        self.conv_w = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        identity = x

        n, c, h, w = x.size()
        x_h = self.pool_h(x)
        x_w = self.pool_w(x).permute(0, 1, 3, 2)

        y = torch.cat([x_h, x_w], dim=2)
        y = self.conv1(y)
        y = self.bn1(y)
        y = self.act(y)

        x_h, x_w = torch.split(y, [h, w], dim=2)
        x_w = x_w.permute(0, 1, 3, 2)

        a_h = self.conv_h(x_h).sigmoid()
        a_w = self.conv_w(x_w).sigmoid()


        out = identity * a_w * a_h

        return out

class CBAM_CA_Bottleneck(nn.Module):
    # Standard bottleneck
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5,ratio=16,kernel_size=7, reduction=32):  # ch_in, ch_out, shortcut, groups, expansion
        super(CBAM_CA_Bottleneck,self).__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_, c2, 3, 1, g=g)
        self.add = shortcut and c1 == c2
        self.channel_attention = ChannelAttention(c2, ratio)#ECA
        self.spatial_attention = SpatialAttention(kernel_size)
        #self.cbam=CBAM(c1,c2,ratio,kernel_size)


        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))

        mip = max(8, c1 // reduction)

        self.conv1 = nn.Conv2d(c1, mip, kernel_size=1, stride=1, padding=0)
        self.bn1 = nn.BatchNorm2d(mip)
        self.act = h_swish()

        self.conv_h = nn.Conv2d(mip, c2, kernel_size=1, stride=1, padding=0)
        self.conv_w = nn.Conv2d(mip, c2, kernel_size=1, stride=1, padding=0)

    def forward(self, x):

        x1 = self.cv2(self.cv1(x))
        out = self.channel_attention(x1) * x1
        # print('outchannels:{}'.format(out.shape))
        out = self.spatial_attention(out) * out

        identity = x

        n, c, h, w = x.size()
        x_h = self.pool_h(x)
        x_w = self.pool_w(x).permute(0, 1, 3, 2)

        y = torch.cat([x_h, x_w], dim=2)
        y = self.conv1(y)
        y = self.bn1(y)
        y = self.act(y)

        x_h, x_w = torch.split(y, [h, w], dim=2)
        x_w = x_w.permute(0, 1, 3, 2)

        a_h = self.conv_h(x_h).sigmoid()
        a_w = self.conv_w(x_w).sigmoid()

        out_CA = identity * a_w * a_h

        return x + out+out_CA if self.add else out+out_CA

class my_RepBottleneck(nn.Module):
    # Standard bottleneck
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = myConv(c_, c2, 3, 1, g=g)
        self.cv3 = myConv(c_, c2, 1, 1, g=g)
        self.conv = nn.Conv2d(c_, c2, 5, 1, autopad(5, None), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU()
        self.add = shortcut and c1 == c2
        # self.my_m=ECABottleneck(c_, c_, shortcut, g, e=1.0)
    def forward(self, x):
        x=self.cv1(x)
        y=self.act(self.cv2(x)+self.cv3(x)+self.bn(self.conv(x)))
        return x + y if self.add else y
        # return x + self.cv2(self.my_m(self.cv1(x))) if self.add else self.cv2(self.my_m(self.cv1(x)))
class RepC3(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # act=FReLU(c2)
        if(shortcut==True):
            self.m = nn.Sequential(*(my_RepBottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))
        else:
            self.m = nn.Sequential(*(Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))

    def forward(self, x):
        # a,b,c,d=x.shape
        # if b>=128:
        #     return self.mycot(self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1)))
        # else:
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))
class Bottleneck(nn.Module):
    # Standard bottleneck
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_, c2, 3, 1, g=g)
        self.add = shortcut and c1 == c2
        # self.my_m=ECABottleneck(c_, c_, shortcut, g, e=1.0)
    def forward(self, x):
        return x + self.cv2(self.cv1(x)) if self.add else self.cv2(self.cv1(x))
        # return x + self.cv2(self.my_m(self.cv1(x))) if self.add else self.cv2(self.my_m(self.cv1(x)))


class Bottleneck_ELAN(nn.Module):
    # Standard bottleneck
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_, c_, 3, 1, g=g)
        self.cv3 = Conv(c_, c_, 3, 1, g=g)
        self.cv4 = Conv(3*c_,c2,1,1)
        # self.add = shortcut and c1 == c2
        # self.my_m=ECABottleneck(c_, c_, shortcut, g, e=1.0)
    def forward(self, x):
        x1 = self.cv1(x)
        x2 = self.cv2(x1)
        x3 = self.cv3(x2)
        y = torch.cat([x1,x2,x3],dim=1)
        y = self.cv4(y)
        return y

class FasterBottleneck(nn.Module):
    # Standard bottleneck
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        # self.cv2 = Conv(c_, c2, 3, 1, g=g)
        self.partconv=Partial_conv334(c_,1,forward='split_cat')
        self.add = shortcut and c1 == c2
        # self.my_m=ECABottleneck(c_, c_, shortcut, g, e=1.0)
    def forward(self, x):
        return x + self.partconv(self.cv1(x)) if self.add else self.partconv(self.cv1(x))

class ECA_Bottleneck(nn.Module):
    # Standard bottleneck
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_, c2, 3, 1, g=g)
        self.add = shortcut and c1 == c2
        self.my_m=ECABottleneck(c_, c_, shortcut, g, e=1.0)
    def forward(self, x):
        # return x + self.cv2(self.cv1(x)) if self.add else self.cv2(self.cv1(x))
        return x + self.cv2(self.my_m(self.cv1(x))) if self.add else self.cv2(self.my_m(self.cv1(x)))

class BottleneckCSP(nn.Module):
    # CSP Bottleneck https://github.com/WongKinYiu/CrossStagePartialNetworks
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = nn.Conv2d(c1, c_, 1, 1, bias=False)
        self.cv3 = nn.Conv2d(c_, c_, 1, 1, bias=False)
        self.cv4 = Conv(2 * c_, c2, 1, 1)
        self.bn = nn.BatchNorm2d(2 * c_)  # applied to cat(cv2, cv3)
        self.act = nn.SiLU()
        self.m = nn.Sequential(*(Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))

    def forward(self, x):
        y1 = self.cv3(self.m(self.cv1(x)))
        y2 = self.cv2(x)
        return self.cv4(self.act(self.bn(torch.cat((y1, y2), dim=1))))





class C3(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # act=FReLU(c2)
        self.m = nn.Sequential(*(Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))
        # self.mycot = MYCoT(c2,c2)
        # self.m = nn.Sequential(*[CrossConv(c_, c_, 3, 1, g, 1.0, shortcut) for _ in range(n)])

    def forward(self, x):
        # a,b,c,d=x.shape
        # if b>=128:
        #     return self.mycot(self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1)))
        # else:
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))

class C3SE(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # act=FReLU(c2)
        self.m = nn.Sequential(*(Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))
        self.se = SELayer(c2)
        # self.mycot = MYCoT(c2,c2)
        # self.m = nn.Sequential(*[CrossConv(c_, c_, 3, 1, g, 1.0, shortcut) for _ in range(n)])

    def forward(self, x):
        # a,b,c,d=x.shape
        # if b>=128:
        #     return self.mycot(self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1)))
        # else:
        return self.se(self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1)))


class C3IA(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # act=FReLU(c2)
        self.m = nn.Sequential(*(Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))
        self.ia = IALayer(c2)
        # self.mycot = MYCoT(c2,c2)
        # self.m = nn.Sequential(*[CrossConv(c_, c_, 3, 1, g, 1.0, shortcut) for _ in range(n)])

    def forward(self, x):
        # a,b,c,d=x.shape
        # if b>=128:
        #     return self.mycot(self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1)))
        # else:
        return self.ia(self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1)))
class ECA_C3(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # act=FReLU(c2)
        self.m = nn.Sequential(*(ECABottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))
        # self.m = nn.Sequential(*[CrossConv(c_, c_, 3, 1, g, 1.0, shortcut) for _ in range(n)])

    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))

class CBAM_C3(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # act=FReLU(c2)
        self.m = nn.Sequential(*(CBAMBottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))
        # self.m = nn.Sequential(*[CrossConv(c_, c_, 3, 1, g, 1.0, shortcut) for _ in range(n)])

    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))


class ECBAM_C3(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # act=FReLU(c2)
        self.m = nn.Sequential(*(ECBAMBottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))
        # self.m = nn.Sequential(*[CrossConv(c_, c_, 3, 1, g, 1.0, shortcut) for _ in range(n)])

    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))

class CBAM_CA_C3(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # act=FReLU(c2)
        self.m = nn.Sequential(*(CBAM_CA_Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))
        # self.m = nn.Sequential(*[CrossConv(c_, c_, 3, 1, g, 1.0, shortcut) for _ in range(n)])
    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))


class C3CBAM(C3):
    # C3 module with CBAMBottleneck()
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)  # hidden channels
        self.m = nn.Sequential(*(CBAMBottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))

class C3ECA(C3):
    # C3 module with ECABottleneck()
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)  # hidden channels
        self.m = nn.Sequential(*(ECABottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))

class C3_CBAM_Attention(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # optional act=FReLU(c2)
        self.m = nn.Sequential(*(Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))
        self._CBAM = ECBAMBottleneck(c2, c2)

    def forward(self, x):
        return self._CBAM(self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), 1)))

class C3_ECA_Attention(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # optional act=FReLU(c2)
        self.m = nn.Sequential(*(Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))
        self._ECA = ECABottleneck(c2, c2)

class C3_ECBAM_Attention(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1,
                 e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # optional act=FReLU(c2)
        self.m = nn.Sequential(*(Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))
        self._ECA = ECBAMBottleneck(c2, c2)

    def forward(self, x):
        return self._ECA(self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), 1)))

class C3TR(C3):
    # C3 module with TransformerBlock()
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)
        self.m = TransformerBlock(c_, c_, 4, n)

class C3STR(C3):
    # C3 module with SwinTransformerBlock()
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)
        self.m = SwinTransformerBlock(c_, c_, c_//32, n)

class C3SPP(C3):
    # C3 module with SPP()
    def __init__(self, c1, c2, k=(5, 9, 13), n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)
        self.m = SPP(c_, c_, k)


class C3Ghost(C3):
    # C3 module with GhostBottleneck()
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)  # hidden channels
        self.m = nn.Sequential(*(GhostBottleneck(c_, c_) for _ in range(n)))


class SPP(nn.Module):
    # Spatial Pyramid Pooling (SPP) layer https://arxiv.org/abs/1406.4729
    def __init__(self, c1, c2, k=(5, 9, 13)):
        super().__init__()
        c_ = c1 // 2  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_ * (len(k) + 1), c2, 1, 1)
        self.m = nn.ModuleList([nn.MaxPool2d(kernel_size=x, stride=1, padding=x // 2) for x in k])

    def forward(self, x):
        x = self.cv1(x)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')  # suppress torch 1.9.0 max_pool2d() warning
            return self.cv2(torch.cat([x] + [m(x) for m in self.m], 1))

class SPPF(nn.Module):
    # Spatial Pyramid Pooling - Fast (SPPF) layer for YOLOv5 by Glenn Jocher
    def __init__(self, c1, c2, k=5):  # equivalent to SPP(k=(5, 9, 13))
        super().__init__()
        c_ = c1 // 2  # hidden channels    96=192/2
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_ * 4, c2, 1, 1)
        self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)  #96

    def forward(self, x):
        x = self.cv1(x)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')  # suppress torch 1.9.0 max_pool2d() warning
            y1 = self.m(x)
            y2 = self.m(y1)
            return self.cv2(torch.cat([x, y1, y2, self.m(y2)], 1))


class CSAPPF(nn.Module):
    # Spatial Pyramid Pooling - Fast (SPPF) layer for YOLOv5 by Glenn Jocher
    def __init__(self, c1, c2, k=5):  # equivalent to SPP(k=(5, 9, 13))
        super().__init__()
        c_ = c1 // 2  # hidden channels    96=192/2
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_ * 4, c2, 1, 1)
        # self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)  #96
        self.av1 = AConv1(c_, c_, 3, 1)
        self.av2 = AConv2(c_, c_, 3, 1)
        self.av3 = AConv3(c_, c_, 3, 1)

    def forward(self, x):
        x = self.cv1(x)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')  # suppress torch 1.9.0 max_pool2d() warning
            y1 = self.av1(x)
            y2 = self.av2(y1)
            y3 = self.av3(y2)
            return self.cv2(torch.cat([x, y1, y2, y3], 1))



class CSPPF(nn.Module):
    # Spatial Pyramid Pooling - Fast (SPPF) layer for YOLOv5 by Glenn Jocher
    def __init__(self, c1, c2, k=5):  # equivalent to SPP(k=(5, 9, 13))
        super().__init__()
        c_ = c1 // 2  # hidden channels    96=192/2
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_ * 5, c2, 1, 1)
        self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)  #96
        self.ca = CoordAtt(c2, c2)
    def forward(self, x):
        x = self.cv1(x)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')  # suppress torch 1.9.0 max_pool2d() warning
            y1 = self.m(x)
            y2 = self.m(y1)
            y3 = self.m(y2)
            return self.ca(self.cv2(torch.cat([x,y1,y2,y3,self.m(y3)],1)))

class CAPPF(nn.Module):
    # Spatial Pyramid Pooling - Fast (SPPF) layer for YOLOv5 by Glenn Jocher
    def __init__(self, c1, c2, k=5):  # equivalent to SPP(k=(5, 9, 13))
        super().__init__()
        c_ = c1 // 2  # hidden channels    96=192/2
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_ * 5, c2, 1, 1)
        self.atrous_block = nn.Conv2d(c_, c_, 3, 1, padding=2, dilation=2)
        self.ca = CoordAtt(c2, c2)
    def forward(self, x):
        x = self.cv1(x)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')  # suppress torch 1.9.0 max_pool2d() warning
            y1 = self.atrous_block(x)
            y2 = self.atrous_block(y1)
            y3 = self.atrous_block(y2)
            return self.ca(self.cv2(torch.cat([x,y1,y2,y3,self.atrous_block(y3)],1)))

# class SPPF(nn.Module):
#     # Spatial Pyramid Pooling - Fast (SPPF) layer for YOLOv5 by Glenn Jocher
#     def __init__(self, c1, c2, k=5):  # equivalent to SPP(k=(5, 9, 13))
#         super().__init__()
#         c_ = c1 // 2  # hidden channels    96=192/2
#         self.cv1 = Conv(c1, c_, 1, 1)
#         self.cv2 = Conv(c_ * 4, c2, 1, 1)
#         self.ca=CoordAtt(c2,c2)
#         # self.cot=CoT
#         self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)  #96
#         # self.n = nn.AvgPool2d(kernel_size=k, stride=1, padding=k // 2)  # 96
#
#     def forward(self, x):
#         x = self.cv1(x)
#         with warnings.catch_warnings():
#             warnings.simplefilter('ignore')  # suppress torch 1.9.0 max_pool2d() warning
#             y1 = self.m(x)
#             y2 = self.m(y1)
#             y3 = self.m(y2)
#             # y4 = self.m(y3)
#             # z1 = self.n(x)
#             # z2 = self.n(z1)
#             # z3 = self.n(z2)
#             # y4 = self.m(y3)
#             return self.cv2(torch.cat([x, y1, y2, y3], 1))

# without BN version
# without BN version
# class ASPP(nn.Module):
#     def __init__(self, in_channel=512, out_channel=256):
#         super(ASPP, self).__init__()
#         self.mean = nn.AdaptiveAvgPool2d((1, 1))  # (1,1)means ouput_dim
#         self.conv = nn.Conv2d(in_channel,out_channel, 1, 1)
#         # self.atrous_block1 = nn.Conv2d(in_channel, out_channel, 1, 1)
#         self.atrous_block6 = nn.Conv2d(in_channel, out_channel, 3, 1, padding=6, dilation=6)
#         self.atrous_block12 = nn.Conv2d(in_channel, out_channel, 3, 1, padding=12, dilation=12)
#         self.atrous_block18 = nn.Conv2d(in_channel, out_channel, 3, 1, padding=18, dilation=18)
#         self.conv_1x1_output = nn.Conv2d(out_channel * 4, out_channel, 1, 1)
#
#     def forward(self, x):
#         size = x.shape[2:]
#
#         image_features = self.mean(x)
#         image_features = self.conv(image_features)
#         image_features = F.upsample(image_features, size=size, mode='bilinear')
#
#         # atrous_block1 = self.atrous_block1(x)
#         atrous_block6 = self.atrous_block6(x)
#         atrous_block12 = self.atrous_block12(x)
#         atrous_block18 = self.atrous_block18(x)
#
#         net = self.conv_1x1_output(torch.cat([image_features, atrous_block6,
#                                               atrous_block12, atrous_block18], dim=1))
#         return net



class SPPFCSPC(nn.Module):
    # 本代码由YOLOAir目标检测交流群 心动 大佬贡献
    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5, k=5):
        super(SPPFCSPC, self).__init__()
        c_ = int(2 * c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(c_, c_, 3, 1)
        self.cv4 = Conv(c_, c_, 1, 1)
        self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)
        self.cv5 = Conv(4 * c_, c_, 1, 1)
        self.cv6 = Conv(c_, c_, 3, 1)
        self.cv7 = Conv(2 * c_, c2, 1, 1)

    def forward(self, x):
        x1 = self.cv4(self.cv3(self.cv1(x)))
        x2 = self.m(x1)
        x3 = self.m(x2)
        y1 = self.cv6(self.cv5(torch.cat((x1,x2,x3, self.m(x3)),1)))
        y2 = self.cv2(x)
        return self.cv7(torch.cat((y1, y2), dim=1))

class BottleneckCSPC(nn.Module):
    # CSP https://github.com/WongKinYiu/CrossStagePartialNetworks
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super(BottleneckCSPC, self).__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(c_, c_, 1, 1)
        self.cv4 = Conv(2 * c_, c2, 1, 1)
        self.m = nn.Sequential(*[Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)])

    def forward(self, x):
        y1 = self.cv3(self.m(self.cv1(x)))
        y2 = self.cv2(x)
        return self.cv4(torch.cat((y1, y2), dim=1))

class BottleneckCSPB(nn.Module):
    # CSP https://github.com/WongKinYiu/CrossStagePartialNetworks
    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super(BottleneckCSPB, self).__init__()
        c_ = int(c2)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1, 1)
        self.m = nn.Sequential(*[Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)])

    def forward(self, x):
        x1 = self.cv1(x)
        y1 = self.m(x1)
        y2 = self.cv2(x1)
        return self.cv3(torch.cat((y1, y2), dim=1))


class SP(nn.Module):
    def __init__(self, k=3, s=1):
        super(SP, self).__init__()
        self.m = nn.MaxPool2d(kernel_size=k, stride=s, padding=k // 2)

    def forward(self, x):
        return self.m(x)


class MP(nn.Module):
    def __init__(self, k=2):
        super(MP, self).__init__()
        self.m = nn.MaxPool2d(kernel_size=k, stride=k)

    def forward(self, x):
        return self.m(x)


class RepConv(nn.Module):
    # Represented convolution
    # https://arxiv.org/abs/2101.03697

    def __init__(self, c1, c2, k=3, s=1, p=None, g=1, act=True, deploy=False):
        super(RepConv, self).__init__()

        self.deploy = deploy
        self.groups = g
        self.in_channels = c1
        self.out_channels = c2

        assert k == 3
        assert autopad(k, p) == 1

        padding_11 = autopad(k, p) - k // 2

        self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())

        if deploy:
            self.rbr_reparam = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=True)

        else:
            self.rbr_identity = (nn.BatchNorm2d(num_features=c1) if c2 == c1 and s == 1 else None)

            self.rbr_dense = nn.Sequential(
                nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False),
                nn.BatchNorm2d(num_features=c2),
            )

            self.rbr_1x1 = nn.Sequential(
                nn.Conv2d(c1, c2, 1, s, padding_11, groups=g, bias=False),
                nn.BatchNorm2d(num_features=c2),
            )

    def forward(self, inputs):
        if hasattr(self, "rbr_reparam"):
            return self.act(self.rbr_reparam(inputs))

        if self.rbr_identity is None:
            id_out = 0
        else:
            id_out = self.rbr_identity(inputs)

        return self.act(self.rbr_dense(inputs) + self.rbr_1x1(inputs) + id_out)

    def get_equivalent_kernel_bias(self):
        kernel3x3, bias3x3 = self._fuse_bn_tensor(self.rbr_dense)
        kernel1x1, bias1x1 = self._fuse_bn_tensor(self.rbr_1x1)
        kernelid, biasid = self._fuse_bn_tensor(self.rbr_identity)
        return (
            kernel3x3 + self._pad_1x1_to_3x3_tensor(kernel1x1) + kernelid,
            bias3x3 + bias1x1 + biasid,
        )

    def _pad_1x1_to_3x3_tensor(self, kernel1x1):
        if kernel1x1 is None:
            return 0
        else:
            return nn.functional.pad(kernel1x1, [1, 1, 1, 1])

    def _fuse_bn_tensor(self, branch):
        if branch is None:
            return 0, 0
        if isinstance(branch, nn.Sequential):
            kernel = branch[0].weight
            running_mean = branch[1].running_mean
            running_var = branch[1].running_var
            gamma = branch[1].weight
            beta = branch[1].bias
            eps = branch[1].eps
        else:
            assert isinstance(branch, nn.BatchNorm2d)
            if not hasattr(self, "id_tensor"):
                input_dim = self.in_channels // self.groups
                kernel_value = np.zeros(
                    (self.in_channels, input_dim, 3, 3), dtype=np.float32
                )
                for i in range(self.in_channels):
                    kernel_value[i, i % input_dim, 1, 1] = 1
                self.id_tensor = torch.from_numpy(kernel_value).to(branch.weight.device)
            kernel = self.id_tensor
            running_mean = branch.running_mean
            running_var = branch.running_var
            gamma = branch.weight
            beta = branch.bias
            eps = branch.eps
        std = (running_var + eps).sqrt()
        t = (gamma / std).reshape(-1, 1, 1, 1)
        return kernel * t, beta - running_mean * gamma / std


# class SPPCSPC(nn.Module):
#     # CSP https://github.com/WongKinYiu/CrossStagePartialNetworks
#     def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5, k=(5, 9, 13)):
#         super(SPPCSPC, self).__init__()
#         c_ = int(2 * c2 * e)  # hidden channels
#         self.cv1 = Conv(c1, c_, 1, 1)
#         self.cv2 = Conv(c1, c_, 1, 1)
#         self.cv3 = Conv(c_, c_, 3, 1)
#         self.cv4 = Conv(c_, c_, 1, 1)
#         self.m = nn.ModuleList([nn.MaxPool2d(kernel_size=x, stride=1, padding=x // 2) for x in k])
#         self.cv5 = Conv(4 * c_, c_, 1, 1)
#         self.cv6 = Conv(c_, c_, 3, 1)
#         self.cv7 = Conv(2 * c_, c2, 1, 1)
#
#     def forward(self, x):
#         x1 = self.cv4(self.cv3(self.cv1(x)))
#         y1 = self.cv6(self.cv5(torch.cat([x1] + [m(x1) for m in self.m], 1)))
#         y2 = self.cv2(x)
#         return self.cv7(torch.cat((y1, y2), dim=1))






class myAPPCSPC(nn.Module):
    # 本代码由YOLOAir目标检测交流群 心动 大佬贡献
    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5, k=5):
        super(myAPPCSPC, self).__init__()
        c_ = int(2 * c2 * e)  # hidden channels  c_=c2
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(c_, c_, 3, 1)
        self.cv4 = Conv(c_, c_, 1, 1)
        # self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)
        # self.cv5 = Conv(4 * c_, c_, 1, 1)
        self.cv6 = Conv(c_, c_, 3, 1)
        self.cv7 = Conv(2 * c_, c2, 1, 1)
    def forward(self, x):
        x1 = self.cv4(self.cv3(self.cv1(x)))
        x2=ASPP(x1)  #c2=96
        y1 = self.cv6(x2)
        y2 = self.cv2(x)
        return self.cv7(torch.cat((y1, y2), dim=1))


class Focus(nn.Module):
    # Focus wh information into c-space
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        self.conv = Conv(c1 * 4, c2, k, s, p, g, act)
        # self.contract = Contract(gain=2)

    def forward(self, x):  # x(b,c,w,h) -> y(b,4c,w/2,h/2)
        return self.conv(torch.cat([x[..., ::2, ::2], x[..., 1::2, ::2], x[..., ::2, 1::2], x[..., 1::2, 1::2]], 1))
        # return self.conv(self.contract(x))


class GhostConv(nn.Module):
    # Ghost Convolution https://github.com/huawei-noah/ghostnet
    def __init__(self, c1, c2, k=1, s=1, g=1, act=True):  # ch_in, ch_out, kernel, stride, groups
        super().__init__()
        c_ = c2 // 2  # hidden channels
        # self.eca=ECALayer(c1)
        # self.cbam=CBAM(c1)
        # self.ecbam = ECBAM(c1)
        self.cv1 = Conv(c1, c_, k, s, None, g, act)  #c_是隐层，即降维后的层，是一个分离卷积
        # self.cv2 = RepVGGBlock(c_, c_, 5, 1,groups=c_)
        # self.cv2=DCNv2(c_, c_, 3, 1, groups=g)
        self.cv2 = Conv(c_, c_, 3, 1, None, c_, act)
    def forward(self, x):
        y = self.cv1(x)
        return torch.cat([y, self.cv2(y)], 1)


class GhostBottleneck(nn.Module):
    # Ghost Bottleneck https://github.com/huawei-noah/ghostnet
    def __init__(self, c1, c2, k=3, s=1):  # ch_in, ch_out, kernel, stride
        super().__init__()
        c_ = c2 // 2
        self.conv = nn.Sequential(GhostConv(c1, c_, 1, 1),  # pw
                                  DWConv(c_, c_, k, s, act=False) if s == 2 else nn.Identity(),  # dw
                                  GhostConv(c_, c2, 1, 1, act=False))  # pw-linear
        self.shortcut = nn.Sequential(DWConv(c1, c1, k, s, act=False),
                                      Conv(c1, c2, 1, 1, act=False)) if s == 2 else nn.Identity()
        # self._ECA = ECBAMBottleneck(c2, c2)
    def forward(self, x):
        return self.conv(x) + self.shortcut(x)
        # return self._ECA(self.conv(x) + self.shortcut(x))


class Contract(nn.Module):
    # Contract width-height into channels, i.e. x(1,64,80,80) to x(1,256,40,40)
    def __init__(self, gain=2):
        super().__init__()
        self.gain = gain

    def forward(self, x):
        b, c, h, w = x.size()  # assert (h / s == 0) and (W / s == 0), 'Indivisible gain'
        s = self.gain
        x = x.view(b, c, h // s, s, w // s, s)  # x(1,64,40,2,40,2)
        x = x.permute(0, 3, 5, 1, 2, 4).contiguous()  # x(1,2,2,64,40,40)
        return x.view(b, c * s * s, h // s, w // s)  # x(1,256,40,40)


class Expand(nn.Module):
    # Expand channels into width-height, i.e. x(1,64,80,80) to x(1,16,160,160)
    def __init__(self, gain=2):
        super().__init__()
        self.gain = gain

    def forward(self, x):
        b, c, h, w = x.size()  # assert C / s ** 2 == 0, 'Indivisible gain'
        s = self.gain
        x = x.view(b, s, s, c // s ** 2, h, w)  # x(1,2,2,16,80,80)
        x = x.permute(0, 3, 4, 1, 5, 2).contiguous()  # x(1,16,80,2,80,2)
        return x.view(b, c // s ** 2, h * s, w * s)  # x(1,16,160,160)


# class Concat1(nn.Module):
#     # Concatenate a list of tensors along dimension
#     def __init__(self, dimension=1):
#         super().__init__()
#         self.d = dimension
#
#     def forward(self, x):
#         return torch.cat(x, self.d)

class Concat(nn.Module):
    # Concatenate a list of tensors along dimension
    def __init__(self, dimension=1):
        super().__init__()
        self.d = dimension
        self.w1 = nn.Parameter(torch.ones(2, dtype=torch.float32), requires_grad=True)
        self.w2 = nn.Parameter(torch.ones(3, dtype=torch.float32), requires_grad=True)
        # self.se = SELayer(2*c2)
    def forward(self, x):
        # x = torch.cat(x, self.d)
        # x = self.se(x)
        if(len(x)==2):
            weights = self.w1

            x1 = x[0]*weights[0]
            x2 = x[1]*weights[1]
            x = [x1,x2]

        if (len(x) == 3):
            weights = self.w2
            x1 = x[0] * weights[0]
            x2 = x[1] * weights[1]
            x3 = x[2] * weights[2]
            x = [x1, x2, x3]

        return torch.cat(x, self.d)
        return x

class Concat_ADD(nn.Module):
    # Concatenate a list of tensors along dimension
    def __init__(self, dimension=1):
        super().__init__()
        self.d = dimension

    def forward(self, x):
        x1=(x[0]+x[1]+x[2]+x[3])/4
        x=[x[0],x[1],x[2],x[3],x1]
        return torch.cat(x, self.d)

class GAM_Attention(nn.Module):
    def __init__(self, in_channels, out_channels, rate=4):
        super(GAM_Attention, self).__init__()

        self.channel_attention = nn.Sequential(
            nn.Linear(in_channels, int(in_channels / rate)),
            nn.ReLU(inplace=True),
            nn.Linear(int(in_channels / rate), in_channels)
        )

        self.spatial_attention = nn.Sequential(
            nn.Conv2d(in_channels, int(in_channels / rate), kernel_size=7, padding=3),
            nn.BatchNorm2d(int(in_channels / rate)),
            nn.ReLU(inplace=True),
            nn.Conv2d(int(in_channels / rate), out_channels, kernel_size=7, padding=3),
            nn.BatchNorm2d(out_channels)
        )

    def forward(self, x):
        b, c, h, w = x.shape
        x_permute = x.permute(0, 2, 3, 1).view(b, -1, c)
        x_att_permute = self.channel_attention(x_permute).view(b, h, w, c)
        x_channel_att = x_att_permute.permute(0, 3, 1, 2)

        x = x * x_channel_att

        x_spatial_att = self.spatial_attention(x).sigmoid()
        out = x * x_spatial_att

        return out

class Concat_fuse_new(nn.Module):
    # Concatenate a list of tensors along dimension
    def __init__(self, dimension=1):
        super().__init__()
        self.d = dimension
        self.w1 = nn.Parameter(torch.ones(2, dtype=torch.float32), requires_grad=True)
        self.w2 = nn.Parameter(torch.ones(3, dtype=torch.float32), requires_grad=True)
    def forward(self, x):

        if(len(x)==2):
            weights = self.w1
            x1 = x[0]*weights[0]
            x2 = x[1]*weights[1]
            x = [x1,x2]

        if (len(x) == 3):
            weights = self.w2
            x1 = x[0] * weights[0]
            x2 = x[1] * weights[1]
            x3 = x[2] * weights[2]
            x = [x1, x2, x3]

        return torch.cat(x, self.d)


class Concat_fliter(nn.Module):
    # Concatenate a list of tensors along dimension
    def __init__(self,c,dimension=1):
        super().__init__()
        # self.attention = GAM_Attention(c,c)
        self.d = dimension
        # self.attention = SELayer(c)
        self.attention = Conv_CBAM1(c,c)
        # self.attention = CoordAtt(c,c)
        self.w1 = nn.Parameter(torch.ones(2, dtype=torch.float32), requires_grad=True)
        self.w2 = nn.Parameter(torch.ones(3, dtype=torch.float32), requires_grad=True)
    def forward(self, x):

        if(len(x)==2):
            weights = self.w1
            x2 = self.attention(x[1])
            x1 = x[0]*weights[0]
            x2 = x2 * weights[1]  #深层特征需要得到滤波
            x = [x1,x2]

            # x2 = self.attention(x[1])
            # x = [x[0], x2]

        if (len(x) == 3):
            weights = self.w2
            x3 = self.attention(x[2])  #深层特征需要得到滤波
            x1 = x[0] * weights[0]
            x2 = x[1] * weights[1]
            x3 = x3 * weights[2]
            x = [x1, x2, x3]

            # x3 = self.attention(x[2])  # 深层特征需要得到滤波
            # x = [x[0], x[1], x3]

        return torch.cat(x, self.d)

class Concat_fliter_attention(nn.Module):
    # Concatenate a list of tensors along dimension
    def __init__(self,c,dimension=1):
        super().__init__()
        # self.attention = GAM_Attention(c,c)
        self.d = dimension
        # self.attention = SELayer(c)
        self.attention = Conv_CBAM_xisu(c,c)
        # self.attention = CoordAtt(c,c)
        self.w1 = nn.Parameter(torch.ones(2, dtype=torch.float32), requires_grad=True)
        self.w2 = nn.Parameter(torch.ones(3, dtype=torch.float32), requires_grad=True)
    def forward(self, x):

        if(len(x)==2):
            weights = self.w1
            aw1,aw2 = self.attention(x[0])
            x1 = x[0]*weights[0]
            x2 = x[1] * aw1 * aw2 * weights[1]  #深层特征需要得到滤波
            x = [x1,x2]

        if (len(x) == 3):
            weights = self.w2
            aw1,aw2 = self.attention(torch.cat([x[0],x[1]],dim=1))  #深层特征需要得到滤波
            x1 = x[0] * weights[0]
            x2 = x[1] * weights[1]
            x3 = x[2] * aw1 * aw2 * weights[2]
            x = [x1, x2, x3]

        return torch.cat(x, self.d)

class Concat_BIF(nn.Module):
    # Concatenate a list of tensors along dimension
    def __init__(self, dimension=1):
        super().__init__()
        self.d = dimension
        self.w = nn.Parameter(torch.ones(4, dtype=torch.float32), requires_grad=True)
        self.epsilon = 0.0001
    def forward(self, x):
        w = self.w
        weight = w / (torch.sum(w, dim=0) + self.epsilon)  # 将权重进行归一化
        x = [weight[0] * x[0], weight[1] * x[1], weight[2] * x[2],weight[3] * x[3]]
        return torch.cat(x, self.d)

class ADD(nn.Module):
    # Concatenate a list of tensors along dimension
    def __init__(self, dimension=1):
        super().__init__()
        self.d = dimension
        self.w = nn.Parameter(torch.ones(4, dtype=torch.float32), requires_grad=True)
        self.epsilon = 0.0001

    def forward(self, x):
        w = self.w
        weight = w / (torch.sum(w, dim=0) + self.epsilon)  # 将权重进行归一化
        y=x[0]*weight[0]
        for i in range(1,len(x)):
                y=y+x[i]*weight[i]
        return y
# class ADD(nn.Module):
#     # Concatenate a list of tensors along dimension
#     def __init__(self, dimension=1):
#         super().__init__()
#         self.d = dimension
#
#     def forward(self, x):
#         y=x[0]
#         for i in range(1,len(x)):
#                 y=y+x[i]
#         return y
class DetectMultiBackend(nn.Module):
    # YOLOv5 MultiBackend class for python inference on various backends
    def __init__(self, weights='yolov5s.pt', device=None, dnn=False, data=None):
        # Usage:
        #   PyTorch:              weights = *.pt
        #   TorchScript:                    *.torchscript
        #   ONNX Runtime:                   *.onnx
        #   ONNX OpenCV DNN:                *.onnx with --dnn
        #   OpenVINO:                       *.xml
        #   CoreML:                         *.mlmodel
        #   TensorRT:                       *.engine
        #   TensorFlow SavedModel:          *_saved_model
        #   TensorFlow GraphDef:            *.pb
        #   TensorFlow Lite:                *.tflite
        #   TensorFlow Edge TPU:            *_edgetpu.tflite
        from models.experimental import attempt_download, attempt_load  # scoped to avoid circular import

        super().__init__()
        w = str(weights[0] if isinstance(weights, list) else weights)
        pt, jit, onnx, xml, engine, coreml, saved_model, pb, tflite, edgetpu, tfjs = self.model_type(w)  # get backend
        stride, names = 64, [f'class{i}' for i in range(1000)]  # assign defaults
        w = attempt_download(w)  # download if not local
        if data:  # data.yaml path (optional)
            with open(data, errors='ignore') as f:
                names = yaml.safe_load(f)['names']  # class names

        if pt:  # PyTorch
            model = attempt_load(weights if isinstance(weights, list) else w, map_location=device)
            stride = max(int(model.stride.max()), 32)  # model stride
            names = model.module.names if hasattr(model, 'module') else model.names  # get class names
            self.model = model  # explicitly assign for to(), cpu(), cuda(), half()
        elif jit:  # TorchScript
            LOGGER.info(f'Loading {w} for TorchScript inference...')
            extra_files = {'config.txt': ''}  # model metadata
            model = torch.jit.load(w, _extra_files=extra_files)
            if extra_files['config.txt']:
                d = json.loads(extra_files['config.txt'])  # extra_files dict
                stride, names = int(d['stride']), d['names']
        elif dnn:  # ONNX OpenCV DNN
            LOGGER.info(f'Loading {w} for ONNX OpenCV DNN inference...')
            check_requirements(('opencv-python>=4.5.4',))
            net = cv2.dnn.readNetFromONNX(w)
        elif onnx:  # ONNX Runtime
            LOGGER.info(f'Loading {w} for ONNX Runtime inference...')
            cuda = torch.cuda.is_available()
            check_requirements(('onnx', 'onnxruntime-gpu' if cuda else 'onnxruntime'))
            import onnxruntime
            providers = ['CUDAExecutionProvider', 'CPUExecutionProvider'] if cuda else ['CPUExecutionProvider']
            session = onnxruntime.InferenceSession(w, providers=providers)
        elif xml:  # OpenVINO
            LOGGER.info(f'Loading {w} for OpenVINO inference...')
            check_requirements(('openvino-dev',))  # requires openvino-dev: https://pypi.org/project/openvino-dev/
            import openvino.inference_engine as ie
            core = ie.IECore()
            if not Path(w).is_file():  # if not *.xml
                w = next(Path(w).glob('*.xml'))  # get *.xml file from *_openvino_model dir
            network = core.read_network(model=w, weights=Path(w).with_suffix('.bin'))  # *.xml, *.bin paths
            executable_network = core.load_network(network, device_name='CPU', num_requests=1)
        elif engine:  # TensorRT
            LOGGER.info(f'Loading {w} for TensorRT inference...')
            import tensorrt as trt  # https://developer.nvidia.com/nvidia-tensorrt-download
            check_version(trt.__version__, '7.0.0', hard=True)  # require tensorrt>=7.0.0
            Binding = namedtuple('Binding', ('name', 'dtype', 'shape', 'data', 'ptr'))
            logger = trt.Logger(trt.Logger.INFO)
            with open(w, 'rb') as f, trt.Runtime(logger) as runtime:
                model = runtime.deserialize_cuda_engine(f.read())
            bindings = OrderedDict()
            for index in range(model.num_bindings):
                name = model.get_binding_name(index)
                dtype = trt.nptype(model.get_binding_dtype(index))
                shape = tuple(model.get_binding_shape(index))
                data = torch.from_numpy(np.empty(shape, dtype=np.dtype(dtype))).to(device)
                bindings[name] = Binding(name, dtype, shape, data, int(data.data_ptr()))
            binding_addrs = OrderedDict((n, d.ptr) for n, d in bindings.items())
            context = model.create_execution_context()
            batch_size = bindings['images'].shape[0]
        elif coreml:  # CoreML
            LOGGER.info(f'Loading {w} for CoreML inference...')
            import coremltools as ct
            model = ct.models.MLModel(w)
        else:  # TensorFlow (SavedModel, GraphDef, Lite, Edge TPU)
            if saved_model:  # SavedModel
                LOGGER.info(f'Loading {w} for TensorFlow SavedModel inference...')
                import tensorflow as tf
                keras = False  # assume TF1 saved_model
                model = tf.keras.models.load_model(w) if keras else tf.saved_model.load(w)
            elif pb:  # GraphDef https://www.tensorflow.org/guide/migrate#a_graphpb_or_graphpbtxt
                LOGGER.info(f'Loading {w} for TensorFlow GraphDef inference...')
                import tensorflow as tf

                def wrap_frozen_graph(gd, inputs, outputs):
                    x = tf.compat.v1.wrap_function(lambda: tf.compat.v1.import_graph_def(gd, name=""), [])  # wrapped
                    ge = x.graph.as_graph_element
                    return x.prune(tf.nest.map_structure(ge, inputs), tf.nest.map_structure(ge, outputs))

                gd = tf.Graph().as_graph_def()  # graph_def
                gd.ParseFromString(open(w, 'rb').read())
                frozen_func = wrap_frozen_graph(gd, inputs="x:0", outputs="Identity:0")
            elif tflite or edgetpu:  # https://www.tensorflow.org/lite/guide/python#install_tensorflow_lite_for_python
                try:  # https://coral.ai/docs/edgetpu/tflite-python/#update-existing-tf-lite-code-for-the-edge-tpu
                    from tflite_runtime.interpreter import Interpreter, load_delegate
                except ImportError:
                    import tensorflow as tf
                    Interpreter, load_delegate = tf.lite.Interpreter, tf.lite.experimental.load_delegate,
                if edgetpu:  # Edge TPU https://coral.ai/software/#edgetpu-runtime
                    LOGGER.info(f'Loading {w} for TensorFlow Lite Edge TPU inference...')
                    delegate = {'Linux': 'libedgetpu.so.1',
                                'Darwin': 'libedgetpu.1.dylib',
                                'Windows': 'edgetpu.dll'}[platform.system()]
                    interpreter = Interpreter(model_path=w, experimental_delegates=[load_delegate(delegate)])
                else:  # Lite
                    LOGGER.info(f'Loading {w} for TensorFlow Lite inference...')
                    interpreter = Interpreter(model_path=w)  # load TFLite model
                interpreter.allocate_tensors()  # allocate
                input_details = interpreter.get_input_details()  # inputs
                output_details = interpreter.get_output_details()  # outputs
            elif tfjs:
                raise Exception('ERROR: YOLOv5 TF.js inference is not supported')
        self.__dict__.update(locals())  # assign all variables to self

    def forward(self, im, augment=False, visualize=False, val=False):
        # YOLOv5 MultiBackend inference
        b, ch, h, w = im.shape  # batch, channel, height, width
        if self.pt or self.jit:  # PyTorch
            y = self.model(im) if self.jit else self.model(im, augment=augment, visualize=visualize)
            return y if val else y[0]
        elif self.dnn:  # ONNX OpenCV DNN
            im = im.cpu().numpy()  # torch to numpy
            self.net.setInput(im)
            y = self.net.forward()
        elif self.onnx:  # ONNX Runtime
            im = im.cpu().numpy()  # torch to numpy
            y = self.session.run([self.session.get_outputs()[0].name], {self.session.get_inputs()[0].name: im})[0]
        elif self.xml:  # OpenVINO
            im = im.cpu().numpy()  # FP32
            desc = self.ie.TensorDesc(precision='FP32', dims=im.shape, layout='NCHW')  # Tensor Description
            request = self.executable_network.requests[0]  # inference request
            request.set_blob(blob_name='images', blob=self.ie.Blob(desc, im))  # name=next(iter(request.input_blobs))
            request.infer()
            y = request.output_blobs['output'].buffer  # name=next(iter(request.output_blobs))
        elif self.engine:  # TensorRT
            assert im.shape == self.bindings['images'].shape, (im.shape, self.bindings['images'].shape)
            self.binding_addrs['images'] = int(im.data_ptr())
            self.context.execute_v2(list(self.binding_addrs.values()))
            y = self.bindings['output'].data
        elif self.coreml:  # CoreML
            im = im.permute(0, 2, 3, 1).cpu().numpy()  # torch BCHW to numpy BHWC shape(1,320,192,3)
            im = Image.fromarray((im[0] * 255).astype('uint8'))
            # im = im.resize((192, 320), Image.ANTIALIAS)
            y = self.model.predict({'image': im})  # coordinates are xywh normalized
            if 'confidence' in y:
                box = xywh2xyxy(y['coordinates'] * [[w, h, w, h]])  # xyxy pixels
                conf, cls = y['confidence'].max(1), y['confidence'].argmax(1).astype(np.float)
                y = np.concatenate((box, conf.reshape(-1, 1), cls.reshape(-1, 1)), 1)
            else:
                k = 'var_' + str(sorted(int(k.replace('var_', '')) for k in y)[-1])  # output key
                y = y[k]  # output
        else:  # TensorFlow (SavedModel, GraphDef, Lite, Edge TPU)
            im = im.permute(0, 2, 3, 1).cpu().numpy()  # torch BCHW to numpy BHWC shape(1,320,192,3)
            if self.saved_model:  # SavedModel
                y = (self.model(im, training=False) if self.keras else self.model(im)[0]).numpy()
            elif self.pb:  # GraphDef
                y = self.frozen_func(x=self.tf.constant(im)).numpy()
            else:  # Lite or Edge TPU
                input, output = self.input_details[0], self.output_details[0]
                int8 = input['dtype'] == np.uint8  # is TFLite quantized uint8 model
                if int8:
                    scale, zero_point = input['quantization']
                    im = (im / scale + zero_point).astype(np.uint8)  # de-scale
                self.interpreter.set_tensor(input['index'], im)
                self.interpreter.invoke()
                y = self.interpreter.get_tensor(output['index'])
                if int8:
                    scale, zero_point = output['quantization']
                    y = (y.astype(np.float32) - zero_point) * scale  # re-scale
            y[..., :4] *= [w, h, w, h]  # xywh normalized to pixels

        y = torch.tensor(y) if isinstance(y, np.ndarray) else y
        return (y, []) if val else y

    def warmup(self, imgsz=(1, 3, 640, 640), half=False):
        # Warmup model by running inference once
        if self.pt or self.jit or self.onnx or self.engine:  # warmup types
            if isinstance(self.device, torch.device) and self.device.type != 'cpu':  # only warmup GPU models
                im = torch.zeros(*imgsz).to(self.device).type(torch.half if half else torch.float)  # input image
                self.forward(im)  # warmup

    @staticmethod
    def model_type(p='path/to/model.pt'):
        # Return model type from model path, i.e. path='path/to/model.onnx' -> type=onnx
        from export import export_formats
        suffixes = list(export_formats().Suffix) + ['.xml']  # export suffixes
        check_suffix(p, suffixes)  # checks
        p = Path(p).name  # eliminate trailing separators
        pt, jit, onnx, xml, engine, coreml, saved_model, pb, tflite, edgetpu, tfjs, xml2 = (s in p for s in suffixes)
        xml |= xml2  # *_openvino_model or *.xml
        tflite &= not edgetpu  # *.tflite
        return pt, jit, onnx, xml, engine, coreml, saved_model, pb, tflite, edgetpu, tfjs


class AutoShape(nn.Module):
    # YOLOv5 input-robust model wrapper for passing cv2/np/PIL/torch inputs. Includes preprocessing, inference and NMS
    conf = 0.25  # NMS confidence threshold
    iou = 0.45  # NMS IoU threshold
    agnostic = False  # NMS class-agnostic
    multi_label = False  # NMS multiple labels per box
    classes = None  # (optional list) filter by class, i.e. = [0, 15, 16] for COCO persons, cats and dogs
    max_det = 1000  # maximum number of detections per image
    amp = False  # Automatic Mixed Precision (AMP) inference

    def __init__(self, model):
        super().__init__()
        LOGGER.info('Adding AutoShape... ')
        copy_attr(self, model, include=('yaml', 'nc', 'hyp', 'names', 'stride', 'abc'), exclude=())  # copy attributes
        self.dmb = isinstance(model, DetectMultiBackend)  # DetectMultiBackend() instance
        self.pt = not self.dmb or model.pt  # PyTorch model
        self.model = model.eval()

    def _apply(self, fn):
        # Apply to(), cpu(), cuda(), half() to model tensors that are not parameters or registered buffers
        self = super()._apply(fn)
        if self.pt:
            m = self.model.model.model[-1] if self.dmb else self.model.model[-1]  # Detect()
            m.stride = fn(m.stride)
            m.grid = list(map(fn, m.grid))
            if isinstance(m.anchor_grid, list):
                m.anchor_grid = list(map(fn, m.anchor_grid))
        return self

    @torch.no_grad()
    def forward(self, imgs, size=640, augment=False, profile=False):
        # Inference from various sources. For height=640, width=1280, RGB images example inputs are:
        #   file:       imgs = 'data/images/zidane.jpg'  # str or PosixPath
        #   URI:             = 'https://ultralytics.com/images/zidane.jpg'
        #   OpenCV:          = cv2.imread('image.jpg')[:,:,::-1]  # HWC BGR to RGB x(640,1280,3)
        #   PIL:             = Image.open('image.jpg') or ImageGrab.grab()  # HWC x(640,1280,3)
        #   numpy:           = np.zeros((640,1280,3))  # HWC
        #   torch:           = torch.zeros(16,3,320,640)  # BCHW (scaled to size=640, 0-1 values)
        #   multiple:        = [Image.open('image1.jpg'), Image.open('image2.jpg'), ...]  # list of images

        t = [time_sync()]
        p = next(self.model.parameters()) if self.pt else torch.zeros(1)  # for device and type
        autocast = self.amp and (p.device.type != 'cpu')  # Automatic Mixed Precision (AMP) inference
        if isinstance(imgs, torch.Tensor):  # torch
            with amp.autocast(enabled=autocast):
                return self.model(imgs.to(p.device).type_as(p), augment, profile)  # inference

        # Pre-process
        n, imgs = (len(imgs), imgs) if isinstance(imgs, list) else (1, [imgs])  # number of images, list of images
        shape0, shape1, files = [], [], []  # image and inference shapes, filenames
        for i, im in enumerate(imgs):
            f = f'image{i}'  # filename
            if isinstance(im, (str, Path)):  # filename or uri
                im, f = Image.open(requests.get(im, stream=True).raw if str(im).startswith('http') else im), im
                im = np.asarray(exif_transpose(im))
            elif isinstance(im, Image.Image):  # PIL Image
                im, f = np.asarray(exif_transpose(im)), getattr(im, 'filename', f) or f
            files.append(Path(f).with_suffix('.jpg').name)
            if im.shape[0] < 5:  # image in CHW
                im = im.transpose((1, 2, 0))  # reverse dataloader .transpose(2, 0, 1)
            im = im[..., :3] if im.ndim == 3 else np.tile(im[..., None], 3)  # enforce 3ch input
            s = im.shape[:2]  # HWC
            shape0.append(s)  # image shape
            g = (size / max(s))  # gain
            shape1.append([y * g for y in s])
            imgs[i] = im if im.data.contiguous else np.ascontiguousarray(im)  # update
        shape1 = [make_divisible(x, self.stride) for x in np.stack(shape1, 0).max(0)]  # inference shape
        x = [letterbox(im, new_shape=shape1 if self.pt else size, auto=False)[0] for im in imgs]  # pad
        x = np.stack(x, 0) if n > 1 else x[0][None]  # stack
        x = np.ascontiguousarray(x.transpose((0, 3, 1, 2)))  # BHWC to BCHW
        x = torch.from_numpy(x).to(p.device).type_as(p) / 255  # uint8 to fp16/32
        t.append(time_sync())

        with amp.autocast(enabled=autocast):
            # Inference
            y = self.model(x, augment, profile)  # forward
            t.append(time_sync())

            # Post-process
            y = non_max_suppression(y if self.dmb else y[0], self.conf, iou_thres=self.iou, classes=self.classes,
                                    agnostic=self.agnostic, multi_label=self.multi_label, max_det=self.max_det)  # NMS
            for i in range(n):
                scale_coords(shape1, y[i][:, :4], shape0[i])

            t.append(time_sync())
            return Detections(imgs, y, files, t, self.names, x.shape)


class Detections:
    # YOLOv5 detections class for inference results
    def __init__(self, imgs, pred, files, times=(0, 0, 0, 0), names=None, shape=None):
        super().__init__()
        d = pred[0].device  # device
        gn = [torch.tensor([*(im.shape[i] for i in [1, 0, 1, 0]), 1, 1], device=d) for im in imgs]  # normalizations
        self.imgs = imgs  # list of images as numpy arrays
        self.pred = pred  # list of tensors pred[0] = (xyxy, conf, cls)
        self.names = names  # class names
        self.files = files  # image filenames
        self.times = times  # profiling times
        self.xyxy = pred  # xyxy pixels
        self.xywh = [xyxy2xywh(x) for x in pred]  # xywh pixels
        self.xyxyn = [x / g for x, g in zip(self.xyxy, gn)]  # xyxy normalized
        self.xywhn = [x / g for x, g in zip(self.xywh, gn)]  # xywh normalized
        self.n = len(self.pred)  # number of images (batch size)
        self.t = tuple((times[i + 1] - times[i]) * 1000 / self.n for i in range(3))  # timestamps (ms)
        self.s = shape  # inference BCHW shape

    def display(self, pprint=False, show=False, save=False, crop=False, render=False, save_dir=Path('')):
        crops = []
        for i, (im, pred) in enumerate(zip(self.imgs, self.pred)):
            s = f'image {i + 1}/{len(self.pred)}: {im.shape[0]}x{im.shape[1]} '  # string
            if pred.shape[0]:
                for c in pred[:, -1].unique():
                    n = (pred[:, -1] == c).sum()  # detections per class
                    s += f"{n} {self.names[int(c)]}{'s' * (n > 1)}, "  # add to string
                if show or save or render or crop:
                    annotator = Annotator(im, example=str(self.names))
                    for *box, conf, cls in reversed(pred):  # xyxy, confidence, class
                        label = f'{self.names[int(cls)]} {conf:.2f}'
                        if crop:
                            file = save_dir / 'crops' / self.names[int(cls)] / self.files[i] if save else None
                            crops.append({'box': box, 'conf': conf, 'cls': cls, 'label': label,
                                          'im': save_one_box(box, im, file=file, save=save)})
                        else:  # all others
                            annotator.box_label(box, label, color=colors(cls))
                    im = annotator.im
            else:
                s += '(no detections)'

            im = Image.fromarray(im.astype(np.uint8)) if isinstance(im, np.ndarray) else im  # from np
            if pprint:
                LOGGER.info(s.rstrip(', '))
            if show:
                im.show(self.files[i])  # show
            if save:
                f = self.files[i]
                im.save(save_dir / f)  # save
                if i == self.n - 1:
                    LOGGER.info(f"Saved {self.n} image{'s' * (self.n > 1)} to {colorstr('bold', save_dir)}")
            if render:
                self.imgs[i] = np.asarray(im)
        if crop:
            if save:
                LOGGER.info(f'Saved results to {save_dir}\n')
            return crops

    def print(self):
        self.display(pprint=True)  # print results
        LOGGER.info(f'Speed: %.1fms pre-process, %.1fms inference, %.1fms NMS per image at shape {tuple(self.s)}' %
                    self.t)

    def show(self):
        self.display(show=True)  # show results

    def save(self, save_dir='runs/detect/exp'):
        save_dir = increment_path(save_dir, exist_ok=save_dir != 'runs/detect/exp', mkdir=True)  # increment save_dir
        self.display(save=True, save_dir=save_dir)  # save results

    def crop(self, save=True, save_dir='runs/detect/exp'):
        save_dir = increment_path(save_dir, exist_ok=save_dir != 'runs/detect/exp', mkdir=True) if save else None
        return self.display(crop=True, save=save, save_dir=save_dir)  # crop results

    def render(self):
        self.display(render=True)  # render results
        return self.imgs

    def pandas(self):
        # return detections as pandas DataFrames, i.e. print(results.pandas().xyxy[0])
        new = copy(self)  # return copy
        ca = 'xmin', 'ymin', 'xmax', 'ymax', 'confidence', 'class', 'name'  # xyxy columns
        cb = 'xcenter', 'ycenter', 'width', 'height', 'confidence', 'class', 'name'  # xywh columns
        for k, c in zip(['xyxy', 'xyxyn', 'xywh', 'xywhn'], [ca, ca, cb, cb]):
            a = [[x[:5] + [int(x[5]), self.names[int(x[5])]] for x in x.tolist()] for x in getattr(self, k)]  # update
            setattr(new, k, [pd.DataFrame(x, columns=c) for x in a])
        return new

    def tolist(self):
        # return a list of Detections objects, i.e. 'for result in results.tolist():'
        r = range(self.n)  # iterable
        x = [Detections([self.imgs[i]], [self.pred[i]], [self.files[i]], self.times, self.names, self.s) for i in r]
        # for d in x:
        #    for k in ['imgs', 'pred', 'xyxy', 'xyxyn', 'xywh', 'xywhn']:
        #        setattr(d, k, getattr(d, k)[0])  # pop out of list
        return x

    def __len__(self):
        return self.n


class Classify(nn.Module):
    # Classification head, i.e. x(b,c1,20,20) to x(b,c2)
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        self.aap = nn.AdaptiveAvgPool2d(1)  # to x(b,c1,1,1)
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g)  # to x(b,c2,1,1)
        self.flat = nn.Flatten()

    def forward(self, x):
        z = torch.cat([self.aap(y) for y in (x if isinstance(x, list) else [x])], 1)  # cat if list
        return self.flat(self.conv(z))  # flatten to x(b,c2)

# class SELayer(nn.Module):
#     def __init__(self, c1, r=16):
#         super(SELayer, self).__init__(class
#         self.avgpool = nn.AdaptiveAvgPool2d(1)
#         self.l1 = nn.Linear(c1, c1 // r, bias=False)
#         self.relu = nn.ReLU(inplace=True)
#         self.l2 = nn.Linear(c1 // r, c1, bias=False)
#         self.sig = nn.Sigmoid()
#
#     def forward(self, x):
#         b, c, _, _ = x.size()
#         y = self.avgpool(x).view(b, c)
#         y = self.l1(y)
#         y = self.relu(y)
#         y = self.l2(y)
#         y = self.sig(y)
#         y = y.view(b, c, 1, 1)
#         return x * y.expand_as(x)

#轻量化
# ---------------------------- MobileBlock start -------------------------------
# ---------------------------- MobileBlock start -------------------------------
class h_sigmoid(nn.Module):
    def __init__(self, inplace=True):
        super(h_sigmoid, self).__init__()
        self.relu = nn.ReLU6(inplace=inplace)

    def forward(self, x):
        return self.relu(x + 3) / 6


class h_swish(nn.Module):
    def __init__(self, inplace=True):
        super(h_swish, self).__init__()
        self.sigmoid = h_sigmoid(inplace=inplace)

    def forward(self, x):
        return x * self.sigmoid(x)
        # return x*nn.ReLU6(x+3)/6


class SELayer(nn.Module):
    def __init__(self, channel, reduction=4):
        super(SELayer, self).__init__()
        # Squeeze操作
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # Excitation操作(FC+ReLU+FC+Sigmoid)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel),
            h_sigmoid()
            # nn.Sigmoid()
            # nn.SiLU()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x)
        y = y.view(b, c)
        y = self.fc(y).view(b, c, 1, 1)  # 学习到的每一channel的权重
        return x * y


class conv_bn_hswish(nn.Module):
    """
    This equals to
    def conv_3x3_bn(inp, oup, stride):
        return nn.Sequential(
            nn.Conv2d(inp, oup, 3, stride, 1, bias=False),
            nn.BatchNorm2d(oup),
            h_swish()
        )
    """

    def __init__(self, c1, c2, stride):
        super(conv_bn_hswish, self).__init__()
        self.conv = nn.Conv2d(c1, c2, 3, stride, 1, bias=False)
        # self.conv = DSConv2D(c1, c2, 3, 1, g=1)
        self.bn = nn.BatchNorm2d(c2)
        self.act = h_swish()

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))

    def fuseforward(self, x):
        return self.act(self.conv(x))

    def forward_fuse(self, x):
        return self.act(self.conv(x))

class ECALayer(nn.Module):
    def __init__(self, channel, b=1, gamma=2):
        super(ECALayer, self).__init__()
        kernel_size = int(abs((math.log(channel, 2) + b) / gamma))
        kernel_size = kernel_size if kernel_size % 2 else kernel_size + 1

        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=kernel_size, padding=(kernel_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        y = self.avg_pool(x)
        y = self.conv(y.squeeze(-1).transpose(-1, -2)).transpose(-1, -2).unsqueeze(-1)
        y = self.sigmoid(y)
        return x * y.expand_as(x)


class myMobileNet_Block(nn.Module):
    def __init__(self, inp, oup, hidden_dim, kernel_size, stride, use_se, use_hs):
        super(myMobileNet_Block, self).__init__()
        assert stride in [1, 2]
        self.myinp=inp
        self.myhidden_dim=hidden_dim
        self.dim_conv3 = hidden_dim // 2
        self.dim_untouched = hidden_dim - self.dim_conv3
        self.identity = stride == 1 and inp == oup
        self.pw1=nn.Sequential(
            nn.Conv2d(inp, hidden_dim, 1, 1, 0, bias=False),
            nn.BatchNorm2d(hidden_dim),
            h_swish() if use_hs else nn.ReLU(inplace=True),
        )
        self.dw3x3=nn.Sequential(
            nn.Conv2d(hidden_dim, hidden_dim, kernel_size, stride, (kernel_size - 1) // 2, groups=hidden_dim,
                      bias=False),
            nn.BatchNorm2d(hidden_dim)
        )
        self.pw2 = nn.Sequential(
            nn.Conv2d(hidden_dim, oup, 1, 1, 0, bias=False),
            nn.BatchNorm2d(oup),
        )
        self.se = SELayer(hidden_dim) if use_se else nn.Sequential()
        self.myhish = h_swish() if use_hs else nn.ReLU(inplace=True)
    def forward(self, x):
        if self.myinp == self.myhidden_dim:
            x1, x2 = torch.split(x, [self.dim_conv3, self.dim_untouched], dim=1)
            dwx1 = self.dw3x3(x1)
            dwx2 = self.dw3x3(x1)
            dwx3 = self.dw3x3(x1)
            dwx4 = self.dw3x3(x1)
            dwx5 = self.dw3x3(x1)
            dwxout = dwx1 + dwx2 + dwx3 + dwx4 + dwx5
            swx = self.myhish(dwxout)
            sex = self.se(swx)
            catx = torch.cat([sex, x2], 1)
            shufflex = channel_shuffle(catx, 2)
            outx = self.pw2(shufflex)
        else:
            x = self.pw1(x)
            x1, x2 = torch.split(x, [self.dim_conv3, self.dim_untouched], dim=1)
            dwx1 = self.dw3x3(x1)
            dwx2 = self.dw3x3(x1)
            dwx3 = self.dw3x3(x1)
            dwx4 = self.dw3x3(x1)
            dwx5 = self.dw3x3(x1)
            dwxout = dwx1 + dwx2 + dwx3 + dwx4 + dwx5
            sex = self.se(dwxout)
            swx = self.myhish(sex)
            catx = torch.cat([swx, x2], 1)
            shufflex = channel_shuffle(catx, 2)
            outx = self.pw2(shufflex)
        if self.identity:
            return x + outx
        else:
            return outx

class MobileNet_Block(nn.Module):
    def __init__(self, inp, oup, hidden_dim, kernel_size, stride, use_se, use_hs):
        super(MobileNet_Block, self).__init__()
        assert stride in [1, 2]

        self.identity = stride == 1 and inp == oup

        # 输入通道数=扩张通道数 则不进行通道扩张
        if inp == hidden_dim:
            self.conv = nn.Sequential(
                # dw
                nn.Conv2d(hidden_dim, hidden_dim, kernel_size, stride, (kernel_size - 1) // 2, groups=hidden_dim,
                          bias=False),
                nn.BatchNorm2d(hidden_dim),
                h_swish() if use_hs else nn.ReLU(inplace=True),
                # Squeeze-and-Excite
                ECALayer(hidden_dim) if use_se else nn.Sequential(),
                # pw-linear
                # CoordAtt(hidden_dim, hidden_dim),
                nn.Conv2d(hidden_dim, oup, 1, 1, 0, bias=False),
                nn.BatchNorm2d(oup),
                # myConv(hidden_dim, oup, 1, 1, 0)

            )
        else:
            # 否则 先进行通道扩张
            self.conv = nn.Sequential(
                # pw
                nn.Conv2d(inp, hidden_dim, 1, 1, 0, bias=False),
                nn.BatchNorm2d(hidden_dim),
                h_swish() if use_hs else nn.ReLU(inplace=True),
                # dw
                nn.Conv2d(hidden_dim, hidden_dim, kernel_size, stride, (kernel_size - 1) // 2, groups=hidden_dim,
                          bias=False),
                nn.BatchNorm2d(hidden_dim),
                # Squeeze-and-Excite
                ECALayer(hidden_dim) if use_se else nn.Sequential(),
                CoordAtt(hidden_dim, hidden_dim),
                h_swish() if use_hs else nn.ReLU(inplace=True),
                # pw-linear
                nn.Conv2d(hidden_dim, oup, 1, 1, 0, bias=False),
                nn.BatchNorm2d(oup),
                # myConv(hidden_dim, oup, 1, 1, 0)
            )

    def forward(self, x):
        y = self.conv(x)
        if self.identity:
            return x + y
        else:
            return y

class MobileNet_Block_1(nn.Module):
    def __init__(self, inp, oup, hidden_dim, kernel_size, stride, use_se, use_hs):
        super(MobileNet_Block_1, self).__init__()
        assert stride in [1, 2]

        self.identity = stride == 1 and inp == oup

        # 输入通道数=扩张通道数 则不进行通道扩张
        if inp == hidden_dim:
            self.conv = nn.Sequential(
                # dw
                # nn.Conv2d(hidden_dim, hidden_dim, kernel_size, stride, (kernel_size - 1) // 2, groups=hidden_dim,
                #           bias=False),
                # nn.BatchNorm2d(hidden_dim),
                my_RepVGGBlock(hidden_dim, hidden_dim,kernel_size, stride,groups=hidden_dim),
                h_swish() if use_hs else nn.ReLU(inplace=True),
                # Squeeze-and-Excite
                SimAM() if use_se else nn.Sequential(),
                # pw-linear
                # CoordAtt(hidden_dim, hidden_dim),
                nn.Conv2d(hidden_dim, oup, 1, 1, 0, bias=False),
                nn.BatchNorm2d(oup),
            )
        else:
            # 否则 先进行通道扩张
            self.conv = nn.Sequential(
                # pw
                nn.Conv2d(inp, hidden_dim, 1, 1, 0, bias=False),
                nn.BatchNorm2d(hidden_dim),
                h_swish() if use_hs else nn.ReLU(inplace=True),
                # dw
                # nn.Conv2d(hidden_dim, hidden_dim, kernel_size, stride, (kernel_size - 1) // 2, groups=hidden_dim,
                #           bias=False),
                # nn.BatchNorm2d(hidden_dim),
                my_RepVGGBlock(hidden_dim, hidden_dim, kernel_size, stride, groups=hidden_dim),
                # Squeeze-and-Excite
                SimAM() if use_se else nn.Sequential(),
                # CoordAtt(hidden_dim, hidden_dim),
                h_swish() if use_hs else nn.ReLU(inplace=True),
                # pw-linear
                nn.Conv2d(hidden_dim, oup, 1, 1, 0, bias=False),
                nn.BatchNorm2d(oup),
            )

    def forward(self, x):
        y = self.conv(x)
        if self.identity:
            return x + y
        else:
            return y
# ---------------------------- MobileBlock end ---------------------------------

#biFPN
# 结合BiFPN 设置可学习参数 学习不同分支的权重
# 两个分支concat操作
# 结合BiFPN 设置可学习参数 学习不同分支的权重
# 两个分支concat操作
class BiFPN_Concat2(nn.Module):
    def __init__(self, dimension=1):
        super(BiFPN_Concat2, self).__init__()
        self.d = dimension
        self.w = nn.Parameter(torch.ones(2, dtype=torch.float32), requires_grad=True)
        self.epsilon = 0.0001
        # 设置可学习参数 nn.Parameter的作用是：将一个不可训练的类型Tensor转换成可以训练的类型

        # 并且会向宿主模型注册该参数 成为其一部分 即model.parameters()会包含这个parameter
        # 从而在参数优化的时候可以自动一起优化

    def forward(self, x):
        w = self.w
        weight = w / (torch.sum(w, dim=0) + self.epsilon)  # 将权重进行归一化
        # Fast normalized fusion
        x = [weight[0] * x[0], weight[1] * x[1]]
        return torch.cat(x, self.d)


# 三个分支concat操作
class BiFPN_Concat3(nn.Module):
    def __init__(self, dimension=1):
        super(BiFPN_Concat3, self).__init__()
        self.d = dimension
        self.w = nn.Parameter(torch.ones(3, dtype=torch.float32), requires_grad=True)
        self.epsilon = 0.0001

    def forward(self, x):
        w = self.w
        weight = w / (torch.sum(w, dim=0) + self.epsilon)  # 将权重进行归一化
        # Fast normalized fusion
        x = [weight[0] * x[0], weight[1] * x[1], weight[2] * x[2]]
        return torch.cat(x, self.d)



class SwishImplementation(torch.autograd.Function):
    @staticmethod
    def forward(ctx, i):
        result = i * torch.sigmoid(i)
        ctx.save_for_backward(i)
        return result

    @staticmethod
    def backward(ctx, grad_output):
        i = ctx.saved_variables[0]
        sigmoid_i = torch.sigmoid(i)
        return grad_output * (sigmoid_i * (1 + i * (1 - sigmoid_i)))


class MemoryEfficientSwish(nn.Module):
    def forward(self, x):
        return SwishImplementation.apply(x)

class my_ECALayer(nn.Module):
    def __init__(self, channel, b=1, gamma=2):
        super(my_ECALayer, self).__init__()
        kernel_size = int(abs((math.log(channel, 2) + b) / gamma))
        kernel_size = kernel_size if kernel_size % 2 else kernel_size + 1

        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=kernel_size, padding=(kernel_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        y = self.avg_pool(x)
        y = self.conv(y.squeeze(-1).transpose(-1, -2)).transpose(-1, -2).unsqueeze(-1)
        y = self.sigmoid(y)
        return y.expand_as(x)


class my_CBAMLayer(nn.Module):
    def __init__(self,c1,kernel_size=7):
        super(my_CBAMLayer, self).__init__()
        self.channel_attention = my_ECALayer(c1)
        self.spatial_attention = SpatialAttention(kernel_size)

    def forward(self, x):
        out = self.channel_attention(x)
        out = self.spatial_attention(out * x) * out
        return out

# class Concat_BiFPN(nn.Module):
#     # Concatenate a list of tensors along dimension
#     def __init__(self, c1, c2):
#         super(Concat_BiFPN, self).__init__()
#         # self.relu = nn.ReLU()
#         self.w1 = nn.Parameter(torch.ones(2, dtype=torch.float32), requires_grad=True)
#         self.w2 = nn.Parameter(torch.ones(3, dtype=torch.float32), requires_grad=True)
#         self.epsilon = 0.0001
#         self.conv = nn.Conv2d(c1, c2, kernel_size=1, stride=1, padding=0)
#         self.swish = MemoryEfficientSwish()
#
#     def forward(self, x):
#         outs = self._forward(x)
#         return outs
#
#     def _forward(self, x):
#         if len(x) == 2:
#             # w = self.relu(self.w1)
#             w = self.w1
#             weight = w / (torch.sum(w, dim=0) + self.epsilon)
#             # Connections for P6_0 and P7_0 to P6_1 respectively
#             x = self.conv(self.swish(weight[0] * x[0] + weight[1] * x[1]))
#         elif len(x) == 3:
#             # w = self.relu(self.w2)
#             w = self.w2
#             weight = w / (torch.sum(w, dim=0) + self.epsilon)
#             x = self.conv(self.swish(weight[0] * x[0] + weight[1] * x[1] + weight[2] * x[2]))
#
#         return x
class Concat_BiFPN(nn.Module):
    # Concatenate a list of tensors along dimension
    def __init__(self, c1, c2):
        super(Concat_BiFPN, self).__init__()
        self.w11= nn.Parameter(torch.ones(c1, dtype=torch.float32), requires_grad=True)
        self.w12 = nn.Parameter(torch.ones(c1, dtype=torch.float32), requires_grad=True)
        self.epsilon = 0.0001
        self.conv = nn.Conv2d(c1, c2, kernel_size=1, stride=1, padding=0)

        self.swish = MemoryEfficientSwish()
        self.ECA=my_ECALayer(c1)
        self.CBAM=my_CBAMLayer(c1)

    def forward(self, x):
        outs = self._forward(x)
        return outs

    def _forward(self, x):
        if len(x) == 2:
            w11=self.w11
            w12=self.w12
            # e1=self.CBAM(x[0])
            # e2=self.CBAM(x[1])
            # e11 = e1.view(e1.shape[0], e1.shape[1], -1).mean(dim=2).squeeze()
            # e12 = e2.view(e2.shape[0], e2.shape[1], -1).mean(dim=2).squeeze()
            weight11 = (w11) / (w11+w12+self.epsilon)
            weight12 = (w12) / (w11+w12+self.epsilon)
            # weight11 = (e11) / (e11 + e12 + self.epsilon)
            # weight12 = (e12) / (e11 + e12 + self.epsilon)
            weight11 = weight11.unsqueeze(-1).unsqueeze(-1)
            weight12 = weight12.unsqueeze(-1).unsqueeze(-1)
            x = self.conv(self.swish(weight11 * x[0] + weight12 * x[1]))

            # print(torch.squeeze(torch.squeeze(torch.squeeze(weight11, -1),-1)))
        return x




class Concat_BiFPN_ECA(nn.Module):
    # Concatenate a list of tensors along dimension
    def __init__(self, c1, c2):
        super(Concat_BiFPN_ECA, self).__init__()
        self.w11 = nn.Parameter(torch.ones(c1, dtype=torch.float32), requires_grad=True)
        self.w12 = nn.Parameter(torch.ones(c1, dtype=torch.float32), requires_grad=True)
        self.epsilon = 0.0001
        self.conv = nn.Conv2d(c1, c2, kernel_size=1, stride=1, padding=0)
        self.swish = MemoryEfficientSwish()
        self.ECA = my_ECALayer(c1)

    def forward(self, x):
        outs = self._forward(x)
        return outs

    def _forward(self, x):
        if len(x) == 2:
            e1 = self.ECA(x[0])
            e2 = self.ECA(x[1])
            e11 = e1.view(e1.shape[0], e1.shape[1], -1).mean(dim=2).squeeze()
            e12 = e2.view(e2.shape[0], e2.shape[1], -1).mean(dim=2).squeeze()
            weight11 = (e11) / (e11 + e12 + self.epsilon)
            weight12 = (e12) / (e11 + e12 + self.epsilon)
            weight11 = weight11.unsqueeze(-1).unsqueeze(-1)
            weight12 = weight12.unsqueeze(-1).unsqueeze(-1)
            x = self.conv(self.swish(weight11 * x[0] + weight12 * x[1]))
        return x

# class Concat_BiFPN_SE(nn.Module):
#     # Concatenate a list of tensors along dimension
#     def __init__(self, c1, c2):
#         super(Concat_BiFPN_SE, self).__init__()
#         self.w11 = nn.Parameter(torch.ones(c1, dtype=torch.float32), requires_grad=True)
#         self.w12 = nn.Parameter(torch.ones(c1, dtype=torch.float32), requires_grad=True)
#         self.epsilon = 0.0001
#         self.conv = nn.Conv2d(c1, c2, kernel_size=1, stride=1, padding=0)
#         self.swish = MemoryEfficientSwish()
#         self.SE = my_SELayer(c1)
#
#     def forward(self, x):
#         outs = self._forward(x)
#         return outs
#
#     def _forward(self, x):
#         if len(x) == 2:
#             e1 = self.SE(x[0])
#             e2 = self.SE(x[1])
#             e11 = e1.view(e1.shape[0], e1.shape[1], -1).mean(dim=2).squeeze()
#             e12 = e2.view(e2.shape[0], e2.shape[1], -1).mean(dim=2).squeeze()
#             weight11 = (e11) / (e11 + e12 + self.epsilon)
#             weight12 = (e12) / (e11 + e12 + self.epsilon)
#             weight11 = weight11.unsqueeze(-1).unsqueeze(-1)
#             weight12 = weight12.unsqueeze(-1).unsqueeze(-1)
#             x = self.conv(self.swish(weight11 * x[0] + weight12 * x[1]))
#         return x

class myCoordAtt(nn.Module):
    def __init__(self, inp, oup, reduction=32):
        super(myCoordAtt, self).__init__()
        self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
        self.pool_w = nn.AdaptiveAvgPool2d((1, None))

        mip = max(8, inp // reduction)

        self.conv1 = nn.Conv2d(inp, mip, kernel_size=1, stride=1, padding=0)
        self.bn1 = nn.BatchNorm2d(mip)
        self.act = h_swish()

        self.conv_h = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)
        self.conv_w = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)

    def forward(self, x):
        identity = x

        n, c, h, w = x.size()
        x_h = self.pool_h(x)
        x_w = self.pool_w(x).permute(0, 1, 3, 2)

        y = torch.cat([x_h, x_w], dim=2)
        y = self.conv1(y)
        y = self.bn1(y)
        y = self.act(y)

        x_h, x_w = torch.split(y, [h, w], dim=2)
        x_w = x_w.permute(0, 1, 3, 2)

        a_h = self.conv_h(x_h).sigmoid()
        a_w = self.conv_w(x_w).sigmoid()

        out = a_w * a_h

        return out


class Concat_BiFPN_SE(nn.Module):
    # Concatenate a list of tensors along dimension
    def __init__(self, c1, c2):
        super(Concat_BiFPN_SE, self).__init__()
        self.w11 = nn.Parameter(torch.ones(c1, dtype=torch.float32), requires_grad=True)
        self.w12 = nn.Parameter(torch.ones(c1, dtype=torch.float32), requires_grad=True)
        self.epsilon = 0.0001
        self.conv = nn.Conv2d(c1, c2, kernel_size=1, stride=1, padding=0)
        self.swish = MemoryEfficientSwish()
        self.SE = my_SELayer(2*c1)

        self.ECA = my_SELayer(2*c1)
        self.CA = myCoordAtt(2*c1,2*c1)
        self.cv1=Conv(c1,c2,1,1)

    def forward(self, x):
        outs = self._forward(x)
        return outs

    def _forward(self, x):
        if len(x) == 2:
            # e1 = self.SE(x[0])
            # e2 = self.SE(x[1])
            # e11 = e1.view(e1.shape[0], e1.shape[1], -1).mean(dim=2).squeeze()
            # e12 = e2.view(e2.shape[0], e2.shape[1], -1).mean(dim=2).squeeze()
            # weight11 = (e11) / (e11 + e12 + self.epsilon)
            # weight12 = (e12) / (e11 + e12 + self.epsilon)
            # weight11 = weight11.unsqueeze(-1).unsqueeze(-1)
            # weight12 = weight12.unsqueeze(-1).unsqueeze(-1)
            # # x = self.conv(self.swish(weight11 * x[0] + weight12 * x[1]))
            # x = self.cv1(weight11 * x[0] + weight12 * x[1])
            y = torch.cat([x[0],x[1]],dim=1)
            y = channel_shuffle(y,2)
            e = self.SE(y)
            e11 = e[:,0::2]
            e12 = e[:,1::2]
            weight11 = (e11) / (e11 + e12 + self.epsilon)
            weight12 = (e12) / (e11 + e12 + self.epsilon)
            # weight11 = (e11)
            # weight12 = (e12)
            weight11 = weight11.unsqueeze(-1).unsqueeze(-1)
            weight12 = weight12.unsqueeze(-1).unsqueeze(-1)
            # x = self.cv1(0.5*weight11 * x[0] + 0.5*weight12 * x[1])
            x = self.cv1(weight11 * x[0] + weight12 * x[1])
        return x

class Concat_BiFPN_ECA_NEW(nn.Module):
    # Concatenate a list of tensors along dimension
    def __init__(self, c1, c2):
        super(Concat_BiFPN_ECA_NEW, self).__init__()
        self.w11 = nn.Parameter(torch.ones(c1, dtype=torch.float32), requires_grad=True)
        self.w12 = nn.Parameter(torch.ones(c1, dtype=torch.float32), requires_grad=True)
        self.epsilon = 0.0001
        self.conv = Conv(c1, c2)
        self.swish = MemoryEfficientSwish()
        self.ECA = my_ECALayer(c1)

    def forward(self, x):
        outs = self._forward(x)
        return outs

    def _forward(self, x):
        if len(x) == 2:
            e1 = self.ECA(x[0])
            e2 = self.ECA(x[1])
            e11 = e1.view(e1.shape[0], e1.shape[1], -1).mean(dim=2).squeeze()
            e12 = e2.view(e2.shape[0], e2.shape[1], -1).mean(dim=2).squeeze()
            weight11 = (e11) / (e11 + e12 + self.epsilon)
            weight12 = (e12) / (e11 + e12 + self.epsilon)
            weight11 = weight11.unsqueeze(-1).unsqueeze(-1)
            weight12 = weight12.unsqueeze(-1).unsqueeze(-1)
            x = self.conv(self.swish(weight11 * x[0] + weight12 * x[1]))
        return x


class Concat_BiFPN_OLD(nn.Module):
    # Concatenate a list of tensors along dimension
    def __init__(self, c1, c2):
        super(Concat_BiFPN_OLD, self).__init__()
        # self.relu = nn.ReLU()
        self.w1 = nn.Parameter(torch.ones(2, dtype=torch.float32), requires_grad=True)
        self.w2 = nn.Parameter(torch.ones(3, dtype=torch.float32), requires_grad=True)
        self.epsilon = 0.0001
        self.conv = nn.Conv2d(c1, c2, kernel_size=1, stride=1, padding=0)
        self.swish = MemoryEfficientSwish()

    def forward(self, x):
        outs = self._forward(x)
        return outs

    def _forward(self, x):
        if len(x) == 2:
            # w = self.relu(self.w1)
            w = self.w1
            weight = w / (torch.sum(w, dim=0) + self.epsilon)
            # Connections for P6_0 and P7_0 to P6_1 respectively
            x = self.conv(self.swish(weight[0] * x[0] + weight[1] * x[1]))
        elif len(x) == 3:
            # w = self.relu(self.w2)
            w = self.w2
            weight = w / (torch.sum(w, dim=0) + self.epsilon)
            x = self.conv(self.swish(weight[0] * x[0] + weight[1] * x[1] + weight[2] * x[2]))
        return x


from torchvision.ops import DeformConv2d

#DCNv2***************************************************************
class DCNConv(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super().__init__()
        self.conv1 = nn.Conv2d(c1, c2, 3, 2, 1, groups=g, bias=False)
        deformable_groups = 1
        offset_channels = 18
        self.conv2_offset = nn.Conv2d(c2, deformable_groups * offset_channels, kernel_size=3, padding=1)
        self.conv2 = DeformConv2d(c2, c2, kernel_size=3, padding=1, bias=False)

        self.bn1 = nn.BatchNorm2d(c2)
        self.act1 = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
        self.bn2 = nn.BatchNorm2d(c2)
        self.act2 = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())

    def forward(self, x):
        x = self.act1(self.bn1(self.conv1(x)))
        offset = self.conv2_offset(x)
        x = self.act2(self.bn2(self.conv2(x, offset)))
        return x


class DCNv2(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1,
                 padding=1, dilation=1, groups=1, deformable_groups=1):
        super(DCNv2, self).__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = (kernel_size, kernel_size)
        self.stride = (stride, stride)
        self.padding = (padding, padding)
        self.dilation = (dilation, dilation)
        self.groups = groups
        self.deformable_groups = deformable_groups

        self.weight = nn.Parameter(
            torch.empty(out_channels, in_channels, *self.kernel_size)
        )
        self.bias = nn.Parameter(torch.empty(out_channels))

        out_channels_offset_mask = (self.deformable_groups * 3 *
                                    self.kernel_size[0] * self.kernel_size[1])
        self.conv_offset_mask = nn.Conv2d(
            self.in_channels,
            out_channels_offset_mask,
            kernel_size=self.kernel_size,
            stride=self.stride,
            padding=self.padding,
            bias=True,
        )
        self.bn = nn.BatchNorm2d(out_channels)
        self.act = nn.SiLU()
        self.reset_parameters()

    def forward(self, x):
        offset_mask = self.conv_offset_mask(x)
        o1, o2, mask = torch.chunk(offset_mask, 3, dim=1)
        offset = torch.cat((o1, o2), dim=1)
        mask = torch.sigmoid(mask)
        x = torch.ops.torchvision.deform_conv2d(
            x,
            self.weight,
            offset,
            mask,
            self.bias,
            self.stride[0], self.stride[1],
            self.padding[0], self.padding[1],
            self.dilation[0], self.dilation[1],
            self.groups,
            self.deformable_groups,
            True
        )
        x = self.bn(x)
        x = self.act(x)
        return x

    def reset_parameters(self):
        n = self.in_channels
        for k in self.kernel_size:
            n *= k
        std = 1. / math.sqrt(n)
        self.weight.data.uniform_(-std, std)
        self.bias.data.zero_()
        self.conv_offset_mask.weight.data.zero_()
        self.conv_offset_mask.bias.data.zero_()

class Bottleneck_DCN(nn.Module):
    # Standard bottleneck
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = DCNv2(c_, c_, 3, 1, groups=g)
        # self.cbam =CBAM(c_)
        self.cv3 = Conv(c_, c2, 1, 1)
        self.add = shortcut and c1 == c2

    def forward(self, x):
        xdc=self.cv2(self.cv1(x))
        # xadd=self.cbam(xdc)+xdc
        xout=self.cv3(xdc)
        return x + xout if self.add else xout

class C3_DCNv2(C3):
    # C3 module with DCNv2可变形卷积
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)
        self.m = nn.Sequential(*(Bottleneck_DCN(c_, c_, shortcut, g, e=1.0) for _ in range(n)))



class ECBAM_DCNv2Bottleneck(nn.Module):
    # Standard bottleneck
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5,ratio=16,kernel_size=7):  # ch_in, ch_out, shortcut, groups, expansion
        super(ECBAM_DCNv2Bottleneck,self).__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = DCNv2(c_, c2, 3, 1, groups=g)
        self.add = shortcut and c1 == c2


        self.channel_attention = ChannelAttention(c2, ratio)

        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=kernel_size, padding=(kernel_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

        self.spatial_attention = SpatialAttention(kernel_size)
        #self.cbam=CBAM(c1,c2,ratio,kernel_size)

    def forward(self, x):
        x1 = self.cv2(self.cv1(x))
        # out = self.channel_attention(x1) * x1

        y = self.avg_pool(x1)
        y = self.conv(y.squeeze(-1).transpose(-1, -2)).transpose(-1, -2).unsqueeze(-1)
        y = self.sigmoid(y)
        out = x1 * y.expand_as(x1)

        # print('outchannels:{}'.format(out.shape))
        out = self.spatial_attention(out) * out
        return x + out if self.add else out

class ECBAM_C3_DCNv2(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # act=FReLU(c2)
        self.m = nn.Sequential(*(ECBAM_DCNv2Bottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))
        # self.m = nn.Sequential(*[CrossConv(c_, c_, 3, 1, g, 1.0, shortcut) for _ in range(n)])

    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))











# class MobileNet_Block(nn.Module):
#     def __init__(self, inp, oup, hidden_dim, kernel_size, stride, use_se, use_hs):
#         super(MobileNet_Block, self).__init__()
#         assert stride in [1, 2]
#
#         self.identity = stride == 1 and inp == oup
#
#         # 输入通道数=扩张通道数 则不进行通道扩张
#         if inp == hidden_dim:
#             self.conv = nn.Sequential(
#                 # dw
#                 nn.Conv2d(hidden_dim, hidden_dim, kernel_size, stride, (kernel_size - 1) // 2, groups=hidden_dim,
#                           bias=False),
#                 nn.BatchNorm2d(hidden_dim),
#                 h_swish() if use_hs else nn.ReLU(inplace=True),
#                 # Squeeze-and-Excite
#                 ECALayer(hidden_dim) if use_se else nn.Sequential(),
#                 # pw-linear
#                 # CoordAtt(hidden_dim, hidden_dim),
#                 nn.Conv2d(hidden_dim, oup, 1, 1, 0, bias=False),
#                 nn.BatchNorm2d(oup),
#             )
#         else:
#             # 否则 先进行通道扩张
#             self.conv = nn.Sequential(
#                 # pw
#                 nn.Conv2d(inp, hidden_dim, 1, 1, 0, bias=False),
#                 nn.BatchNorm2d(hidden_dim),
#                 h_swish() if use_hs else nn.ReLU(inplace=True),
#                 # dw
#                 nn.Conv2d(hidden_dim, hidden_dim, kernel_size, stride, (kernel_size - 1) // 2, groups=hidden_dim,
#                           bias=False),
#                 nn.BatchNorm2d(hidden_dim),
#                 # Squeeze-and-Excite
#                 ECALayer(hidden_dim) if use_se else nn.Sequential(),
#                 # CoordAtt(hidden_dim, hidden_dim),
#                 h_swish() if use_hs else nn.ReLU(inplace=True),
#                 # pw-linear
#                 nn.Conv2d(hidden_dim, oup, 1, 1, 0, bias=False),
#                 nn.BatchNorm2d(oup),
#             )
#
#     def forward(self, x):
#         y = self.conv(x)
#         if self.identity:
#             return x + y
#         else:
#             return y




class CARAFE(nn.Module):
    #CARAFE: Content-Aware ReAssembly of FEatures       https://arxiv.org/pdf/1905.02188.pdf
    def __init__(self, c1, c2, kernel_size=3, up_factor=2):
        super(CARAFE, self).__init__()
        self.kernel_size = kernel_size
        self.up_factor = up_factor
        self.down = nn.Conv2d(c1, c1 // 4, 1)
        self.encoder = nn.Conv2d(c1 // 4, self.up_factor ** 2 * self.kernel_size ** 2,
                                 self.kernel_size, 1, self.kernel_size // 2)
        self.out = nn.Conv2d(c1, c2, 1)

    def forward(self, x):
        N, C, H, W = x.size()
        # N,C,H,W -> N,C,delta*H,delta*W
        # kernel prediction module
        kernel_tensor = self.down(x)  # (N, Cm, H, W)
        kernel_tensor = self.encoder(kernel_tensor)  # (N, S^2 * Kup^2, H, W)
        kernel_tensor = F.pixel_shuffle(kernel_tensor, self.up_factor)  # (N, S^2 * Kup^2, H, W)->(N, Kup^2, S*H, S*W)
        kernel_tensor = F.softmax(kernel_tensor, dim=1)  # (N, Kup^2, S*H, S*W)
        kernel_tensor = kernel_tensor.unfold(2, self.up_factor, step=self.up_factor) # (N, Kup^2, H, W*S, S)
        kernel_tensor = kernel_tensor.unfold(3, self.up_factor, step=self.up_factor) # (N, Kup^2, H, W, S, S)
        kernel_tensor = kernel_tensor.reshape(N, self.kernel_size ** 2, H, W, self.up_factor ** 2) # (N, Kup^2, H, W, S^2)
        kernel_tensor = kernel_tensor.permute(0, 2, 3, 1, 4)  # (N, H, W, Kup^2, S^2)

        # content-aware reassembly module
        # tensor.unfold: dim, size, step
        x = F.pad(x, pad=(self.kernel_size // 2, self.kernel_size // 2,
                                          self.kernel_size // 2, self.kernel_size // 2),
                          mode='constant', value=0) # (N, C, H+Kup//2+Kup//2, W+Kup//2+Kup//2)
        x = x.unfold(2, self.kernel_size, step=1) # (N, C, H, W+Kup//2+Kup//2, Kup)
        x = x.unfold(3, self.kernel_size, step=1) # (N, C, H, W, Kup, Kup)
        x = x.reshape(N, C, H, W, -1) # (N, C, H, W, Kup^2)
        x = x.permute(0, 2, 3, 1, 4)  # (N, H, W, C, Kup^2)

        out_tensor = torch.matmul(x, kernel_tensor)  # (N, H, W, C, S^2)
        out_tensor = out_tensor.reshape(N, H, W, -1)
        out_tensor = out_tensor.permute(0, 3, 1, 2)
        out_tensor = F.pixel_shuffle(out_tensor, self.up_factor)
        out_tensor = self.out(out_tensor)
        #print("up shape:",out_tensor.shape)
        return out_tensor


#____________________________________________head


# build repvgg block
# -----------------------------
def conv_bn(in_channels, out_channels, kernel_size, stride, padding, groups=1):
    result = nn.Sequential()
    result.add_module('conv', nn.Conv2d(in_channels=in_channels, out_channels=out_channels,
                                        kernel_size=kernel_size, stride=stride, padding=padding, groups=groups,
                                        bias=False))
    result.add_module('bn', nn.BatchNorm2d(num_features=out_channels))

    return result


class SEBlock(nn.Module):

    def __init__(self, input_channels, internal_neurons):
        super(SEBlock, self).__init__()
        self.down = nn.Conv2d(in_channels=input_channels, out_channels=internal_neurons, kernel_size=1, stride=1,
                              bias=True)
        self.up = nn.Conv2d(in_channels=internal_neurons, out_channels=input_channels, kernel_size=1, stride=1,
                            bias=True)
        self.input_channels = input_channels

    def forward(self, inputs):
        x = F.avg_pool2d(inputs, kernel_size=inputs.size(3))
        x = self.down(x)
        x = F.relu(x)
        x = self.up(x)
        x = torch.sigmoid(x)
        x = x.view(-1, self.input_channels, 1, 1)
        return inputs * x

# class RepVGGBlock(nn.Module):
#
#     def __init__(self, in_channels, out_channels, kernel_size=3,
#                  stride=1, padding=1, dilation=1, groups=1, padding_mode='zeros', deploy=False, use_se=False):
#         super(RepVGGBlock, self).__init__()
#         self.deploy = deploy
#         self.groups = groups
#         self.in_channels = in_channels
#
#         padding_11 = padding - kernel_size // 2
#
#         self.nonlinearity = nn.SiLU()
#
#         # self.nonlinearity = nn.ReLU()
#
#         if use_se:
#             self.se = SEBlock(out_channels, internal_neurons=out_channels // 16)
#         else:
#             self.se = nn.Identity()
#
#         if deploy:
#             self.rbr_reparam = nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size,
#                                          stride=stride,
#                                          padding=padding, dilation=dilation, groups=groups, bias=True,
#                                          padding_mode=padding_mode)
#
#         else:
#             self.rbr_identity = nn.BatchNorm2d(
#                 num_features=in_channels) if out_channels == in_channels and stride == 1 else None
#             self.rbr_dense = conv_bn(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size,
#                                      stride=stride, padding=padding, groups=groups)
#             self.rbr_1x1 = conv_bn(in_channels=in_channels, out_channels=out_channels, kernel_size=1, stride=stride,
#                                    padding=padding_11, groups=groups)
#             # print('RepVGG Block, identity = ', self.rbr_identity)
#
#     def get_equivalent_kernel_bias(self):
#         kernel3x3, bias3x3 = self._fuse_bn_tensor(self.rbr_dense)
#         kernel1x1, bias1x1 = self._fuse_bn_tensor(self.rbr_1x1)
#         kernelid, biasid = self._fuse_bn_tensor(self.rbr_identity)
#         return kernel3x3 + self._pad_1x1_to_3x3_tensor(kernel1x1) + kernelid, bias3x3 + bias1x1 + biasid
#
#     def _pad_1x1_to_3x3_tensor(self, kernel1x1):
#         if kernel1x1 is None:
#             return 0
#         else:
#             return torch.nn.functional.pad(kernel1x1, [1, 1, 1, 1])
#
#     def _fuse_bn_tensor(self, branch):
#         if branch is None:
#             return 0, 0
#         if isinstance(branch, nn.Sequential):
#             kernel = branch.conv.weight
#             running_mean = branch.bn.running_mean
#             running_var = branch.bn.running_var
#             gamma = branch.bn.weight
#             beta = branch.bn.bias
#             eps = branch.bn.eps
#         else:
#             assert isinstance(branch, nn.BatchNorm2d)
#             if not hasattr(self, 'id_tensor'):
#                 input_dim = self.in_channels // self.groups
#                 kernel_value = np.zeros((self.in_channels, input_dim, 3, 3), dtype=np.float32)
#                 for i in range(self.in_channels):
#                     kernel_value[i, i % input_dim, 1, 1] = 1
#                 self.id_tensor = torch.from_numpy(kernel_value).to(branch.weight.device)
#             kernel = self.id_tensor
#             running_mean = branch.running_mean
#             running_var = branch.running_var
#             gamma = branch.weight
#             beta = branch.bias
#             eps = branch.eps
#         std = (running_var + eps).sqrt()
#         t = (gamma / std).reshape(-1, 1, 1, 1)
#         return kernel * t, beta - running_mean * gamma / std
#
#     def forward(self, inputs):
#         if hasattr(self, 'rbr_reparam'):
#             return self.nonlinearity(self.se(self.rbr_reparam(inputs)))
#
#         if self.rbr_identity is None:
#             id_out = 0
#         else:
#             id_out = self.rbr_identity(inputs)
#
#         return self.nonlinearity(self.se(self.rbr_dense(inputs) + self.rbr_1x1(inputs) + id_out))
#
#     def fusevggforward(self, x):
#         return self.nonlinearity(self.rbr_dense(x))

class CBH(nn.Module):
    def __init__(self, num_channels, num_filters, filter_size, stride, num_groups=1):
        super().__init__()
        self.conv = nn.Conv2d(
            num_channels,
            num_filters,
            filter_size,
            stride,
            padding=(filter_size - 1) // 2,
            groups=num_groups,
            bias=False)
        self.bn = nn.BatchNorm2d(num_filters)
        self.hardswish = nn.Hardswish()

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.hardswish(x)
        return x

    def fuseforward(self, x):
        return self.hardswish(self.conv(x))

class Hswish(nn.Module):
    def __init__(self, inplace=True):
        super(Hswish, self).__init__()
        self.relu = nn.ReLU6(inplace=inplace)

    def forward(self, x):
        return self.relu(x + 3) / 6


class SELayer(nn.Module):
    def __init__(self, channel, reduction=4):
        super(SELayer, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel),
            Hswish())

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x)
        y = y.view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y


# build shuffle block
# -------------------------------------------------------------------------

def channel_shuffle(x, groups):
    batchsize, num_channels, height, width = x.data.size()
    channels_per_group = num_channels // groups

    # reshape
    x = x.view(batchsize, groups,
               channels_per_group, height, width)

    x = torch.transpose(x, 1, 2).contiguous()

    # flatten
    x = x.view(batchsize, -1, height, width)

    return x


class conv_bn_relu_maxpool(nn.Module):
    def __init__(self, c1, c2):  # ch_in, ch_out
        super(conv_bn_relu_maxpool, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(c1, c2, kernel_size=3, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(c2),
            nn.ReLU(inplace=True),
        )
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1, dilation=1, ceil_mode=False)

    def forward(self, x):
        return self.maxpool(self.conv(x))


# class Shuffle_Block(nn.Module):
#     def __init__(self, inp, oup, stride):
#         super(Shuffle_Block, self).__init__()
#
#         if not (1 <= stride <= 3):
#             raise ValueError('illegal stride value')
#         self.stride = stride
#
#         branch_features = oup // 2
#         assert (self.stride != 1) or (inp == branch_features << 1)
#
#         if self.stride > 1:
#             self.branch1 = nn.Sequential(
#                 # self.depthwise_conv(inp, inp, kernel_size=3, stride=self.stride, padding=1),
#                 # nn.BatchNorm2d(inp),
#                 myDWConv(inp,inp,3,self.stride),
#                 # DCNv2(inp, inp, 3, 1, groups=inp),
#                 SELayer(inp),
#                 # ECALayer(inp),
#                 # SimAM(),
#                 # CBAM(inp),
#                 # CoordAtt(inp,inp),
#                 # # SpatialAttentionx(inp),
#                 # CBAM(inp),
#                 # nn.Conv2d(inp, branch_features, kernel_size=1, stride=1, padding=0, bias=False),
#                 # nn.BatchNorm2d(branch_features),
#                 myConv(inp,branch_features,1,1),
#                 nn.ReLU(inplace=True),
#             )
#
#         self.branch2 = nn.Sequential(
#             # nn.Conv2d(inp if (self.stride > 1) else branch_features,
#             #           branch_features, kernel_size=1, stride=1, padding=0, bias=False),
#             # nn.BatchNorm2d(branch_features),
#             myConv(inp if (self.stride > 1) else branch_features, branch_features, 1, 1),
#             nn.ReLU(inplace=True),
#             # self.depthwise_conv(branch_features, branch_features, kernel_size=3, stride=self.stride, padding=1),
#             # nn.BatchNorm2d(branch_features),
#             myDWConv(branch_features, branch_features, 3, self.stride),
#             SELayer(branch_features),
#             # ECALayer(branch_features),
#             # SimAM(),
#             # CBAM(branch_features),
#             # CoordAtt(branch_features, branch_features),
#             # SpatialAttentionx(branch_features),
#             # CBAMX(branch_features),
#             # nn.Conv2d(branch_features, branch_features, kernel_size=1, stride=1, padding=0, bias=False),
#             # nn.BatchNorm2d(branch_features),
#             myConv(branch_features, branch_features, 1, 1),
#             nn.ReLU(inplace=True),
#         )
#
#     @staticmethod
#     def depthwise_conv(i, o, kernel_size, stride=1, padding=0, bias=False):
#         return nn.Conv2d(i, o, kernel_size, stride, padding, bias=bias, groups=i)
#
#
#     def forward(self, x):
#         if self.stride == 1:
#             x1, x2 = x.chunk(2, dim=1)
#             out = torch.cat((x1, self.branch2(x2)), dim=1)
#         else:
#             out = torch.cat((self.branch1(x),self.branch2(x)), dim=1)
#
#         out = channel_shuffle(out, 2)
#
#         return out
class Shuffle_Block(nn.Module):
    def __init__(self, inp, oup, stride):
        super(Shuffle_Block, self).__init__()

        if not (1 <= stride <= 3):
            raise ValueError('illegal stride value')
        self.stride = stride

        branch_features = oup // 2
        assert (self.stride != 1) or (inp == branch_features << 1)

        if self.stride > 1:
            self.branch1 = nn.Sequential(
                # self.depthwise_conv(inp, inp, kernel_size=3, stride=self.stride, padding=1),
                # nn.BatchNorm2d(inp),
                myDWConv(inp,inp,3,self.stride),
                # DCNv2(inp, inp, 3, 1, groups=inp),
                SELayer(inp),
                # # SpatialAttentionx(inp),
                # CBAMX(inp),
                # nn.Conv2d(inp, branch_features, kernel_size=1, stride=1, padding=0, bias=False),
                # nn.BatchNorm2d(branch_features),
                myConv(inp,branch_features,1,1),
                nn.ReLU(inplace=True),
            )

        self.branch2 = nn.Sequential(
            # nn.Conv2d(inp if (self.stride > 1) else branch_features,
            #           branch_features, kernel_size=1, stride=1, padding=0, bias=False),
            # nn.BatchNorm2d(branch_features),
            myConv(inp if (self.stride > 1) else branch_features, branch_features, 1, 1),
            nn.ReLU(inplace=True),
            # self.depthwise_conv(branch_features, branch_features, kernel_size=3, stride=self.stride, padding=1),
            # nn.BatchNorm2d(branch_features),
            myDWConv(branch_features, branch_features, 3, self.stride),
            SELayer(branch_features),
            # SpatialAttentionx(branch_features),
            # CBAMX(branch_features),
            # nn.Conv2d(branch_features, branch_features, kernel_size=1, stride=1, padding=0, bias=False),
            # nn.BatchNorm2d(branch_features),
            myConv(branch_features, branch_features, 1, 1),
            nn.ReLU(inplace=True),
        )

    @staticmethod
    def depthwise_conv(i, o, kernel_size, stride=1, padding=0, bias=False):
        return nn.Conv2d(i, o, kernel_size, stride, padding, bias=bias, groups=i)


    def forward(self, x):
        if self.stride == 1:
            x1, x2 = x.chunk(2, dim=1)
            out = torch.cat((x1, self.branch2(x2)), dim=1)
        else:
            out = torch.cat((self.branch1(x),self.branch2(x)), dim=1)

        out = channel_shuffle(out, 2)

        return out


# class Shuffle_Block(nn.Module):
#     def __init__(self, inp, oup, stride):
#         super(Shuffle_Block, self).__init__()
#
#         if not (1 <= stride <= 3):
#             raise ValueError('illegal stride value')
#         self.stride = stride
#
#         branch_features = oup // 2
#         assert (self.stride != 1) or (inp == branch_features << 1)
#
#         if self.stride > 1:
#             self.branch1 = nn.Sequential(
#                 self.depthwise_conv(inp, inp, kernel_size=5, stride=self.stride, padding=2),
#                 nn.BatchNorm2d(inp),
#                 nn.Conv2d(inp, branch_features, kernel_size=1, stride=1, padding=0, bias=False),
#                 nn.BatchNorm2d(branch_features),
#                 nn.ReLU(inplace=True),
#             )
#         self.se1 = nn.Sequential(
#             nn.AdaptiveAvgPool2d(1),
#             nn.Linear(branch_features, branch_features),
#             nn.ReLU(inplace=True),
#             nn.Linear(branch_features, branch_features),
#             nn.Sigmoid()
#         )
#         self.branch2 = nn.Sequential(
#             nn.Conv2d(inp if (self.stride > 1) else branch_features,
#                       branch_features, kernel_size=1, stride=1, padding=0, bias=False),
#             nn.BatchNorm2d(branch_features),
#             nn.ReLU(inplace=True),
#             self.depthwise_conv(branch_features, branch_features, kernel_size=5, stride=self.stride, padding=2),
#             nn.BatchNorm2d(branch_features),
#             nn.Conv2d(branch_features, branch_features, kernel_size=1, stride=1, padding=0, bias=False),
#             nn.BatchNorm2d(branch_features),
#             nn.ReLU(inplace=True),
#         )
#
#     @staticmethod
#     def depthwise_conv(i, o, kernel_size, stride=1, padding=0, bias=False):
#         return nn.Conv2d(i, o, kernel_size, stride, padding, bias=bias, groups=i)
#
#     def forward(self, x):
#         if self.stride == 1:
#             x1, x2 = x.chunk(2, dim=1)  # 按照维度1进行split
#             out = torch.cat((x1, self.branch2(x2)), dim=1)
#             out1 = self.se1(x1) * out[:, :out.size(1) // 2, :, :]
#             out = torch.cat((out1, out[:, out.size(1) // 2:, :, :]), dim=1)
#         else:
#             out = torch.cat((self.branch1(x), self.branch2(x)), dim=1)
#
#         out = channel_shuffle(out, 2)
#
#         return out


class Shuffle_Block_noSE(nn.Module):
    def __init__(self, inp, oup, stride):
        super(Shuffle_Block_noSE, self).__init__()

        if not (1 <= stride <= 3):
            raise ValueError('illegal stride value')
        self.stride = stride

        branch_features = oup // 2
        assert (self.stride != 1) or (inp == branch_features << 1)

        if self.stride > 1:
            self.branch1 = nn.Sequential(
                # self.depthwise_conv(inp, inp, kernel_size=3, stride=self.stride, padding=1),
                # nn.BatchNorm2d(inp),
                myDWConv(inp,inp,3,self.stride),
                # DCNv2(inp, inp, 3, 1, groups=inp),
                # SELayer(inp),
                # # SpatialAttentionx(inp),
                # CBAMX(inp),
                # nn.Conv2d(inp, branch_features, kernel_size=1, stride=1, padding=0, bias=False),
                # nn.BatchNorm2d(branch_features),
                myConv(inp,branch_features,1,1),
                nn.ReLU(inplace=True),
            )

        self.branch2 = nn.Sequential(
            # nn.Conv2d(inp if (self.stride > 1) else branch_features,
            #           branch_features, kernel_size=1, stride=1, padding=0, bias=False),
            # nn.BatchNorm2d(branch_features),
            myConv(inp if (self.stride > 1) else branch_features, branch_features, 1, 1),
            nn.ReLU(inplace=True),
            # self.depthwise_conv(branch_features, branch_features, kernel_size=3, stride=self.stride, padding=1),
            # nn.BatchNorm2d(branch_features),
            myDWConv(branch_features, branch_features, 3, self.stride),
            # SELayer(branch_features),
            # SpatialAttentionx(branch_features),
            # CBAMX(branch_features),
            # nn.Conv2d(branch_features, branch_features, kernel_size=1, stride=1, padding=0, bias=False),
            # nn.BatchNorm2d(branch_features),
            myConv(branch_features, branch_features, 1, 1),
            nn.ReLU(inplace=True),
        )


    @staticmethod
    def depthwise_conv(i, o, kernel_size, stride=1, padding=0, bias=False):
        return nn.Conv2d(i, o, kernel_size, stride, padding, bias=bias, groups=i)


    def forward(self, x):
        if self.stride == 1:
            x1, x2 = x.chunk(2, dim=1)
            out = torch.cat((x1, self.branch2(x2)), dim=1)
        else:
            out = torch.cat((self.branch1(x),self.branch2(x)), dim=1)

        out = channel_shuffle(out, 2)

        return out

# repvgg block end
# -----------------------------

from timm.models.layers import DropPath
def paixu(channel_weights, feature_map):
    batch_size, num_channels, height, width = feature_map.size()

    # 将通道权重比重的张量展平为形状为（batch_size, num_channels）的二维张量
    weights_flat = channel_weights.view(batch_size, num_channels)

    # 对权重进行按大到小排序，并记录排序后的索引
    sorted_indices = torch.argsort(weights_flat, dim=1, descending=True)

    # 创建用于重排特征图的索引张量
    reorder_indices = sorted_indices.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, height, width)

    # 对特征图进行通道重排
    reordered_feature_map = torch.gather(feature_map, 1, reorder_indices)

    return reordered_feature_map, sorted_indices


def chongzu(channel_weights, feature_map):
    batch_size, num_channels, height, width = feature_map.size()

    # 将通道权重比重的张量展平为形状为（batch_size, num_channels）的二维张量
    weights_flat = channel_weights.view(batch_size, num_channels)

    # 对权重进行按大到小排序，并记录排序后的索引
    sorted_indices = torch.argsort(weights_flat, dim=1, descending=True)

    # 创建用于重排特征图的索引张量
    reorder_indices = sorted_indices.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, height, width)

    # 对特征图进行通道重排
    reordered_feature_map = torch.gather(feature_map, 1, reorder_indices)

    return reordered_feature_map, sorted_indices


def inverse_paixu(feature_map, indices):
    batch_size, num_channels, height, width = feature_map.size()
    sorted_indices_expanded = indices.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, height, width)
    restored_feature_map = torch.zeros_like(feature_map)
    restored_feature_map.scatter_(1, sorted_indices_expanded, feature_map)
    return restored_feature_map

class my_SELayer(nn.Module):
    def __init__(self, channel, reduction=4):
        super(my_SELayer, self).__init__()
        # Squeeze操作
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # Excitation操作(FC+ReLU+FC+Sigmoid)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel),
            h_sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x)
        y = y.view(b, c)
        y = self.fc(y)  # 学习到的每一channel的权重
        return y

class Partial_conv3(nn.Module):    #按论文来的
    def __init__(self, dim, n_div, forward):
        super().__init__()
        self.dim_conv3 = dim *3 // 4
        self.dim_untouched = dim - self.dim_conv3
        # self.partial_conv3 = nn.Conv2d(self.dim_conv3, self.dim_conv3, 3, 1, 1, bias=False)
        # self.partial_conv3x3 = nn.Conv2d(self.dim_conv3, self.dim_conv3, 3, 1, 1, bias=False)
        self.partial_conv3x3 = Conv(self.dim_conv3, self.dim_conv3, 3, 1)
        # self.partial_conv1x1 = nn.Conv2d(self.dim_conv3, self.dim_conv3, 1, 1, 0, bias=False)
        # self.partial_conv1x3 = nn.Conv2d(self.dim_conv3, self.dim_conv3, (1, 3), 1, (0, 1), bias=False)
        # self.partial_conv3x1 = nn.Conv2d(self.dim_conv3, self.dim_conv3, (3, 1), 1, (1, 0), bias=False)

        # self.bn = nn.BatchNorm2d(self.dim_conv3)
        # self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())

        # self.se = my_SELayer(dim)

        if forward == 'slicing':
            self.forward = self.forward_slicing
        elif forward == 'split_cat':
            self.forward = self.forward_split_cat
        else:
            raise NotImplementedError

    def forward_slicing(self, x):
        # only for inference
        x = x.clone()  # !!! Keep the original input intact for the residual connection later
        x[:, :self.dim_conv3, :, :] = self.partial_conv3(x[:, :self.dim_conv3, :, :])
        return x

    def forward_split_cat(self, x):
        # for training/inference
        # b = self.se(x)
        # xnew0, indices = paixu(b, x)
        # x1, x2 = torch.split(xnew0, [self.dim_conv3, self.dim_untouched], dim=1)
        # x1 = self.partial_conv3(x1)
        # xnew1 = torch.cat((x1, x2), 1)
        #
        # # xnew1=self.all_conv3(xnew0)
        # restored_xnew1 = inverse_paixu(xnew1, indices)
        #
        # return x, restored_xnew1
        x1, x2 = torch.split(x, [self.dim_conv3, self.dim_untouched], dim=1)
        # x1 = self.partial_conv3(x1)
        x3x3_1 = self.partial_conv3x3(x1)
        # x3x3_2 = self.bn(self.partial_conv3x3(x1))
        # x3x3_3 = self.bn(self.partial_conv3x3(x1))
        # x3x3_4 = self.bn(self.partial_conv3x3(x1))
        # x3x3_5 = self.bn(self.partial_conv3x3(x1))
        # x3x3_6 = self.bn(self.partial_conv3x3(x1))
        # x3x3_7 = self.bn(self.partial_conv3x3(x1))
        # x3x3_8 = self.bn(self.partial_conv3x3(x1))
        # x3x3_9 = self.bn(self.partial_conv3x3(x1))
        # x1x3=self.bn(self.partial_conv1x3(x1))
        # x3x1=self.bn(self.partial_conv3x1(x1))
        # x1x1 = self.bn(self.partial_conv1x1(x1))
        xf=x3x3_1
        xff = torch.cat((xf, x2), 1)
        # restored_xnew1 = inverse_paixu(xff, indices)
        return xff


class Partial_conv314(nn.Module):    #按论文来的
    def __init__(self, dim, n_div, forward):
        super().__init__()
        # self.dim_conv3 = dim // n_div
        self.dim_conv3 = dim // 4
        self.dim_untouched = dim - self.dim_conv3
        self.partial_conv3x3 = nn.Conv2d(self.dim_conv3, self.dim_conv3, 3, 1, 1, bias=False)
        self.bn = nn.BatchNorm2d(self.dim_conv3)

        if forward == 'slicing':
            self.forward = self.forward_slicing
        elif forward == 'split_cat':
            self.forward = self.forward_split_cat
        else:
            raise NotImplementedError

    def forward_slicing(self, x):
        # only for inference
        x = x.clone()  # !!! Keep the original input intact for the residual connection later
        x[:, :self.dim_conv3, :, :] = self.partial_conv3(x[:, :self.dim_conv3, :, :])
        return x

    def forward_split_cat(self, x):
        # for training/inference
        x1, x2 = torch.split(x, [self.dim_conv3, self.dim_untouched], dim=1)
        x3x3_1 = self.bn(self.partial_conv3x3(x1))
        xf=x3x3_1
        xff = torch.cat((xf, x2), 1)
        return xff

class Partial_conv324(nn.Module):    #按论文来的
    def __init__(self, dim, n_div, forward):
        super().__init__()
        # self.dim_conv3 = dim // n_div
        self.dim_conv3 = dim *2// 4
        self.dim_untouched = dim - self.dim_conv3
        self.partial_conv3x3 = nn.Conv2d(self.dim_conv3, self.dim_conv3, 3, 1, 1, bias=False)
        self.bn = nn.BatchNorm2d(self.dim_conv3)

        if forward == 'slicing':
            self.forward = self.forward_slicing
        elif forward == 'split_cat':
            self.forward = self.forward_split_cat
        else:
            raise NotImplementedError

    def forward_slicing(self, x):
        # only for inference
        x = x.clone()  # !!! Keep the original input intact for the residual connection later
        x[:, :self.dim_conv3, :, :] = self.partial_conv3(x[:, :self.dim_conv3, :, :])
        return x

    def forward_split_cat(self, x):
        # for training/inference
        x1, x2 = torch.split(x, [self.dim_conv3, self.dim_untouched], dim=1)
        x3x3_1 = self.bn(self.partial_conv3x3(x1))
        xf=x3x3_1
        xff = torch.cat((xf, x2), 1)
        return xff

class Partial_conv334(nn.Module):    #按论文来的
    def __init__(self, dim, n_div, forward):
        super().__init__()
        # self.dim_conv3 = dim // n_div
        self.dim_conv3 = dim *3// 4
        self.dim_untouched = dim - self.dim_conv3
        self.partial_conv3x3 = nn.Conv2d(self.dim_conv3, self.dim_conv3, 3, 1, 1, bias=False)
        self.bn = nn.BatchNorm2d(self.dim_conv3)
        self.act = nn.SiLU()

        if forward == 'slicing':
            self.forward = self.forward_slicing
        elif forward == 'split_cat':
            self.forward = self.forward_split_cat
        else:
            raise NotImplementedError

    def forward_slicing(self, x):
        # only for inference
        x = x.clone()  # !!! Keep the original input intact for the residual connection later
        x[:, :self.dim_conv3, :, :] = self.partial_conv3(x[:, :self.dim_conv3, :, :])
        return x

    def forward_split_cat(self, x):
        # for training/inference
        x1, x2 = torch.split(x, [self.dim_conv3, self.dim_untouched], dim=1)
        x3x3_1 = self.act(self.bn(self.partial_conv3x3(x1)))
        xf=x3x3_1
        xff = torch.cat((xf, x2), 1)
        return xff

class Faster_Block(nn.Module):   #当作卷积块用
    def __init__(self,
                 inc,
                 dim,
                 n_div=4,
                 mlp_ratio=2,
                 drop_path=0.0,    #可以调节
                 layer_scale_init_value=0.0,
                 pconv_fw_type='split_cat'
                 ):
        super().__init__()
        self.dim = dim
        self.mlp_ratio = mlp_ratio
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.n_div = n_div

        mlp_hidden_dim = int(dim * mlp_ratio)

        mlp_layer = [
            # Conv(dim, mlp_hidden_dim, 1),
            myConv(dim, mlp_hidden_dim, 1,1),
            nn.ReLU(),
            nn.Conv2d(mlp_hidden_dim, dim, 1, bias=False)
        ]

        self.mlp = nn.Sequential(*mlp_layer)

        self.spatial_mixing = Partial_conv3(
            dim,
            n_div,
            pconv_fw_type
        )

        self.adjust_channel = None
        if inc != dim:
            self.adjust_channel = Conv(inc, dim, 1)

        if layer_scale_init_value > 0:
            self.layer_scale = nn.Parameter(layer_scale_init_value * torch.ones((dim)), requires_grad=True)
            self.forward = self.forward_layer_scale
        else:
            self.forward = self.forward

    # def forward(self, x):
    #     if self.adjust_channel is not None:
    #         x = self.adjust_channel(x)
    #     # shortcut = x
    #     shortcut,x = self.spatial_mixing(x)
    #     x = shortcut + self.drop_path(self.mlp(x))
    #     return x
    #
    # def forward_layer_scale(self, x):
    #     # shortcut = x
    #     shortcut,x = self.spatial_mixing(x)
    #     x = shortcut + self.drop_path(
    #         self.layer_scale.unsqueeze(-1).unsqueeze(-1) * self.mlp(x))
    #     return x
    def forward(self, x):
        if self.adjust_channel is not None:
            x = self.adjust_channel(x)
        shortcut = x
        x = self.spatial_mixing(x)
        x = shortcut + self.drop_path(self.mlp(x))
        return x

    def forward_layer_scale(self, x):
        shortcut = x
        x = self.spatial_mixing(x)
        x = shortcut + self.drop_path(
            self.layer_scale.unsqueeze(-1).unsqueeze(-1) * self.mlp(x))
        return x

class Faster_Block14(nn.Module):   #当作卷积块用
    def __init__(self,
                 inc,
                 dim,
                 n_div=2,
                 mlp_ratio=2,
                 drop_path=0.0,    #可以调节
                 layer_scale_init_value=0.0,
                 pconv_fw_type='split_cat'
                 ):
        super().__init__()
        self.dim = dim
        self.mlp_ratio = mlp_ratio
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.n_div = n_div

        mlp_hidden_dim = int(dim * mlp_ratio)

        mlp_layer = [
            Conv(dim, mlp_hidden_dim, 1),
            nn.Conv2d(mlp_hidden_dim, dim, 1, bias=False)
        ]

        self.mlp = nn.Sequential(*mlp_layer)

        self.spatial_mixing = Partial_conv314(
            dim,
            n_div,
            pconv_fw_type
        )

        self.adjust_channel = None
        if inc != dim:
            self.adjust_channel = Conv(inc, dim, 1)

        if layer_scale_init_value > 0:
            self.layer_scale = nn.Parameter(layer_scale_init_value * torch.ones((dim)), requires_grad=True)
            self.forward = self.forward_layer_scale
        else:
            self.forward = self.forward
    def forward(self, x):
        if self.adjust_channel is not None:
            x = self.adjust_channel(x)
        shortcut = x
        x = self.spatial_mixing(x)
        x = shortcut + self.drop_path(self.mlp(x))
        return x

    def forward_layer_scale(self, x):
        shortcut = x
        x = self.spatial_mixing(x)
        x = shortcut + self.drop_path(
            self.layer_scale.unsqueeze(-1).unsqueeze(-1) * self.mlp(x))
        return x

class Faster_Block24(nn.Module):   #当作卷积块用
    def __init__(self,
                 inc,
                 dim,
                 n_div=2,
                 mlp_ratio=2,
                 drop_path=0.0,    #可以调节
                 layer_scale_init_value=0.0,
                 pconv_fw_type='split_cat'
                 ):
        super().__init__()
        self.dim = dim
        self.mlp_ratio = mlp_ratio
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.n_div = n_div

        mlp_hidden_dim = int(dim * mlp_ratio)

        mlp_layer = [
            Conv(dim, mlp_hidden_dim, 1),
            nn.Conv2d(mlp_hidden_dim, dim, 1, bias=False)
        ]

        self.mlp = nn.Sequential(*mlp_layer)

        self.spatial_mixing = Partial_conv324(
            dim,
            n_div,
            pconv_fw_type
        )

        self.adjust_channel = None
        if inc != dim:
            self.adjust_channel = Conv(inc, dim, 1)

        if layer_scale_init_value > 0:
            self.layer_scale = nn.Parameter(layer_scale_init_value * torch.ones((dim)), requires_grad=True)
            self.forward = self.forward_layer_scale
        else:
            self.forward = self.forward
    def forward(self, x):
        if self.adjust_channel is not None:
            x = self.adjust_channel(x)
        shortcut = x
        x = self.spatial_mixing(x)
        x = shortcut + self.drop_path(self.mlp(x))
        return x

    def forward_layer_scale(self, x):
        shortcut = x
        x = self.spatial_mixing(x)
        x = shortcut + self.drop_path(
            self.layer_scale.unsqueeze(-1).unsqueeze(-1) * self.mlp(x))
        return x

class Faster_Block34(nn.Module):   #当作卷积块用
    def __init__(self,
                 inc,
                 dim,
                 n_div=2,
                 mlp_ratio=2,
                 drop_path=0.0,    #可以调节
                 layer_scale_init_value=0.0,
                 pconv_fw_type='split_cat'
                 ):
        super().__init__()
        self.dim = dim
        self.mlp_ratio = mlp_ratio
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.n_div = n_div

        mlp_hidden_dim = int(dim * mlp_ratio)

        mlp_layer = [
            Conv(dim, mlp_hidden_dim, 1),
            nn.Conv2d(mlp_hidden_dim, dim, 1, bias=False)
        ]

        self.mlp = nn.Sequential(*mlp_layer)

        self.spatial_mixing = Partial_conv334(
            dim,
            n_div,
            pconv_fw_type
        )

        self.adjust_channel = None
        if inc != dim:
            self.adjust_channel = Conv(inc, dim, 1)

        if layer_scale_init_value > 0:
            self.layer_scale = nn.Parameter(layer_scale_init_value * torch.ones((dim)), requires_grad=True)
            self.forward = self.forward_layer_scale
        else:
            self.forward = self.forward
    def forward(self, x):
        if self.adjust_channel is not None:
            x = self.adjust_channel(x)
        shortcut = x
        x = self.spatial_mixing(x)
        x = shortcut + self.drop_path(self.mlp(x))
        return x

    def forward_layer_scale(self, x):
        shortcut = x
        x = self.spatial_mixing(x)
        x = shortcut + self.drop_path(
            self.layer_scale.unsqueeze(-1).unsqueeze(-1) * self.mlp(x))
        return x

# class C3_Faster(C3):
#     # C3 module with cross-convolutions
#     def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
#         super().__init__(c1, c2, n, shortcut, g, e)
#         c_ = int(c2 * e)
#         self.m = nn.Sequential(*(Faster_Block(c_, c_) for _ in range(n)),
#                                ECALayer(c_))
class C3_Faster(C3):
    # C3 module with cross-convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)
        self.m = nn.Sequential(*(Faster_Block(c_, c_) for _ in range(n)))

class C3_Fasteradjust(C3):
    # C3 module with cross-convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)
        self.m = nn.Sequential(*(FasterBottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)))
class C3_Faster14(C3):
    # C3 module with cross-convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)
        self.m = nn.Sequential(*(Faster_Block14(c_, c_) for _ in range(n)))
class C3_Faster24(C3):
    # C3 module with cross-convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)
        self.m = nn.Sequential(*(Faster_Block24(c_, c_) for _ in range(n)))
class C3_Faster34(C3):
    # C3 module with cross-convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)
        self.m = nn.Sequential(*(Faster_Block34(c_, c_) for _ in range(n)))


class C2f(nn.Module):
    # CSP Bottleneck with 2 convolutions
    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        self.c = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.cv2 = Conv((2 + n) * self.c, c2, 1)  # optional act=FReLU(c2)
        self.m = nn.ModuleList((Faster_Block(self.c, self.c) for _ in range(n)))

    def forward(self, x):
        y = list(self.cv1(x).chunk(2, 1))
        y.extend(m(y[-1]) for m in self.m)
        return self.cv2(torch.cat(y, 1))

    def forward_split(self, x):
        y = list(self.cv1(x).split((self.c, self.c), 1))
        y.extend(m(y[-1]) for m in self.m)
        return self.cv2(torch.cat(y, 1))
#shuffle-------------------------
# *************************test************************#
# class SEGhostConv(nn.Module):
#     # Ghost Convolution https://github.com/huawei-noah/ghostnet
#     def __init__(self, c1, c2, k=1, s=1, g=1, act=True):  # ch_in, ch_out, kernel, stride, groups
#         super().__init__()
#         c_ = c2 // 2  # hidden channels
#         self.eca = ECALayer(c1)
#         self.cbam = CBAM(c1)
#         self.ecbam = ECBAM(c1)
#         self.ca = CoordAtt(c1,c1)
#         self.se = SELayer(c1)
#
#         self.cv1 = Conv(c1, c_, k, s, None, g, act)  # c_是隐层，即降维后的层，是一个分离卷积
#         self.cv2 = Conv(c_, c_, 5, 1, None, c_, act)
#         # self.cv2=DCNv2(c_, c_, 3, 1, groups=g)
#
#     def forward(self, x):
#         y = self.cv1(self.se(x))
#         return torch.cat([y, self.cv2(y)], 1)
class SEGhostBottleneck(nn.Module):
    # Ghost Bottleneck https://github.com/huawei-noah/ghostnet
    def __init__(self, c1, c2, k=3, s=1):  # ch_in, ch_out, kernel, stride
        super().__init__()
        c_ = c2 // 2
        self.se = SELayer(c2)
        self.conv = nn.Sequential(GhostConv(c1, c_, 1, 1),  # pw
                                  DWConv(c_, c_, k, s, act=False) if s == 2 else nn.Identity(),  # dw
                                  GhostConv(c_, c2, 1, 1, act=False))  # pw-linear
        self.shortcut = nn.Sequential(DWConv(c1, c1, k, s, act=False),
                                      Conv(c1, c2, 1, 1, act=False)) if s == 2 else nn.Identity()
        # self._ECA = ECBAMBottleneck(c2, c2)

    def forward(self, x):
        return self.se(self.conv(x)) + self.shortcut(x)
        # return self._ECA(self.conv(x) + self.shortcut(x))

class ECAGhostConv(nn.Module):
    # Ghost Convolution https://github.com/huawei-noah/ghostnet
    def __init__(self, c1, c2, k=1, s=1, g=1, act=True):  # ch_in, ch_out, kernel, stride, groups
        super().__init__()
        c_ = c2 // 2  # hidden channels
        self.eca = ECALayer(c1)
        self.cbam = CBAM(c1)
        self.ecbam = ECBAM(c1)
        self.ca = CoordAtt(c1,c1)
        self.se = SELayer(c1)

        self.cv1 = Conv(c1, c_, k, s, None, g, act)  # c_是隐层，即降维后的层，是一个分离卷积
        self.cv2 = Conv(c_, c_, 5, 1, None, c_, act)
        # self.cv2 = RepVGGBlock(c_, c_, 5, 1, groups=c_)
        # self.cv2=DCNv2(c_, c_, 3, 1, groups=g)

    def forward(self, x):
        y = self.cv1(self.eca(x))
        return torch.cat([y, self.cv2(y)], 1)

class CAGhostConv(nn.Module):
    # Ghost Convolution https://github.com/huawei-noah/ghostnet
    def __init__(self, c1, c2, k=1, s=1, g=1, act=True):  # ch_in, ch_out, kernel, stride, groups
        super().__init__()
        c_ = c2 // 2  # hidden channels
        self.eca = ECALayer(c1)
        self.cbam = CBAM(c1)
        self.ecbam = ECBAM(c1)
        self.ca = CoordAtt(c1,c1)
        self.se = SELayer(c1)

        self.cv1 = Conv(c1, c_, k, s, None, g, act)  # c_是隐层，即降维后的层，是一个分离卷积
        self.cv2 = Conv(c_, c_, 5, 1, None, c_, act)
        # self.cv2=DCNv2(c_, c_, 3, 1, groups=g)

    def forward(self, x):
        y = self.cv1(self.ca(x))
        return torch.cat([y, self.cv2(y)], 1)


class CBAMGhostConv(nn.Module):
    # Ghost Convolution https://github.com/huawei-noah/ghostnet
    def __init__(self, c1, c2, k=1, s=1, g=1, act=True):  # ch_in, ch_out, kernel, stride, groups
        super().__init__()
        c_ = c2 // 2  # hidden channels
        self.eca = ECALayer(c1)
        self.cbam = CBAM(c1)
        self.ecbam = ECBAM(c1)
        self.ca = ChannelAttention(c1)
        self.se = SpatialAttention(c1)

        self.cv1 = Conv(c1, c_, k, s, None, g, act)  # c_是隐层，即降维后的层，是一个分离卷积
        self.cv2 = Conv(c_, c_, 5, 1, None, c_, act)
        # self.cv2=DCNv2(c_, c_, 3, 1, groups=g)

    def forward(self, x):
        y = self.cv1(self.cbam(x))
        return torch.cat([y, self.cv2(y)], 1)


class ECBAMGhostConv(nn.Module):
    # Ghost Convolution https://github.com/huawei-noah/ghostnet
    def __init__(self, c1, c2, k=1, s=1, g=1, act=True):  # ch_in, ch_out, kernel, stride, groups
        super().__init__()
        c_ = c2 // 2  # hidden channels
        # self.eca = ECALayer(c1)
        # self.cbam = CBAM(c1)
        self.ecbam = ECBAM(c1)
        # self.ca = ChannelAttention(c1)#SE
        # self.se = SpatialAttention(c1)#空间注意力机制

        self.cv1 = Conv(c1, c_, k, s, None, g, act)  # c_是隐层，即降维后的层，是一个分离卷积
        self.cv2 = Conv(c_, c_, 5, 1, None, c_, act)
        # self.cv2=DCNv2(c_, c_, 3, 1, groups=g)
#ECA CBAM CA SE
    def forward(self, x):
        y = self.cv1(self.ecbam(x))
        return torch.cat([y, self.cv2(y)], 1)


class SEGhostBottleneck(nn.Module):
    # Ghost Bottleneck https://github.com/huawei-noah/ghostnet
    def __init__(self, c1, c2, k=3, s=1):  # ch_in, ch_out, kernel, stride
        super().__init__()
        c_ = c2 // 2
        self.conv = nn.Sequential(SEGhostConv(c1, c_, 1, 1),  # pw
                                  DWConv(c_, c_, k, s, act=False) if s == 2 else nn.Identity(),  # dw
                                  SEGhostConv(c_, c2, 1, 1, act=False))  # pw-linear
        self.shortcut = nn.Sequential(DWConv(c1, c1, k, s, act=False),
                                      Conv(c1, c2, 1, 1, act=False)) if s == 2 else nn.Identity()
        # self._ECA = ECBAMBottleneck(c2, c2)

    def forward(self, x):
        return self.conv(x) + self.shortcut(x)
        # return self._ECA(self.conv(x) + self.shortcut(x))

class ECAGhostBottleneck(nn.Module):
    # Ghost Bottleneck https://github.com/huawei-noah/ghostnet
    def __init__(self, c1, c2, k=3, s=1):  # ch_in, ch_out, kernel, stride
        super().__init__()
        c_ = c2 // 2
        self.conv = nn.Sequential(ECAGhostConv(c1, c_, 1, 1),  # pw
                                  DWConv(c_, c_, k, s, act=False) if s == 2 else nn.Identity(),  # dw
                                  ECAGhostConv(c_, c2, 1, 1, act=False))  # pw-linear
        self.shortcut = nn.Sequential(DWConv(c1, c1, k, s, act=False),
                                      Conv(c1, c2, 1, 1, act=False)) if s == 2 else nn.Identity()
        # self._ECA = ECBAMBottleneck(c2, c2)

    def forward(self, x):
        return self.conv(x) + self.shortcut(x)
        # return self._ECA(self.conv(x) + self.shortcut(x))

class CAGhostBottleneck(nn.Module):
    # Ghost Bottleneck https://github.com/huawei-noah/ghostnet
    def __init__(self, c1, c2, k=3, s=1):  # ch_in, ch_out, kernel, stride
        super().__init__()
        c_ = c2 // 2
        self.conv = nn.Sequential(CAGhostConv(c1, c_, 1, 1),  # pw
                                  DWConv(c_, c_, k, s, act=False) if s == 2 else nn.Identity(),  # dw
                                  CAGhostConv(c_, c2, 1, 1, act=False))  # pw-linear
        self.shortcut = nn.Sequential(DWConv(c1, c1, k, s, act=False),
                                      Conv(c1, c2, 1, 1, act=False)) if s == 2 else nn.Identity()
        # self._ECA = ECBAMBottleneck(c2, c2)

    def forward(self, x):
        return self.conv(x) + self.shortcut(x)
        # return self._ECA(self.conv(x) + self.shortcut(x))


class CBAMGhostBottleneck(nn.Module):
    # Ghost Bottleneck https://github.com/huawei-noah/ghostnet
    def __init__(self, c1, c2, k=3, s=1):  # ch_in, ch_out, kernel, stride
        super().__init__()
        c_ = c2 // 2
        self.conv = nn.Sequential(CBAMGhostConv(c1, c_, 1, 1),  # pw
                                  DWConv(c_, c_, k, s, act=False) if s == 2 else nn.Identity(),  # dw
                                  CBAMGhostConv(c_, c2, 1, 1, act=False))  # pw-linear
        self.shortcut = nn.Sequential(DWConv(c1, c1, k, s, act=False),
                                      Conv(c1, c2, 1, 1, act=False)) if s == 2 else nn.Identity()
        # self._ECA = ECBAMBottleneck(c2, c2)

    def forward(self, x):
        return self.conv(x) + self.shortcut(x)
        # return self._ECA(self.conv(x) + self.shortcut(x))


class ECBAMGhostBottleneck(nn.Module):
    # Ghost Bottleneck https://github.com/huawei-noah/ghostnet
    def __init__(self, c1, c2, k=3, s=1):  # ch_in, ch_out, kernel, stride
        super().__init__()
        c_ = c2 // 2
        self.conv = nn.Sequential(ECBAMGhostConv(c1, c_, 1, 1),  # pw
                                  DWConv(c_, c_, k, s, act=False) if s == 2 else nn.Identity(),  # dw
                                  ECBAMGhostConv(c_, c2, 1, 1, act=False))  # pw-linear
        self.shortcut = nn.Sequential(DWConv(c1, c1, k, s, act=False),
                                      Conv(c1, c2, 1, 1, act=False)) if s == 2 else nn.Identity()
        # self._ECA = ECBAMBottleneck(c2, c2)

    def forward(self, x):
        return self.conv(x) + self.shortcut(x)
        # return self._ECA(self.conv(x) + self.shortcut(x))


class SEC3Ghost(C3):
    # C3 module with GhostBottleneck()
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)  # hidden channels
        self.m = nn.Sequential(*(SEGhostBottleneck(c_, c_) for _ in range(n)))

class ECAC3Ghost(C3):
    # C3 module with GhostBottleneck()
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)  # hidden channels
        self.m = nn.Sequential(*(ECAGhostBottleneck(c_, c_) for _ in range(n)))

class CAC3Ghost(C3):
    # C3 module with GhostBottleneck()
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)  # hidden channels
        self.m = nn.Sequential(*(CAGhostBottleneck(c_, c_) for _ in range(n)))


class CBAMC3Ghost(C3):
    # C3 module with GhostBottleneck()
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)  # hidden channels
        self.m = nn.Sequential(*(CBAMGhostBottleneck(c_, c_) for _ in range(n)))


class ECBAMC3Ghost(C3):
    # C3 module with GhostBottleneck()
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)  # hidden channels
        self.m = nn.Sequential(*(ECBAMGhostBottleneck(c_, c_) for _ in range(n)))

# **************************test***********************#
class ECA(nn.Module):
    def __init__(self, channel, b=1, gamma=2):
        super(ECA, self).__init__()
        kernel_size = int(abs((math.log(channel, 2) + b) / gamma))
        kernel_size = kernel_size if kernel_size % 2 else kernel_size + 1
        print("kernel_size:",kernel_size)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=kernel_size, padding=(kernel_size - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        y = self.avg_pool(x)
        y = self.conv(y.squeeze(-1).transpose(-1, -2)).transpose(-1, -2).unsqueeze(-1)
        y = self.sigmoid(y)
        return x * y.expand_as(x)


from typing import Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange
from torch import Tensor


class TopkRouting(nn.Module):
    """
    differentiable topk routing with scaling
    Args:
        qk_dim: int, feature dimension of query and key
        topk: int, the 'topk'
        qk_scale: int or None, temperature (multiply) of softmax activation
        with_param: bool, wether inorporate learnable params in routing unit
        diff_routing: bool, wether make routing differentiable
        soft_routing: bool, wether make output value multiplied by routing weights
    """

    def __init__(self, qk_dim, topk=4, qk_scale=None, param_routing=False, diff_routing=False):
        super().__init__()
        self.topk = topk
        self.qk_dim = qk_dim
        self.scale = qk_scale or qk_dim ** -0.5
        self.diff_routing = diff_routing
        # TODO: norm layer before/after linear?
        self.emb = nn.Linear(qk_dim, qk_dim) if param_routing else nn.Identity()
        # routing activation
        self.routing_act = nn.Softmax(dim=-1)

    def forward(self, query: Tensor, key: Tensor) -> Tuple[Tensor]:
        """
        Args:
            q, k: (n, p^2, c) tensor
        Return:
            r_weight, topk_index: (n, p^2, topk) tensor
        """
        if not self.diff_routing:
            query, key = query.detach(), key.detach()
        query_hat, key_hat = self.emb(query), self.emb(key)  # per-window pooling -> (n, p^2, c)
        attn_logit = (query_hat * self.scale) @ key_hat.transpose(-2, -1)  # (n, p^2, p^2)
        topk_attn_logit, topk_index = torch.topk(attn_logit, k=self.topk, dim=-1)  # (n, p^2, k), (n, p^2, k)
        r_weight = self.routing_act(topk_attn_logit)  # (n, p^2, k)

        return r_weight, topk_index


class KVGather(nn.Module):
    def __init__(self, mul_weight='none'):
        super().__init__()
        assert mul_weight in ['none', 'soft', 'hard']
        self.mul_weight = mul_weight

    def forward(self, r_idx: Tensor, r_weight: Tensor, kv: Tensor):
        """
        r_idx: (n, p^2, topk) tensor
        r_weight: (n, p^2, topk) tensor
        kv: (n, p^2, w^2, c_kq+c_v)
        Return:
            (n, p^2, topk, w^2, c_kq+c_v) tensor
        """
        # select kv according to routing index
        n, p2, w2, c_kv = kv.size()
        topk = r_idx.size(-1)
        # print(r_idx.size(), r_weight.size())
        # FIXME: gather consumes much memory (topk times redundancy), write cuda kernel?
        topk_kv = torch.gather(kv.view(n, 1, p2, w2, c_kv).expand(-1, p2, -1, -1, -1),
                               # (n, p^2, p^2, w^2, c_kv) without mem cpy
                               dim=2,
                               index=r_idx.view(n, p2, topk, 1, 1).expand(-1, -1, -1, w2, c_kv)
                               # (n, p^2, k, w^2, c_kv)
                               )

        if self.mul_weight == 'soft':
            topk_kv = r_weight.view(n, p2, topk, 1, 1) * topk_kv  # (n, p^2, k, w^2, c_kv)
        elif self.mul_weight == 'hard':
            raise NotImplementedError('differentiable hard routing TBA')
        # else: #'none'
        #     topk_kv = topk_kv # do nothing

        return topk_kv


class QKVLinear(nn.Module):
    def __init__(self, dim, qk_dim, bias=True):
        super().__init__()
        self.dim = dim
        self.qk_dim = qk_dim
        self.qkv = nn.Linear(dim, qk_dim + qk_dim + dim, bias=bias)

    def forward(self, x):
        q, kv = self.qkv(x).split([self.qk_dim, self.qk_dim + self.dim], dim=-1)
        return q, kv
        # q, k, v = self.qkv(x).split([self.qk_dim, self.qk_dim, self.dim], dim=-1)
        # return q, k, v


class BiLevelRoutingAttention(nn.Module):
    """
    n_win: number of windows in one side (so the actual number of windows is n_win*n_win)
    kv_per_win: for kv_downsample_mode='ada_xxxpool' only, number of key/values per window. Similar to n_win, the actual number is kv_per_win*kv_per_win.
    topk: topk for window filtering
    param_attention: 'qkvo'-linear for q,k,v and o, 'none': param free attention
    param_routing: extra linear for routing
    diff_routing: wether to set routing differentiable
    soft_routing: wether to multiply soft routing weights
    """

    def __init__(self, dim, n_win=7, num_heads=8, qk_dim=None, qk_scale=None,
                 kv_per_win=4, kv_downsample_ratio=4, kv_downsample_kernel=None, kv_downsample_mode='identity',
                 topk=4, param_attention="qkvo", param_routing=False, diff_routing=False, soft_routing=False,
                 side_dwconv=3,
                 auto_pad=True):
        super().__init__()
        # local attention setting
        self.dim = dim
        self.n_win = n_win  # Wh, Ww
        self.num_heads = num_heads
        self.qk_dim = qk_dim or dim
        assert self.qk_dim % num_heads == 0 and self.dim % num_heads == 0, 'qk_dim and dim must be divisible by num_heads!'
        self.scale = qk_scale or self.qk_dim ** -0.5

        ################side_dwconv (i.e. LCE in ShuntedTransformer)###########
        self.lepe = nn.Conv2d(dim, dim, kernel_size=side_dwconv, stride=1, padding=side_dwconv // 2,
                              groups=dim) if side_dwconv > 0 else \
            lambda x: torch.zeros_like(x)

        ################ global routing setting #################
        self.topk = topk
        self.param_routing = param_routing
        self.diff_routing = diff_routing
        self.soft_routing = soft_routing
        # router
        assert not (self.param_routing and not self.diff_routing)  # cannot be with_param=True and diff_routing=False
        self.router = TopkRouting(qk_dim=self.qk_dim,
                                  qk_scale=self.scale,
                                  topk=self.topk,
                                  diff_routing=self.diff_routing,
                                  param_routing=self.param_routing)
        if self.soft_routing:  # soft routing, always diffrentiable (if no detach)
            mul_weight = 'soft'
        elif self.diff_routing:  # hard differentiable routing
            mul_weight = 'hard'
        else:  # hard non-differentiable routing
            mul_weight = 'none'
        self.kv_gather = KVGather(mul_weight=mul_weight)

        # qkv mapping (shared by both global routing and local attention)
        self.param_attention = param_attention
        if self.param_attention == 'qkvo':
            self.qkv = QKVLinear(self.dim, self.qk_dim)
            self.wo = nn.Linear(dim, dim)
        elif self.param_attention == 'qkv':
            self.qkv = QKVLinear(self.dim, self.qk_dim)
            self.wo = nn.Identity()
        else:
            raise ValueError(f'param_attention mode {self.param_attention} is not surpported!')

        self.kv_downsample_mode = kv_downsample_mode
        self.kv_per_win = kv_per_win
        self.kv_downsample_ratio = kv_downsample_ratio
        self.kv_downsample_kenel = kv_downsample_kernel
        if self.kv_downsample_mode == 'ada_avgpool':
            assert self.kv_per_win is not None
            self.kv_down = nn.AdaptiveAvgPool2d(self.kv_per_win)
        elif self.kv_downsample_mode == 'ada_maxpool':
            assert self.kv_per_win is not None
            self.kv_down = nn.AdaptiveMaxPool2d(self.kv_per_win)
        elif self.kv_downsample_mode == 'maxpool':
            assert self.kv_downsample_ratio is not None
            self.kv_down = nn.MaxPool2d(self.kv_downsample_ratio) if self.kv_downsample_ratio > 1 else nn.Identity()
        elif self.kv_downsample_mode == 'avgpool':
            assert self.kv_downsample_ratio is not None
            self.kv_down = nn.AvgPool2d(self.kv_downsample_ratio) if self.kv_downsample_ratio > 1 else nn.Identity()
        elif self.kv_downsample_mode == 'identity':  # no kv downsampling
            self.kv_down = nn.Identity()
        elif self.kv_downsample_mode == 'fracpool':
            # assert self.kv_downsample_ratio is not None
            # assert self.kv_downsample_kenel is not None
            # TODO: fracpool
            # 1. kernel size should be input size dependent
            # 2. there is a random factor, need to avoid independent sampling for k and v
            raise NotImplementedError('fracpool policy is not implemented yet!')
        elif kv_downsample_mode == 'conv':
            # TODO: need to consider the case where k != v so that need two downsample modules
            raise NotImplementedError('conv policy is not implemented yet!')
        else:
            raise ValueError(f'kv_down_sample_mode {self.kv_downsaple_mode} is not surpported!')

        # softmax for local attention
        self.attn_act = nn.Softmax(dim=-1)

        self.auto_pad = auto_pad

    def forward(self, x, ret_attn_mask=False):
        """
        x: NHWC tensor
        Return:
            NHWC tensor
        """
        x = rearrange(x, "n c h w -> n h w c")
        # NOTE: use padding for semantic segmentation
        ###################################################
        if self.auto_pad:
            N, H_in, W_in, C = x.size()

            pad_l = pad_t = 0
            pad_r = (self.n_win - W_in % self.n_win) % self.n_win
            pad_b = (self.n_win - H_in % self.n_win) % self.n_win
            x = F.pad(x, (0, 0,  # dim=-1
                          pad_l, pad_r,  # dim=-2
                          pad_t, pad_b))  # dim=-3
            _, H, W, _ = x.size()  # padded size
        else:
            N, H, W, C = x.size()
            assert H % self.n_win == 0 and W % self.n_win == 0  #
        ###################################################

        # patchify, (n, p^2, w, w, c), keep 2d window as we need 2d pooling to reduce kv size
        x = rearrange(x, "n (j h) (i w) c -> n (j i) h w c", j=self.n_win, i=self.n_win)

        #################qkv projection###################
        # q: (n, p^2, w, w, c_qk)
        # kv: (n, p^2, w, w, c_qk+c_v)
        # NOTE: separte kv if there were memory leak issue caused by gather
        q, kv = self.qkv(x)

        # pixel-wise qkv
        # q_pix: (n, p^2, w^2, c_qk)
        # kv_pix: (n, p^2, h_kv*w_kv, c_qk+c_v)
        q_pix = rearrange(q, 'n p2 h w c -> n p2 (h w) c')
        kv_pix = self.kv_down(rearrange(kv, 'n p2 h w c -> (n p2) c h w'))
        kv_pix = rearrange(kv_pix, '(n j i) c h w -> n (j i) (h w) c', j=self.n_win, i=self.n_win)

        q_win, k_win = q.mean([2, 3]), kv[..., 0:self.qk_dim].mean(
            [2, 3])  # window-wise qk, (n, p^2, c_qk), (n, p^2, c_qk)

        ##################side_dwconv(lepe)##################
        # NOTE: call contiguous to avoid gradient warning when using ddp
        lepe = self.lepe(rearrange(kv[..., self.qk_dim:], 'n (j i) h w c -> n c (j h) (i w)', j=self.n_win,
                                   i=self.n_win).contiguous())
        lepe = rearrange(lepe, 'n c (j h) (i w) -> n (j h) (i w) c', j=self.n_win, i=self.n_win)

        ############ gather q dependent k/v #################

        r_weight, r_idx = self.router(q_win, k_win)  # both are (n, p^2, topk) tensors

        kv_pix_sel = self.kv_gather(r_idx=r_idx, r_weight=r_weight, kv=kv_pix)  # (n, p^2, topk, h_kv*w_kv, c_qk+c_v)
        k_pix_sel, v_pix_sel = kv_pix_sel.split([self.qk_dim, self.dim], dim=-1)
        # kv_pix_sel: (n, p^2, topk, h_kv*w_kv, c_qk)
        # v_pix_sel: (n, p^2, topk, h_kv*w_kv, c_v)

        ######### do attention as normal ####################
        k_pix_sel = rearrange(k_pix_sel, 'n p2 k w2 (m c) -> (n p2) m c (k w2)',
                              m=self.num_heads)  # flatten to BMLC, (n*p^2, m, topk*h_kv*w_kv, c_kq//m) transpose here?
        v_pix_sel = rearrange(v_pix_sel, 'n p2 k w2 (m c) -> (n p2) m (k w2) c',
                              m=self.num_heads)  # flatten to BMLC, (n*p^2, m, topk*h_kv*w_kv, c_v//m)
        q_pix = rearrange(q_pix, 'n p2 w2 (m c) -> (n p2) m w2 c',
                          m=self.num_heads)  # to BMLC tensor (n*p^2, m, w^2, c_qk//m)

        # param-free multihead attention
        attn_weight = (
                                  q_pix * self.scale) @ k_pix_sel  # (n*p^2, m, w^2, c) @ (n*p^2, m, c, topk*h_kv*w_kv) -> (n*p^2, m, w^2, topk*h_kv*w_kv)
        attn_weight = self.attn_act(attn_weight)
        out = attn_weight @ v_pix_sel  # (n*p^2, m, w^2, topk*h_kv*w_kv) @ (n*p^2, m, topk*h_kv*w_kv, c) -> (n*p^2, m, w^2, c)
        out = rearrange(out, '(n j i) m (h w) c -> n (j h) (i w) (m c)', j=self.n_win, i=self.n_win,
                        h=H // self.n_win, w=W // self.n_win)

        out = out + lepe
        # output linear
        out = self.wo(out)

        # NOTE: use padding for semantic segmentation
        # crop padded region
        if self.auto_pad and (pad_r > 0 or pad_b > 0):
            out = out[:, :H_in, :W_in, :].contiguous()

        if ret_attn_mask:
            return out, r_weight, r_idx, attn_weight
        else:
            return rearrange(out, "n h w c -> n c h w")


class Attention(nn.Module):
    """
    vanilla attention
    """

    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.):
        super().__init__()
        self.num_heads = num_heads
        head_dim = dim // num_heads
        # NOTE scale factor was wrong in my original version, can set manually to be compat with prev weights
        self.scale = qk_scale or head_dim ** -0.5

        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, x):
        """
        args:
            x: NCHW tensor
        return:
            NCHW tensor
        """
        _, _, H, W = x.size()
        x = rearrange(x, 'n c h w -> n (h w) c')

        #######################################
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]  # make torchscript happy (cannot use tensor as tuple)

        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        #######################################

        x = rearrange(x, 'n (h w) c -> n c h w', h=H, w=W)
        return x


class AttentionLePE(nn.Module):
    """
    vanilla attention
    """

    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0., side_dwconv=5):
        super().__init__()
        self.num_heads = num_heads
        head_dim = dim // num_heads
        # NOTE scale factor was wrong in my original version, can set manually to be compat with prev weights
        self.scale = qk_scale or head_dim ** -0.5

        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)
        self.lepe = nn.Conv2d(dim, dim, kernel_size=side_dwconv, stride=1, padding=side_dwconv // 2,
                              groups=dim) if side_dwconv > 0 else \
            lambda x: torch.zeros_like(x)

    def forward(self, x):
        """
        args:
            x: NCHW tensor
        return:
            NCHW tensor
        """
        _, _, H, W = x.size()
        x = rearrange(x, 'n c h w -> n (h w) c')

        #######################################
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]  # make torchscript happy (cannot use tensor as tuple)

        lepe = self.lepe(rearrange(x, 'n (h w) c -> n c h w', h=H, w=W))
        lepe = rearrange(lepe, 'n c h w -> n (h w) c')

        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x = x + lepe

        x = self.proj(x)
        x = self.proj_drop(x)
        #######################################

        x = rearrange(x, 'n (h w) c -> n c h w', h=H, w=W)
        return








# class RepConv(nn.Module):
#     # Represented convolution
#     # https://arxiv.org/abs/2101.03697
#
#     def __init__(self, c1, c2, k=3, s=1, p=None, g=1, act=True, deploy=False):
#         super(RepConv, self).__init__()
#
#         self.deploy = deploy
#         self.groups = g
#         self.in_channels = c1
#         self.out_channels = c2
#
#         assert k == 3
#         assert autopad(k, p) == 1
#
#         padding_11 = autopad(k, p) - k // 2
#
#         self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
#
#         if deploy:
#             self.rbr_reparam = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=True)
#
#         else:
#             self.rbr_identity = (nn.BatchNorm2d(num_features=c1) if c2 == c1 and s == 1 else None)
#
#             self.rbr_dense = nn.Sequential(
#                 nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False),
#                 nn.BatchNorm2d(num_features=c2),
#             )
#
#             self.rbr_1x1 = nn.Sequential(
#                 nn.Conv2d(c1, c2, 1, s, padding_11, groups=g, bias=False),
#                 nn.BatchNorm2d(num_features=c2),
#             )
#
#     def forward(self, inputs):
#         if hasattr(self, "rbr_reparam"):
#             return self.act(self.rbr_reparam(inputs))
#
#         if self.rbr_identity is None:
#             id_out = 0
#         else:
#             id_out = self.rbr_identity(inputs)
#
#         return self.act(self.rbr_dense(inputs) + self.rbr_1x1(inputs) + id_out)
#
#     def get_equivalent_kernel_bias(self):
#         kernel3x3, bias3x3 = self._fuse_bn_tensor(self.rbr_dense)
#         kernel1x1, bias1x1 = self._fuse_bn_tensor(self.rbr_1x1)
#         kernelid, biasid = self._fuse_bn_tensor(self.rbr_identity)
#         return (
#             kernel3x3 + self._pad_1x1_to_3x3_tensor(kernel1x1) + kernelid,
#             bias3x3 + bias1x1 + biasid,
#         )
#
#     def _pad_1x1_to_3x3_tensor(self, kernel1x1):
#         if kernel1x1 is None:
#             return 0
#         else:
#             return nn.functional.pad(kernel1x1, [1, 1, 1, 1])
#
#     def _fuse_bn_tensor(self, branch):
#         if branch is None:
#             return 0, 0
#         if isinstance(branch, nn.Sequential):
#             kernel = branch[0].weight
#             running_mean = branch[1].running_mean
#             running_var = branch[1].running_var
#             gamma = branch[1].weight
#             beta = branch[1].bias
#             eps = branch[1].eps
#         else:
#             assert isinstance(branch, nn.BatchNorm2d)
#             if not hasattr(self, "id_tensor"):
#                 input_dim = self.in_channels // self.groups
#                 kernel_value = np.zeros(
#                     (self.in_channels, input_dim, 3, 3), dtype=np.float32
#                 )
#                 for i in range(self.in_channels):
#                     kernel_value[i, i % input_dim, 1, 1] = 1
#                 self.id_tensor = torch.from_numpy(kernel_value).to(branch.weight.device)
#             kernel = self.id_tensor
#             running_mean = branch.running_mean
#             running_var = branch.running_var
#             gamma = branch.weight
#             beta = branch.bias
#             eps = branch.eps
#         std = (running_var + eps).sqrt()
#         t = (gamma / std).reshape(-1, 1, 1, 1)
#         return kernel * t, beta - running_mean * gamma / std
#
#     def repvgg_convert(self):
#         kernel, bias = self.get_equivalent_kernel_bias()
#         return (
#             kernel.detach().cpu().numpy(),
#             bias.detach().cpu().numpy(),
#         )
#
#     def fuse_conv_bn(self, conv, bn):
#
#         std = (bn.running_var + bn.eps).sqrt()
#         bias = bn.bias - bn.running_mean * bn.weight / std
#
#         t = (bn.weight / std).reshape(-1, 1, 1, 1)
#         weights = conv.weight * t
#
#         bn = nn.Identity()
#         conv = nn.Conv2d(in_channels=conv.in_channels,
#                          out_channels=conv.out_channels,
#                          kernel_size=conv.kernel_size,
#                          stride=conv.stride,
#                          padding=conv.padding,
#                          dilation=conv.dilation,
#                          groups=conv.groups,
#                          bias=True,
#                          padding_mode=conv.padding_mode)
#
#         conv.weight = torch.nn.Parameter(weights)
#         conv.bias = torch.nn.Parameter(bias)
#         return conv
#
#     def fuse_repvgg_block(self):
#         if self.deploy:
#             return
#         print(f"RepConv.fuse_repvgg_block")
#         self.rbr_dense = self.fuse_conv_bn(self.rbr_dense[0], self.rbr_dense[1])
#         self.rbr_1x1 = self.fuse_conv_bn(self.rbr_1x1[0], self.rbr_1x1[1])
#         rbr_1x1_bias = self.rbr_1x1.bias
#         weight_1x1_expanded = torch.nn.functional.pad(self.rbr_1x1.weight, [1, 1, 1, 1]) #膨胀成3*3
#         # Fuse self.rbr_identity
#         if (isinstance(self.rbr_identity, nn.BatchNorm2d) or isinstance(self.rbr_identity,nn.modules.batchnorm.SyncBatchNorm)):
#             identity_conv_1x1 = nn.Conv2d(
#                 in_channels=self.in_channels,
#                 out_channels=self.out_channels,
#                 kernel_size=1,
#                 stride=1,
#                 padding=0,
#                 groups=self.groups,
#                 bias=False)
#             identity_conv_1x1.weight.data = identity_conv_1x1.weight.data.to(self.rbr_1x1.weight.data.device)
#             identity_conv_1x1.weight.data = identity_conv_1x1.weight.data.squeeze().squeeze()
#             identity_conv_1x1.weight.data.fill_(0.0)
#             identity_conv_1x1.weight.data.fill_diagonal_(1.0)
#             identity_conv_1x1.weight.data = identity_conv_1x1.weight.data.unsqueeze(2).unsqueeze(3)
#             identity_conv_1x1 = self.fuse_conv_bn(identity_conv_1x1, self.rbr_identity)
#             bias_identity_expanded = identity_conv_1x1.bias
#             weight_identity_expanded = torch.nn.functional.pad(identity_conv_1x1.weight, [1, 1, 1, 1])
#         else:
#             bias_identity_expanded = torch.nn.Parameter(torch.zeros_like(rbr_1x1_bias))
#             weight_identity_expanded = torch.nn.Parameter(torch.zeros_like(weight_1x1_expanded))
#         self.rbr_dense.weight = torch.nn.Parameter(
#             self.rbr_dense.weight + weight_1x1_expanded + weight_identity_expanded)
#         self.rbr_dense.bias = torch.nn.Parameter(self.rbr_dense.bias + rbr_1x1_bias + bias_identity_expanded)
#         self.rbr_reparam = self.rbr_dense
#         self.deploy = True
#         if self.rbr_identity is not None:
#             del self.rbr_identity
#             self.rbr_identity = None
#         if self.rbr_1x1 is not None:
#             del self.rbr_1x1
#             self.rbr_1x1 = None
#         if self.rbr_dense is not None:
#             del self.rbr_dense
#             self.rbr_dense = None


class C3RepVGG(nn.Module):
    # CSP RepBottleneck with 3 convolutions, modified by wqt
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5, act=True):  # ch_in, ch_out, number, shortcut, groups, expansion
        super(C3RepVGG, self).__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1, act=act)
        self.cv2 = Conv(c1, c_, 1, 1, act=act)
        self.cv3 = Conv(2 * c_, c2, 1, act=act)  # act=FReLU(c2
        # self.m = nn.Sequential(*[RepBottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)])   #original RepBottleneck format
        self.m = nn.Sequential(*[RepBottleneck(c_, c_, shortcut, g, e=0.5) for _ in range(n)])   # change e=0.5, otherwise, bugs happens.

    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))


class RepBottleneck(Bottleneck):
    # Standard bottleneck
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, shortcut, groups, expansion
        super().__init__(c1, c2, shortcut=True, g=1, e=0.5)
        c_ = int(c2 * e)  # hidden channels
        self.cv2 = RepConv(c_, c2, 3, 1, g=g)

#1111111111111111111111111111111111111111111
class SEBlock1(nn.Module):

    def __init__(self, input_channels, internal_neurons):
        super(SEBlock1, self).__init__()
        self.down = nn.Conv2d(in_channels=input_channels, out_channels=internal_neurons, kernel_size=1, stride=1,
                              bias=True)
        self.up = nn.Conv2d(in_channels=internal_neurons, out_channels=input_channels, kernel_size=1, stride=1,
                            bias=True)
        self.input_channels = input_channels

    def forward(self, inputs):
        x = F.avg_pool2d(inputs, kernel_size=inputs.size(3))
        x = self.down(x)
        x = F.relu(x)
        x = self.up(x)
        x = torch.sigmoid(x)
        x = x.view(-1, self.input_channels, 1, 1)
        return inputs * x

class RepVGGBlock(nn.Module):

    def __init__(self, in_channels, out_channels, kernel_size=5,
                 stride=1, padding=2, dilation=2, groups=1, padding_mode='zeros', deploy=False, use_se=False):
        super(RepVGGBlock, self).__init__()
        self.deploy = deploy
        self.groups = groups
        self.in_channels = in_channels

        padding_11 = padding - kernel_size // 2

        self.nonlinearity = nn.SiLU()

        # self.nonlinearity = nn.ReLU()

        if use_se:
            self.se = SEBlock1(out_channels, internal_neurons=out_channels // 16)
        else:
            self.se = nn.Identity()

        if deploy:
            self.rbr_reparam = nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size,
                                         stride=stride,
                                         padding=padding, dilation=dilation, groups=groups, bias=True,
                                         padding_mode=padding_mode)

        else:
            self.rbr_identity = nn.BatchNorm2d(
                num_features=in_channels) if out_channels == in_channels and stride == 1 else None
            self.rbr_dense = conv_bn(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size,
                                     stride=stride, padding=padding, groups=groups)
            self.rbr_1x1 = conv_bn(in_channels=in_channels, out_channels=out_channels, kernel_size=3, stride=stride,
                                   padding=1, groups=groups)
            # print('RepVGG Block, identity = ', self.rbr_identity)

    def get_equivalent_kernel_bias(self):
        kernel3x3, bias3x3 = self._fuse_bn_tensor(self.rbr_dense)
        kernel1x1, bias1x1 = self._fuse_bn_tensor(self.rbr_1x1)
        kernelid, biasid = self._fuse_bn_tensor(self.rbr_identity)
        return kernel3x3 + self._pad_1x1_to_3x3_tensor(kernel1x1) + kernelid, bias3x3 + bias1x1 + biasid

    def _pad_1x1_to_3x3_tensor(self, kernel1x1):
        if kernel1x1 is None:
            return 0
        else:
            return torch.nn.functional.pad(kernel1x1, [1, 1, 1, 1])

    def _fuse_bn_tensor(self, branch):
        if branch is None:
            return 0, 0
        if isinstance(branch, nn.Sequential):
            kernel = branch.conv.weight
            running_mean = branch.bn.running_mean
            running_var = branch.bn.running_var
            gamma = branch.bn.weight
            beta = branch.bn.bias
            eps = branch.bn.eps
        else:
            assert isinstance(branch, nn.BatchNorm2d)
            if not hasattr(self, 'id_tensor'):
                input_dim = self.in_channels // self.groups
                kernel_value = np.zeros((self.in_channels, input_dim, 5, 5), dtype=np.float32)
                for i in range(self.in_channels):
                    kernel_value[i, i % input_dim, 1, 1] = 1
                self.id_tensor = torch.from_numpy(kernel_value).to(branch.weight.device)
            kernel = self.id_tensor
            running_mean = branch.running_mean
            running_var = branch.running_var
            gamma = branch.weight
            beta = branch.bias
            eps = branch.eps
        std = (running_var + eps).sqrt()
        t = (gamma / std).reshape(-1, 1, 1, 1)
        return kernel * t, beta - running_mean * gamma / std

    def forward(self, inputs):
        if hasattr(self, 'rbr_reparam'):
            return self.nonlinearity(self.se(self.rbr_reparam(inputs)))

        if self.rbr_identity is None:
            id_out = 0
        else:
            id_out = self.rbr_identity(inputs)

        return self.nonlinearity(self.se(self.rbr_dense(inputs) + self.rbr_1x1(inputs) + id_out))

    def fusevggforward(self, x):
        return self.nonlinearity(self.rbr_dense(x))


# repvgg block end
# -----------------------------
class C3RepVGGline(nn.Module):
    # CSP RepBottleneck with 3 convolutions, modified by wqt
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5, act=True):  # ch_in, ch_out, number, shortcut, groups, expansion
        super(C3RepVGGline, self).__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1, act=act)
        self.cv2 = Conv(c1, c_, 1, 1, act=act)
        self.cv3 = Conv(2 * c_, c2, 1, act=act)  # act=FReLU(c2
        # self.m = nn.Sequential(*[RepBottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)])   #original RepBottleneck format
        self.m = nn.Sequential(*[RepBottleneckline(c_, c_, shortcut, g, e=0.5) for _ in range(n)])   # change e=0.5, otherwise, bugs happens.

    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))


class RepBottleneckline(Bottleneck):
    # Standard bottleneck
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, shortcut, groups, expansion
        super().__init__(c1, c2, shortcut=True, g=1, e=0.5)
        c_ = int(c2 * e)  # hidden channels
        self.cv2 = RepVGGBlock(c_, c2, 5, 1)



class my_RepVGGBlock(nn.Module):

    def __init__(self, in_channels, out_channels, kernel_size=5,
                 stride=1, padding=2, dilation=2, groups=1, padding_mode='zeros', deploy=False, use_se=False):

        if(kernel_size==5):
            padding = 2
            dilation = 2
        else:
            padding=1
            dilation=1
        self.ker=kernel_size
        super(my_RepVGGBlock, self).__init__()
        self.deploy = deploy
        self.groups = groups
        self.in_channels = in_channels

        padding_11 = padding - kernel_size // 2

        self.nonlinearity = nn.SiLU()

        # self.nonlinearity = nn.ReLU()

        if use_se:
            self.se = SEBlock1(out_channels, internal_neurons=out_channels // 16)
        else:
            self.se = nn.Identity()

        if deploy:
            self.rbr_reparam = nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size,
                                         stride=stride,
                                         padding=padding, dilation=dilation, groups=groups, bias=True,
                                         padding_mode=padding_mode)

        else:
            self.rbr_identity = nn.BatchNorm2d(
                num_features=in_channels) if out_channels == in_channels and stride == 1 else None
            self.rbr_dense = conv_bn(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size,
                                     stride=stride, padding=padding, groups=groups)
            if(kernel_size==5):
                self.rbr_1x1 = conv_bn(in_channels=in_channels, out_channels=out_channels, kernel_size=3, stride=stride,
                                       padding=1, groups=groups)
            else:
                self.rbr_1x1 = conv_bn(in_channels=in_channels, out_channels=out_channels, kernel_size=1, stride=stride,
                                       padding=padding_11, groups=groups)

            # print('RepVGG Block, identity = ', self.rbr_identity)

    def get_equivalent_kernel_bias(self):
        kernel3x3, bias3x3 = self._fuse_bn_tensor(self.rbr_dense)
        kernel1x1, bias1x1 = self._fuse_bn_tensor(self.rbr_1x1)
        kernelid, biasid = self._fuse_bn_tensor(self.rbr_identity)
        return kernel3x3 + self._pad_1x1_to_3x3_tensor(kernel1x1) + kernelid, bias3x3 + bias1x1 + biasid

    def _pad_1x1_to_3x3_tensor(self, kernel1x1):
        if kernel1x1 is None:
            return 0
        else:
            return torch.nn.functional.pad(kernel1x1, [1, 1, 1, 1])

    def _fuse_bn_tensor(self, branch):
        if branch is None:
            return 0, 0
        if isinstance(branch, nn.Sequential):
            kernel = branch.conv.weight
            running_mean = branch.bn.running_mean
            running_var = branch.bn.running_var
            gamma = branch.bn.weight
            beta = branch.bn.bias
            eps = branch.bn.eps
        else:
            assert isinstance(branch, nn.BatchNorm2d)
            if not hasattr(self, 'id_tensor'):
                input_dim = self.in_channels // self.groups
                if (self.ker == 5):
                    kernel_value = np.zeros((self.in_channels, input_dim, 5, 5), dtype=np.float32)
                else:
                    kernel_value = np.zeros((self.in_channels, input_dim, 3, 3), dtype=np.float32)

                for i in range(self.in_channels):
                    kernel_value[i, i % input_dim, 1, 1] = 1
                self.id_tensor = torch.from_numpy(kernel_value).to(branch.weight.device)
            kernel = self.id_tensor
            running_mean = branch.running_mean
            running_var = branch.running_var
            gamma = branch.weight
            beta = branch.bias
            eps = branch.eps
        std = (running_var + eps).sqrt()
        t = (gamma / std).reshape(-1, 1, 1, 1)
        return kernel * t, beta - running_mean * gamma / std

    def forward(self, inputs):
        if hasattr(self, 'rbr_reparam'):
            return self.nonlinearity(self.se(self.rbr_reparam(inputs)))

        if self.rbr_identity is None:
            id_out = 0
        else:
            id_out = self.rbr_identity(inputs)

        return self.nonlinearity(self.se(self.rbr_dense(inputs) + self.rbr_1x1(inputs) + id_out))

    def fusevggforward(self, x):
        return self.nonlinearity(self.rbr_dense(x))


class SimAM(torch.nn.Module):
    def __init__(self, channels=None, out_channels=None, e_lambda=1e-4):
        super(SimAM, self).__init__()

        self.activaton = nn.Sigmoid()
        self.e_lambda = e_lambda

    def __repr__(self):
        s = self.__class__.__name__ + '('
        s += ('lambda=%f)' % self.e_lambda)
        return s

    @staticmethod
    def get_module_name():
        return "simam"

    def forward(self, x):
        b, c, h, w = x.size()

        n = w * h - 1

        x_minus_mu_square = (x - x.mean(dim=[2, 3], keepdim=True)).pow(2)
        y = x_minus_mu_square / (4 * (x_minus_mu_square.sum(dim=[2, 3], keepdim=True) / n + self.e_lambda)) + 0.5

        return x * self.activaton(y)


class Add(nn.Module):
    #  Add two tensors
    def __init__(self, arg):
        super(Add, self).__init__()
        self.arg = arg

    def forward(self, x):
        return torch.add(x[0], x[1])


class mySimAM(torch.nn.Module):
    def __init__(self, channels=None, out_channels=None, e_lambda=1e-4):
        super(mySimAM, self).__init__()

        self.activaton = nn.Sigmoid()
        self.e_lambda = e_lambda

    def __repr__(self):
        s = self.__class__.__name__ + '('
        s += ('lambda=%f)' % self.e_lambda)
        return s

    @staticmethod
    def get_module_name():
        return "simam"

    def forward(self, x):
        b, c, h, w = x.size()

        n = w * h - 1

        x_minus_mu_square = (x - x.mean(dim=[2, 3], keepdim=True)).pow(2)
        y = x_minus_mu_square / (4 * (x_minus_mu_square.sum(dim=[2, 3], keepdim=True) / n + self.e_lambda)) + 0.5

        return self.activaton(y)


class Concat_BiFPN_SimAM(nn.Module):
    # Concatenate a list of tensors along dimension
    def __init__(self, c1, c2):
        super(Concat_BiFPN_SimAM, self).__init__()
        self.w11 = nn.Parameter(torch.ones(c1, dtype=torch.float32), requires_grad=True)
        self.w12 = nn.Parameter(torch.ones(c1, dtype=torch.float32), requires_grad=True)
        self.epsilon = 0.0001
        self.conv = Conv(c1, c2)
        self.swish = MemoryEfficientSwish()
        self.simam = mySimAM()

    def forward(self, x):
        outs = self._forward(x)
        return outs

    def _forward(self, x):
        if len(x) == 2:
            e1 = self.simam(x[0])
            e2 = self.simam(x[1])
            e11 = e1.view(e1.shape[0], e1.shape[1], -1).mean(dim=2).squeeze()
            e12 = e2.view(e2.shape[0], e2.shape[1], -1).mean(dim=2).squeeze()
            weight11 = (e11) / (e11 + e12 + self.epsilon)
            weight12 = (e12) / (e11 + e12 + self.epsilon)
            weight11 = weight11.unsqueeze(-1).unsqueeze(-1)
            weight12 = weight12.unsqueeze(-1).unsqueeze(-1)
            x = self.conv(self.swish(weight11 * x[0] + weight12 * x[1]))
        return x

class fusion_cbam(nn.Module):
    def __init__(self, c1, c2):
        super(fusion_cbam, self).__init__()
        self.epsilon = 0.0001
        self.conv = Conv(c1, c2)
        self.swish = MemoryEfficientSwish()
        self.ECA = my_ECALayer(2*c1)
        self.spatial_attention = SpatialAttention(7)
        self.c1=c1
    def forward(self, x):
        outs = self._forward(x)
        return outs

    def _forward(self, x):
        if len(x) == 2:
            y1 = self.spatial_attention(x[0])*x[0]
            y2 = self.spatial_attention(x[1])*x[1]
            y=torch.cat([y1,y2],1)
            y_fusion = channel_shuffle(y, 2)
            e=self.ECA(y_fusion)
            e1, e2 = torch.split(e, self.c1, dim=1)
            e11 = e1.view(e1.shape[0], e1.shape[1], -1).mean(dim=2).squeeze()
            e12 = e2.view(e2.shape[0], e2.shape[1], -1).mean(dim=2).squeeze()
            weight11 = (e11) / (e11 + e12 + self.epsilon)
            weight12 = (e12) / (e11 + e12 + self.epsilon)
            weight11 = weight11.unsqueeze(-1).unsqueeze(-1)
            weight12 = weight12.unsqueeze(-1).unsqueeze(-1)
            x = self.conv(self.swish(weight11 * y1 + weight12 * y2))
        return x


class multiscale_fous(nn.Module):
    # Spatial Pyramid Pooling - Fast (SPPF) layer for YOLOv5 by Glenn Jocher
    def __init__(self, c1, c2, k=5):  # equivalent to SPP(k=(5, 9, 13))
        super().__init__()
        self.c1=c1
        # c_ = c1 // 2  # hidden channels    96=192/2
        # self.cv1 = Conv(c1, c_, 1, 1)
        # self.cv2 = Conv(c_ * 4, c2, 1, 1)
        self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)  #96
        self.conv1x3 = nn.Conv2d(self.c1, self.c1, (1, 3), 1, (0, 1), bias=False)
        self.conv3x1 = nn.Conv2d(self.c1, self.c1, (3, 1), 1, (1, 0), bias=False)
        self.conv1x5 = nn.Conv2d(self.c1, self.c1, (1, 5), 1, (0, 2), bias=False)
        self.conv5x1 = nn.Conv2d(self.c1, self.c1, (5, 1), 1, (2, 0), bias=False)
        self.conv1x7 = nn.Conv2d(self.c1, self.c1, (1, 7), 1, (0, 3), bias=False)
        self.conv7x1 = nn.Conv2d(self.c1, self.c1, (7, 1), 1, (3, 0), bias=False)
        self.conv3x3 = nn.Conv2d(self.c1, self.c1, 3, 1, 1, bias=False)
        self.conv5x5 = nn.Conv2d(self.c1, self.c1, 5, 1, 2, bias=False)
        self.conv7x7 = nn.Conv2d(self.c1, self.c1, 7, 1, 3, bias=False)
        self.conv1x1 = nn.Conv2d(self.c1, self.c1, 1, 1, 0, bias=False)
        self.bn = nn.BatchNorm2d(self.c1)
        self.bn2 = nn.BatchNorm2d(4*self.c1)
        self.act = nn.SiLU()
        self.m = TransformerBlock(c2, c2, 4, 1)
        self.cv2 = Conv(c1 * 4, c2, 1, 1)
        self.cvcon = Conv(c1 * 3, c2, 1, 1)
        self.max = nn.MaxPool2d(3, stride=1, padding=1)

    def forward(self, x):
        x0=self.act(self.bn(self.conv1x1(x)))

        x30=self.act(self.bn(self.conv1x1(x)))     #1x1
        x31 = self.act(self.bn(self.conv1x3(x30))) #3x1
        x32 = self.act(self.bn(self.conv3x1(x31))) #1x3
        x33 = self.act(self.bn(self.conv3x3(x32))) #3x3
        # x34 = self.act(self.bn(self.conv1x1(x32)))  # 3x3

        x50 = self.act(self.bn(self.conv1x1(x)))  # 1x1
        x51 = self.act(self.bn(self.conv1x5(x50)))  # 5x1
        x52 = self.act(self.bn(self.conv5x1(x51)))  # 1x5
        x53 = self.act(self.bn(self.conv5x5(x52)))  # 5x5
        x54 = self.act(self.bn(self.conv1x1(x53)))  # 5x5

        x70 = self.act(self.bn(self.conv1x1(x)))  # 1x1
        x71 = self.act(self.bn(self.conv1x7(x70)))  # 7x1
        x72 = self.act(self.bn(self.conv7x1(x71)))  # 1x7
        x73 = self.act(self.bn(self.conv7x7(x72)))  # 7x7
        # x74 = self.act(self.bn(self.conv1x1(x72)))  # 7x7
        # max1=self.max(x)
        # max2=self.act(self.bn(self.conv1x1(max1)))
        xcon=torch.cat([x33,x53,x73], 1)
        # xout=self.cv2(self.m((torch.cat([x0, x34,x74,max2], 1))))
        xout = self.cvcon(xcon)+x0 #加入自主力机制

        return xout

# def split_feature_map(x):
#     batch_size, channels, height, width = x.size()
#
#     # 切割操作
#     h_split = height // 2
#     w_split = width // 2
#
#     tensor_1 = x[:, :, :h_split, :w_split]
#     tensor_2 = x[:, :, :h_split, w_split:]
#     tensor_3 = x[:, :, h_split:, :w_split]
#     tensor_4 = x[:, :, h_split:, w_split:]
#
#     return tensor_1, tensor_2, tensor_3, tensor_4


def split_feature_map(x):
    batch_size, channels, height, width = x.size()

    # 切割操作
    h_split = height // 4
    w_split = width // 4

    tensor_11 = x[:, :, :h_split, 0:w_split]
    tensor_12 = x[:, :, :h_split, w_split:2*w_split]
    tensor_13 = x[:, :, :h_split, 2*w_split:3*w_split]
    tensor_14 = x[:, :, :h_split, 3*w_split:4*w_split]
    tensor_21 = x[:, :, h_split:2*h_split, 0:w_split]
    tensor_22 = x[:, :, h_split:2*h_split, w_split:2 * w_split]
    tensor_23 = x[:, :, h_split:2*h_split, 2 * w_split:3 * w_split]
    tensor_24 = x[:, :, h_split:2*h_split, 3 * w_split:4 * w_split]
    tensor_31 = x[:, :, 2*h_split:3 * h_split, 0:w_split]
    tensor_32 = x[:, :, 2*h_split:3 * h_split, w_split:2 * w_split]
    tensor_33 = x[:, :, 2*h_split:3 * h_split, 2 * w_split:3 * w_split]
    tensor_34 = x[:, :, 2*h_split:3 * h_split, 3 * w_split:4 * w_split]
    tensor_41 = x[:, :, 3 * h_split:4 * h_split, 0:w_split]
    tensor_42 = x[:, :, 3 * h_split:4 * h_split, w_split:2 * w_split]
    tensor_43 = x[:, :, 3 * h_split:4 * h_split, 2 * w_split:3 * w_split]
    tensor_44 = x[:, :, 3 * h_split:4 * h_split, 3 * w_split:4 * w_split]

    return tensor_11,tensor_12,tensor_13,tensor_14,\
           tensor_21,tensor_22,tensor_23,tensor_24,\
           tensor_31,tensor_32,tensor_33,tensor_34,\
           tensor_41,tensor_42,tensor_43,tensor_44



def combine_feature_map(tensor_11,tensor_12,tensor_13,tensor_14,tensor_21,tensor_22,tensor_23,tensor_24,tensor_31,tensor_32,tensor_33,tensor_34,tensor_41,tensor_42,tensor_43,tensor_44):
    output0 = torch.cat((tensor_11,tensor_12,tensor_13,tensor_14), dim=3)
    output1 = torch.cat((tensor_21,tensor_22,tensor_23,tensor_24), dim=3)
    output2 = torch.cat((tensor_31,tensor_32,tensor_33,tensor_34), dim=3)
    output3 = torch.cat((tensor_41,tensor_42,tensor_43,tensor_44), dim=3)
    output = torch.cat((output0, output1,output2,output3), dim=2)
    return output

class split_se(nn.Module):
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        self.se=my_SELayer(c1)
    def forward(self, x):

        tensor_11,tensor_12,tensor_13,tensor_14,\
        tensor_21,tensor_22,tensor_23,tensor_24,\
        tensor_31,tensor_32,tensor_33,tensor_34,\
        tensor_41,tensor_42,tensor_43,tensor_44 = split_feature_map(x)

        tensor_11 = self.se(tensor_11)
        tensor_12 = self.se(tensor_12)
        tensor_13 = self.se(tensor_13)
        tensor_14 = self.se(tensor_14)
        tensor_21 = self.se(tensor_21)
        tensor_22 = self.se(tensor_22)
        tensor_23 = self.se(tensor_23)
        tensor_24 = self.se(tensor_24)
        tensor_31 = self.se(tensor_31)
        tensor_32 = self.se(tensor_32)
        tensor_33 = self.se(tensor_33)
        tensor_34 = self.se(tensor_34)
        tensor_41 = self.se(tensor_41)
        tensor_42 = self.se(tensor_42)
        tensor_43 = self.se(tensor_43)
        tensor_44 = self.se(tensor_44)

        # y = combine_feature_map(tensor_11,tensor_12,tensor_13,tensor_14,
        #                         tensor_21,tensor_22,tensor_23,tensor_24,
        #                         tensor_31,tensor_32,tensor_33,tensor_34,
        #                         tensor_41,tensor_42,tensor_43,tensor_44)
        total_tensor_weight= tensor_11+tensor_12+tensor_13+tensor_14+\
                            tensor_21+tensor_22+tensor_23+tensor_24+\
                            tensor_31+tensor_32+tensor_33+tensor_34+\
                            tensor_41+tensor_42+tensor_43+tensor_44
        return total_tensor_weight


class C3_Faster_trans(C3):
    # C3 module with cross-convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)
        self.m = nn.Sequential(*(Faster_Block_trans(c_, c_) for _ in range(n)))

class Faster_Block_trans(nn.Module):   #当作卷积块用
    def __init__(self,
                 inc,
                 dim,
                 stride=1,
                 n_div=4,
                 mlp_ratio=2,
                 drop_path=0.0,    #可以调节
                 layer_scale_init_value=0.0,
                 pconv_fw_type='split_cat'
                 ):
        super().__init__()
        self.dim = dim
        self.mlp_ratio = mlp_ratio
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.n_div = n_div

        mlp_hidden_dim = int(dim * mlp_ratio)

        mlp_layer = [
            Conv(dim, mlp_hidden_dim, 1),
            nn.Conv2d(mlp_hidden_dim, dim, 1, bias=False)
        ]

        self.mlp = nn.Sequential(*mlp_layer)
        # self.trans = TransformerBlock(dim, dim, 4, 1)

        self.spatial_mixing = Partial_conv3_trans(
            dim,
            n_div,
            # stride
            pconv_fw_type
        )

        self.adjust_channel = None
        if inc != dim:
            self.adjust_channel = Conv(inc, dim, 1)

        # if layer_scale_init_value > 0:
        #     self.layer_scale = nn.Parameter(layer_scale_init_value * torch.ones((dim)), requires_grad=True)
        #     self.forward = self.forward_layer_scale
        # else:
        #     self.forward = self.forward

    # def forward(self, x):
    #     if self.adjust_channel is not None:
    #         x = self.adjust_channel(x)
    #     # shortcut = x
    #     shortcut,x = self.spatial_mixing(x)
    #     x = shortcut + self.drop_path(self.mlp(x))
    #     return x
    #
    # def forward_layer_scale(self, x):
    #     # shortcut = x
    #     shortcut,x = self.spatial_mixing(x)
    #     x = shortcut + self.drop_path(
    #         self.layer_scale.unsqueeze(-1).unsqueeze(-1) * self.mlp(x))
    #     return x
    def forward(self, x):
        if self.adjust_channel is not None:
            x = self.adjust_channel(x)
        # x = self.trans(x)
        shortcut = x
        x = self.spatial_mixing(x)
        x = shortcut + self.drop_path(self.mlp(x))
        return x

    def forward_layer_scale(self, x):
        # x = self.trans(x)
        shortcut = x
        x = self.spatial_mixing(x)
        x = shortcut + self.drop_path(
            self.layer_scale.unsqueeze(-1).unsqueeze(-1) * self.mlp(x))
        return x

# class Partial_conv3_trans(nn.Module):    #按论文来的
#     def __init__(self, dim, n_div,forward):
#         super().__init__()
#         self.dim_conv3 = dim // n_div
#         self.dim_untouched = dim - self.dim_conv3
#         # self.partial_conv3 = nn.Conv2d(self.dim_conv3, self.dim_conv3, 3, 1, 1, bias=False)
#         # self.partial_conv3x3 = nn.Conv2d(self.dim_conv3, self.dim_conv3, 3, 1, 1, bias=False)
#         # self.partial_conv1x1 = nn.Conv2d(self.dim_conv3, self.dim_conv3, 1, 1, 0, bias=False)
#         # self.partial_conv1x3 = nn.Conv2d(self.dim_conv3, self.dim_conv3, (1, 3), 1, (0, 1), bias=False)
#         # self.partial_conv3x1 = nn.Conv2d(self.dim_conv3, self.dim_conv3, (3, 1), 1, (1, 0), bias=False)
#
#         # self.bn = nn.BatchNorm2d(self.dim_conv3)
#         # self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
#         self.conv=Conv(self.dim_untouched,self.dim_untouched,3,1)
#         # self.conv2 = Conv(self.dim_conv3, 2*self.dim_conv3, 1, 1)
#         # self.conv3 = Conv(2*self.dim_conv3, self.dim_conv3, 1, 1)
#         # self.splitse = split_se(dim,dim)
#         self.se=my_SELayer2(dim)
#         if forward == 'slicing':
#             self.forward = self.forward_slicing
#         elif forward == 'split_cat':
#             self.forward = self.forward_split_cat
#         else:
#             raise NotImplementedError
#         # self.m = TransformerBlock(dim, dim, 4, 1)
#
#     def forward_slicing(self, x):
#         # only for inference
#         x = x.clone()  # !!! Keep the original input intact for the residual connection later
#         x[:, :self.dim_conv3, :, :] = self.partial_conv3(x[:, :self.dim_conv3, :, :])
#         return x
#
#     def forward_split_cat(self, x):
#         # for training/inference
#
#         b = self.se(x)
#         xnew0, indices = paixu(b, x)
#         x1, x2 = torch.split(xnew0, [self.dim_untouched, self.dim_conv3], dim=1)
#         x1 = self.conv(x1)
#
#         # xnew1 = torch.cat((x1, x2), 1)
#         xout = tttxxx(x2, x1)
#         # xout = self.conv2(xout)
#         # xout = self.conv1(xout)
#         # xout = xout+x
#         # # xnew1=self.all_conv3(xnew0)
#         # restored_xnew1 = inverse_paixu(xnew1, indices)
#         #
#         # return x, restored_xnew1
#         # x1, x2 = torch.split(x, [self.dim_conv3, self.dim_untouched], dim=1)
#         # # x1 = self.partial_conv3(x1)
#         # x3x3_1 = self.bn(self.partial_conv3x3(x1))
#         # x3x3_2 = self.bn(self.partial_conv3x3(x1))
#         # x3x3_3 = self.bn(self.partial_conv3x3(x1))
#         # x3x3_4 = self.bn(self.partial_conv3x3(x1))
#         # x3x3_5 = self.bn(self.partial_conv3x3(x1))
#         # x3x3_6 = self.bn(self.partial_conv3x3(x1))
#         # x3x3_7 = self.bn(self.partial_conv3x3(x1))
#         # x3x3_8 = self.bn(self.partial_conv3x3(x1))
#         # x3x3_9 = self.bn(self.partial_conv3x3(x1))
#         # x1x3=self.bn(self.partial_conv1x3(x1))
#         # x3x1=self.bn(self.partial_conv3x1(x1))
#         # x1x1 = self.bn(self.partial_conv1x1(x1))
#         # xf=x3x3_1
#         # xff = torch.cat((xf, x2), 1)
#         # restored_xnew1 = inverse_paixu(xff, indices)
#         # xout=self.m(restored_xnew1)
#         return xout

class Partial_conv3_trans(nn.Module):    #按论文来的
    def __init__(self, dim, n_div,forward):
        super().__init__()
        self.dim_conv3 = dim // n_div
        self.dim_untouched = dim - self.dim_conv3
        # self.partial_conv3 = nn.Conv2d(self.dim_conv3, self.dim_conv3, 3, 1, 1, bias=False)
        # self.partial_conv3x3 = nn.Conv2d(self.dim_conv3, self.dim_conv3, 3, 1, 1, bias=False)
        # self.partial_conv1x1 = nn.Conv2d(self.dim_conv3, self.dim_conv3, 1, 1, 0, bias=False)
        # self.partial_conv1x3 = nn.Conv2d(self.dim_conv3, self.dim_conv3, (1, 3), 1, (0, 1), bias=False)
        # self.partial_conv3x1 = nn.Conv2d(self.dim_conv3, self.dim_conv3, (3, 1), 1, (1, 0), bias=False)
        self.conv22 = Conv(self.dim_conv3, self.dim_conv3, 1, 1)

        # self.bn = nn.BatchNorm2d(self.dim_conv3)
        # self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
        self.conv=Conv(self.dim_untouched,self.dim_untouched,3,1)
        # self.conv2 = Conv(self.dim_conv3, 2*self.dim_conv3, 1, 1)
        # self.conv3 = Conv(2*self.dim_conv3, self.dim_conv3, 1, 1)
        # self.splitse = split_se(dim,dim)
        self.se=my_SELayer(dim)
        if forward == 'slicing':
            self.forward = self.forward_slicing
        elif forward == 'split_cat':
            self.forward = self.forward_split_cat
        else:
            raise NotImplementedError
        # self.m = TransformerBlock(dim, dim, 4, 1)

    def forward_slicing(self, x):
        # only for inference
        x = x.clone()  # !!! Keep the original input intact for the residual connection later
        x[:, :self.dim_conv3, :, :] = self.partial_conv3(x[:, :self.dim_conv3, :, :])
        return x

    def forward_split_cat(self, x):
        # for training/inference

        b = self.se(x)
        xnew0, indices = paixu(b, x)
        x1, x2 = torch.split(xnew0, [self.dim_untouched, self.dim_conv3], dim=1)
        x1 = self.conv(x1)
        x2=self.conv22(x2)
        # xnew1 = torch.cat((x1, x2), 1)
        xout = tttxxx(x2, x1)
        # xout = self.conv2(xout)
        # xout = self.conv1(xout)
        # xout = xout+x
        # # xnew1=self.all_conv3(xnew0)
        # restored_xnew1 = inverse_paixu(xnew1, indices)
        #
        # return x, restored_xnew1
        # x1, x2 = torch.split(x, [self.dim_conv3, self.dim_untouched], dim=1)
        # # x1 = self.partial_conv3(x1)
        # x3x3_1 = self.bn(self.partial_conv3x3(x1))
        # x3x3_2 = self.bn(self.partial_conv3x3(x1))
        # x3x3_3 = self.bn(self.partial_conv3x3(x1))
        # x3x3_4 = self.bn(self.partial_conv3x3(x1))
        # x3x3_5 = self.bn(self.partial_conv3x3(x1))
        # x3x3_6 = self.bn(self.partial_conv3x3(x1))
        # x3x3_7 = self.bn(self.partial_conv3x3(x1))
        # x3x3_8 = self.bn(self.partial_conv3x3(x1))
        # x3x3_9 = self.bn(self.partial_conv3x3(x1))
        # x1x3=self.bn(self.partial_conv1x3(x1))
        # x3x1=self.bn(self.partial_conv3x1(x1))
        # x1x1 = self.bn(self.partial_conv1x1(x1))
        # xf=x3x3_1
        # xff = torch.cat((xf, x2), 1)
        # restored_xnew1 = inverse_paixu(xff, indices)
        # xout=self.m(restored_xnew1)
        return xout

def tttxxx(x0, x1):
    batch_size, num_channels0, height, width = x0.size()
    batch_size, num_channels1, height, width = x1.size()
    interval = num_channels1 // num_channels0
    # x2 = torch.zeros(batch_size, 4 * num_channels0, height, width, device=x0.device)
    x2 = torch.cat([x0,x1],1)
    x2[:,0::4,:,:] = x0
    x2[:,1::4,:,:] = x1[:,0::3,:,:]
    x2[:,2::4, :, :] = x1[:, 1::3, :, :]
    x2[:,3::4, :, :] = x1[:, 2::3, :, :]
    # for i in range(num_channels0):
    #     start_channel = 4 * i  # 插入位置的起始通道索引
    #     end_channel = start_channel + interval  # 插入位置的结束通道索引
    #     # 将 x0 的通道插入到 x2 中
    #     x2[:, start_channel, :, :] = x0[:, i, :, :]
    # # Interleave channels
    #     x2[:, start_channel + 1:end_channel + 1, :, :] \
    #         = x1[:, i * num_channels1 // num_channels0:(i + 1) * num_channels1 // num_channels0,:, :]
    return x2

class my_SELayer2(nn.Module):
    def __init__(self, channel, reduction=4):
        super(my_SELayer2, self).__init__()
        # Squeeze操作
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # Excitation操作(FC+ReLU+FC+Sigmoid)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel),
            h_sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x)
        y = y.view(b, c)
        # y = self.fc(y).view(b,c,1,1).squeeze(-1).transpose(-1, -2)  # 学习到的每一channel的权重
        y = self.fc(y)
        return y

# class Partial_conv3_maxppol(nn.Module):  # 按论文来的
#     def __init__(self, dim,dim2):
#         super().__init__()
#         self.dim_conv3 = dim // 4
#         self.dim_untouched = dim - self.dim_conv3
#         self.conv = Conv(self.dim_conv3, self.dim_conv3, 3, 2)
#         self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
#         self.se = my_SELayer(dim)
#
#         self.forward = self.forward_split_cat
#
#     def forward_split_cat(self, x):
#         # for training/inference
#         b = self.se(x)
#         xnew0, indices = paixu(b, x)
#         x1, x2 = torch.split(xnew0, [self.dim_conv3, self.dim_untouched], dim=1)
#         x2 = self.maxpool(x2)
#         x1 = self.conv(x1)
#         xout = tttxxx(x1, x2)
#         return xout

class Partial_conv3_maxppol(nn.Module):  # 按论文来的
    def __init__(self, dim,dim2):
        super().__init__()
        self.dim_conv3 = dim // 4
        self.dim_untouched = dim - self.dim_conv3
        self.conv = Conv(self.dim_untouched, self.dim_untouched, 3, 2)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.se = my_SELayer(dim)
        self.conv22 = Conv(self.dim_conv3, self.dim_conv3, 1, 1)

        self.forward = self.forward_split_cat

    def forward_split_cat(self, x):
        # for training/inference
        b = self.se(x)
        xnew0, indices = paixu(b, x)
        x1, x2 = torch.split(xnew0, [self.dim_untouched, self.dim_conv3], dim=1)
        x2 = self.maxpool(x2)
        x2=self.conv22(x2)
        x1 = self.conv(x1)
        xout = tttxxx(x2, x1)
        return xout

class C3_Shuffle_Block(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2,stride=1, n=1):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        self.n = n
        self.m = nn.Sequential(*(Shuffle_Block(c1, c2, stride) for _ in range(n)))
    def forward(self, x):
        return self.m(x)

class C3_Shuffle_Block_nose(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2,stride=1, n=1):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        self.n = n
        self.m = nn.Sequential(*(Shuffle_Block_noSE(c1, c2, stride) for _ in range(n)))
    def forward(self, x):
        return self.m(x)
class C3_Shuffle_Block1(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2,stride=1, n=1):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        self.n = n
        self.m = nn.Sequential(*(Shuffle_Block(c1, c2, stride) for _ in range(n)))
        self.cv1 = DCNv2(c2, c2, 3, 1, groups=1)
    def forward(self, x):
        return self.cv1(self.m(x))


class C3_Shuffle_Block_new3(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, stride=1, n=1):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        self.n=n
        self.c1=c1
        self.c2=c2
        self.c= Shuffle_Block(self.c1, self.c2, stride)
        self.c3 = Conv(3*self.c2, self.c2, 1)
    def forward(self, x):
        x1=self.c(x)
        x2=self.c(x1)
        x3=self.c(x2)
        xout=torch.cat((x1,x2,x3),dim=1)
        xout=self.c3(xout)
        return xout

class C3_Shuffle_Block_new7(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, stride=1, n=1):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        self.n=n
        self.c1=c1
        self.c2=c2
        self.c= Shuffle_Block(self.c1, self.c2, stride)
        self.c7 = Conv(7*self.c2, self.c2, 1)

    def forward(self, x):
        x1= self.c(x)
        x2 = self.c(x1)
        x3 = self.c(x2)
        x4 = self.c(x3)
        x5 = self.c(x4)
        x6 = self.c(x5)
        x6 = self.c(x5)
        x7 = self.c(x6)
        xout = torch.cat((x1, x2, x3, x4, x5, x6, x7), dim=1)
        xout = self.c7(xout)
        return xout


class Ctiny(nn.Module):
    #yolov4-tiny bottleneck
    def __init__(self,c1, c2, n=1,e=0.5):
        super(Ctiny, self).__init__()
        c_ = int(c2 * e)  # hidden channels
        c1=c1//2
        self.cv1 = Conv(c1, c_, 3, 1,act=nn.LeakyReLU(0.1, inplace=True))
        self.cv2 = Conv(c1, c_, 3, 1,act=nn.LeakyReLU(0.1, inplace=True))
        self.cv3 = Conv(2 * c_, c2, 1,act=nn.LeakyReLU(0.1, inplace=True))

    def forward(self,x):
        out = torch.chunk(x, 2, dim=1)
        x1=out[1]
        y=self.cv1(x1)
        return self.cv3(torch.cat((self.cv2(y),y), dim=1))

class Ctinye(nn.Module):
    #yolov4-tiny bottleneck
    def __init__(self,c1, c2, n=1,e=0.5):
        super(Ctinye, self).__init__()
        c_ = int(c2 * e)  # hidden channels
        c1=c1//2
        self.cv1 = RepConve(c1, c_, 3, 1,act=nn.LeakyReLU(0.1, inplace=True))
        self.cv2 = RepConve(c1, c_, 3, 1,act=nn.LeakyReLU(0.1, inplace=True))
        self.cv3 = Conv(2 * c_, c2, 1,act=nn.LeakyReLU(0.1, inplace=True))
        # self.cat = Concat_fuse_new(1)
        self.cat = Concat(1)
    def forward(self,x):
        out = torch.chunk(x, 2, dim=1)
        x1=out[1]
        y=self.cv1(x1)
        return self.cv3(self.cat((self.cv2(y),y)))


#*****************************DBB****************************#

#*****************************DBB****************************#


class CSSEC3Ghost(C3):
    # C3 module with GhostBottleneck()
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__(c1, c2, n, shortcut, g, e)
        c_ = int(c2 * e)  # hidden channels
        self.m = nn.Sequential(*(CSSEGhostBottleneck(c_, c_) for _ in range(n)))


class CSSEGhostBottleneck(nn.Module):
    # Ghost Bottleneck https://github.com/huawei-noah/ghostnet
    def __init__(self, c1, c2, k=3, s=1):  # ch_in, ch_out, kernel, stride
        super().__init__()
        c_ = c2 // 2
        self.conv = nn.Sequential(SEGhostConv(c1, c_, 1, 1),  # pw
                                  DWConv(c_, c_, k, s, act=False) if s == 2 else nn.Identity(),  # dw
                                  GhostConv(c_, c2, 1, 1, act=False))  # pw-linear
        self.shortcut = nn.Sequential(DWConv(c1, c1, k, s, act=False),
                                      Conv(c1, c2, 1, 1, act=False)) if s == 2 else nn.Identity()

        self.cv2 = Conv(2*c2,c2,1,1)
    def forward(self, x):
        x = torch.cat([self.conv(x),self.shortcut(x)],1)
        xout = self.cv2(channel_shuffle(x,2))
        return xout

class SEGhostConv(nn.Module):
    # Ghost Convolution https://github.com/huawei-noah/ghostnet
    def __init__(self, c1, c2, k=1, s=1, g=1, act=True):  # ch_in, ch_out, kernel, stride, groups
        super().__init__()
        c_ = c2 // 2  # hidden channels
        # self.eca = ECALayer(c1)
        # self.cbam = CBAM(c1)
        # self.ecbam = ECBAM(c1)
        # self.ca = CoordAtt(c1,c1)
        self.se = SELayer(c2)

        self.cv1 = Conv(c1, c_, k, s, None, g, act)  # c_是隐层，即降维后的层，是一个分离卷积
        self.cv2 = Conv(c_, c_, 5, 1, None, c_, act=False)
        self.cv3 = Conv(c_, c_, 3, 1, None, c_, act=False)
        self.cv4 = Conv(c_, c_, 1, 1, None, c_, act=False)
        self.act = nn.SiLU()
        # self.cv2=DCNv2(c_, c_, 3, 1, groups=g)

    def forward(self, x):
        y = self.cv1(x)
        return self.se(torch.cat([y, self.act((self.cv2(y)+self.cv3(y)+self.cv4(y))/3)], 1))




class caGhostConv(nn.Module):
    # Ghost Convolution https://github.com/huawei-noah/ghostnet
    def __init__(self, c1, c2, k=1, s=1, g=1, act=True):  # ch_in, ch_out, kernel, stride, groups
        super().__init__()
        c_ = c2 // 2  # hidden channels
        # self.eca = ECALayer(c1)
        # self.cbam = CBAM(c1)
        # self.ecbam = ECBAM(c1)
        # self.ca = CoordAtt(c1,c1)
        self.ca = CoordAtt(c2, c2)

        self.cv1 = Conv(c1, c_, k, s, None, g, act)  # c_是隐层，即降维后的层，是一个分离卷积
        self.cv2 = Conv(c_, c_, 5, 1, None, c_, act)
        # self.cv2=DCNv2(c_, c_, 3, 1, groups=g)

    def forward(self, x):
        y = self.cv1(x)
        return self.ca(torch.cat([y, self.cv2(y)], 1))

class CoT3(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # act=FReLU(c2)
        self.m = nn.Sequential(*[CoTBottleneck(c_, c_, shortcut, g, e=1.0) for _ in range(n)])
        # self.m = nn.Sequential(*[CrossConv(c_, c_, 3, 1, g, 1.0, shortcut) for _ in range(n)])

    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))

class CoTBottleneck(nn.Module):
    # Standard bottleneck https://github.com/iscyy/yoloair
    def __init__(self, c1, c2, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, shortcut, groups, expansion
        super(CoTBottleneck, self).__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = CoT(c_, 3)
        self.add = shortcut and c1 == c2

    def forward(self, x):
        return x + self.cv2(self.cv1(x)) if self.add else self.cv2(self.cv1(x))

class CoT(nn.Module):
    # Contextual Transformer Networks https://arxiv.org/abs/2107.12292
    def __init__(self, dim=512, kernel_size=3):
        super().__init__()
        self.dim = dim
        self.kernel_size = kernel_size

        self.key_embed = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=kernel_size, padding=kernel_size // 2, groups=4, bias=False),
            nn.BatchNorm2d(dim),
            nn.ReLU()
        )
        self.value_embed = nn.Sequential(
            nn.Conv2d(dim, dim, 1, bias=False),
            nn.BatchNorm2d(dim)
        )

        factor = 4
        self.attention_embed = nn.Sequential(
            nn.Conv2d(2 * dim, 2 * dim // factor, 1, bias=False),
            nn.BatchNorm2d(2 * dim // factor),
            nn.ReLU(),
            nn.Conv2d(2 * dim // factor, kernel_size * kernel_size * dim, 1)
        )

    def forward(self, x):
        bs, c, h, w = x.shape
        k1 = self.key_embed(x)  # bs,c,h,w
        v = self.value_embed(x).view(bs, c, -1)  # bs,c,h,w

        y = torch.cat([k1, x], dim=1)  # bs,2c,h,w
        att = self.attention_embed(y)  # bs,c*k*k,h,w
        att = att.reshape(bs, c, self.kernel_size * self.kernel_size, h, w)
        att = att.mean(2, keepdim=False).view(bs, c, -1)  # bs,c,h*w
        k2 = F.softmax(att, dim=-1) * v
        k2 = k2.view(bs, c, h, w)

        return k1 + k2

class MYCoT(nn.Module):
    # Contextual Transformer Networks https://arxiv.org/abs/2107.12292
    # def __init__(self, dim,dim2=512):
    def __init__(self, dim, c2, k=1, s=1, p=None, g=1, act=True):
        super().__init__()
        self.dim = dim
        self.kernel_size = 1

        self.key_embed = nn.Sequential(
           # nn.Conv2d(dim, dim, kernel_size=1, padding=1 // 2, groups=4, bias=False),
           # nn.BatchNorm2d(dim),
            myConv(dim,dim,k=1,g=4),
            nn.ReLU()
        	# nn.SiLU()
        )
        self.value_embed = nn.Sequential(
            #nn.Conv2d(dim, dim, 1, bias=False),
            #nn.BatchNorm2d(dim)
            myConv(dim,dim,k=1)
        )

        # factor = 4
        factor = 2

        self.attention_embed = nn.Sequential(
           # nn.Conv2d(2 * dim, 2 * dim // factor, 1, bias=False),
            #nn.BatchNorm2d(2 * dim // factor),
            myConv(2 * dim, 2 * dim // factor, k=1),
            nn.ReLU(),
            # nn.SiLU(),
            nn.Conv2d(2 * dim // factor, 1 * 1 * dim, 1)
        )

    def forward(self, x):
        bs, c, h, w = x.shape
        k1 = self.key_embed(x)  # bs,c,h,w
        v = self.value_embed(x).view(bs, c, -1)  # bs,c,h,w

        y = torch.cat([k1, x], dim=1)  # bs,2c,h,w
        att = self.attention_embed(y)  # bs,c*k*k,h,w
        att = att.reshape(bs, c, self.kernel_size * self.kernel_size, h, w)
        att = att.mean(2, keepdim=False).view(bs, c, -1)  # bs,c,h*w
        k2 = F.softmax(att, dim=-1) * v
        k2 = k2.view(bs, c, h, w)

        return k1 + k2
# class MYCoT(nn.Module):
#     # Contextual Transformer Networks https://arxiv.org/abs/2107.12292
#     # def __init__(self, dim,dim2=512):
#     def __init__(self, dim, c2, k=1, s=1, p=None, g=1, act=True):
#         super().__init__()
#         self.dim = dim
#         self.kernel_size = 3
#
#         self.key_embed = nn.Sequential(
#             nn.Conv2d(dim, dim, kernel_size=3, padding=3 // 2, groups=4, bias=False),
#             nn.BatchNorm2d(dim),
#             nn.ReLU()
#         )
#         self.value_embed = nn.Sequential(
#             nn.Conv2d(dim, dim, 1, bias=False),
#             nn.BatchNorm2d(dim)
#         )
#
#         factor = 4
#         self.attention_embed = nn.Sequential(
#             nn.Conv2d(2 * dim, 2 * dim // factor, 1, bias=False),
#             nn.BatchNorm2d(2 * dim // factor),
#             nn.ReLU(),
#             nn.Conv2d(2 * dim // factor, 3 * 3 * dim, 1)
#         )
#
#     def forward(self, x):
#         bs, c, h, w = x.shape
#         k1 = self.key_embed(x)  # bs,c,h,w
#         v = self.value_embed(x).view(bs, c, -1)  # bs,c,h,w
#
#         y = torch.cat([k1, x], dim=1)  # bs,2c,h,w
#         att = self.attention_embed(y)  # bs,c*k*k,h,w
#         att = att.reshape(bs, c, self.kernel_size * self.kernel_size, h, w)
#         att = att.mean(2, keepdim=False).view(bs, c, -1)  # bs,c,h*w
#         k2 = F.softmax(att, dim=-1) * v
#         k2 = k2.view(bs, c, h, w)
#
#         return k1 + k2

class CABlock(nn.Module):
    def __init__(self, inp, oup, reduction=32):
        super(CABlock, self).__init__()
        mip = max(8, inp // reduction)

        self.conv1 = nn.Conv2d(inp, mip, 1, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(mip)
        self.act = h_swish()

        self.conv_h = nn.Conv2d(mip, oup, 1, 1, bias=False)
        self.conv_w = nn.Conv2d(mip, oup, 1, 1, bias=False)


    def forward(self, x):
        identity = x
        _, _, h, w = x.size()
        pool_h = nn.AdaptiveAvgPool2d((h, 1))
        x_h = pool_h(x)
        pool_w = nn.AdaptiveAvgPool2d((1, w))
        x_w = pool_w(x).permute(0, 1, 3, 2)

        y = torch.cat([x_h, x_w], dim=2)
        y = self.conv1(y)
        y = self.bn1(y)
        y = self.act(y)

        y_h, y_w = torch.split(y, [h, w], dim=2)
        y_w = y_w.permute(0, 1, 3, 2)

        a_h = self.conv_h(y_h).sigmoid()
        a_w = self.conv_w(y_w).sigmoid()

        return identity * a_w * a_h


class C3CA(nn.Module):
    # CSP Bottleneck with 3 convolutions
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):  # ch_in, ch_out, number, shortcut, groups, expansion
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(2 * c_, c2, 1)  # act=FReLU(c2)
        self.m = nn.Sequential(*(CABlock(c_, c_, shortcut) for _ in range(n)))
        # self.m = nn.Sequential(*[CrossConv(c_, c_, 3, 1, g, 1.0, shortcut) for _ in range(n)])
    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))


class SelfAttention(nn.Module):
    def __init__(self, in_channels, in_channel2, n=1, shortcut=True, g=1, e=0.5):
        super(SelfAttention, self).__init__()
        self.query = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.key = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.value = nn.Conv2d(in_channels, in_channels, kernel_size=1)

    def forward(self, x):
        b, c, h, w = x.size()
        query = self.query(x).view(b, c, -1).permute(0, 2, 1)  # 查询特征
        key = self.key(x).view(b, c, -1)  # 键特征
        value = self.value(x).view(b, c, -1)  # 值特征

        attention = torch.softmax(torch.bmm(query, key), dim=2)  # 注意力权重计算
        out = torch.bmm(value, attention.permute(0, 2, 1)).view(b, c, h, w)  # 特征加权
        return out


# 结合BiFPN 设置可学习参数 学习不同分支的权重
# 两个分支concat操作
class myBiFPN_Concat2(nn.Module):
    def __init__(self, dimension=1):
        super(myBiFPN_Concat2, self).__init__()
        self.d = dimension
        self.w = nn.Parameter(torch.ones(2, dtype=torch.float32), requires_grad=True)
        self.epsilon = 0.0001
        # 设置可学习参数 nn.Parameter的作用是：将一个不可训练的类型Tensor转换成可以训练的类型

        # 并且会向宿主模型注册该参数 成为其一部分 即model.parameters()会包含这个parameter
        # 从而在参数优化的时候可以自动一起优化

    def forward(self, x):
        w = self.w
        weight = w / (torch.sum(w, dim=0) + self.epsilon)  # 将权重进行归一化
        # Fast normalized fusion
        x = [weight[0] * x[0], weight[1] * x[1]]
        return torch.cat(x, self.d)


# 三个分支concat操作
class myBiFPN_Concat3(nn.Module):
    def __init__(self, dimension=1):
        super(myBiFPN_Concat3, self).__init__()
        self.d = dimension
        self.w = nn.Parameter(torch.ones(3, dtype=torch.float32), requires_grad=True)
        self.epsilon = 0.0001

    def forward(self, x):
        w = self.w
        weight = w / (torch.sum(w, dim=0) + self.epsilon)  # 将权重进行归一化
        # Fast normalized fusion
        x = [weight[0] * x[0], weight[1] * x[1], weight[2] * x[2]]
        return torch.cat(x, self.d)

class MYCoTCross(nn.Module):
    # Contextual Transformer Networks https://arxiv.org/abs/2107.12292
    # def __init__(self, dim,dim2=512):
    def __init__(self, dim, c2, k=1, s=1, p=None, g=1, act=True):
        super().__init__()
        self.dim = dim
        self.kernel_size = 1

        self.key_embed = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=1, padding=1 // 2, groups=4, bias=False),
            nn.BatchNorm2d(dim),
            nn.ReLU()
        )
        self.value_embed = nn.Sequential(
            nn.Conv2d(dim, dim, 1, bias=False),
            nn.BatchNorm2d(dim)
        )

        factor = 4
        self.attention_embed = nn.Sequential(
            nn.Conv2d(2 * dim, 2 * dim // factor, 1, bias=False),
            nn.BatchNorm2d(2 * dim // factor),
            nn.ReLU(),
            nn.Conv2d(2 * dim // factor, 1 * 1 * dim, 1)
        )

        self.CrossConv=CrossConv2d(dim,dim,1,1)

    def forward(self, x):
        bs, c, h, w = x.shape
        k1 = self.key_embed(x)  # bs,c,h,w
        v = self.value_embed(x).view(bs, c, -1)  # bs,c,h,w

        y = torch.cat([k1, x], dim=1)  # bs,2c,h,w
        att = self.attention_embed(y)  # bs,c*k*k,h,w
        att = att.reshape(bs, c, self.kernel_size * self.kernel_size, h, w)
        att = att.mean(2, keepdim=False).view(bs, c, -1)  # bs,c,h*w
        k2 = F.softmax(att, dim=-1) * v
        k2 = k2.view(bs, c, h, w)

        out=self.CrossConv(k1+k2)

        return out

class Deconvolution(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):
        super(Deconvolution, self).__init__()
        self.deconv = nn.ConvTranspose2d(c1, c1, 4, 2, 1)
    def forward(self, x):
        return self.deconv(x)

import torch

def channel_partition(channel_weights, feature_map):
    batch_size, num_channels, height, width = feature_map.size()

    weights_tensor = torch.tensor(channel_weights)
    sorted_indices = torch.argsort(weights_tensor, descending=True)
    ranks = torch.argsort(sorted_indices)

    feature_map_1 = feature_map[:, ranks < num_channels // 4, :, :]
    feature_map_2 = feature_map[:, ranks >= num_channels // 4, :, :]

    return feature_map_1, feature_map_2


# GSConv_______________________________________________________

# class GSConv(nn.Module):
#     def __init__(self, c1, c2, k=1, s=1, g=1, act=True):
#         super().__init__()
#         c_ = c2 // 2
#         self.cv1 = Conv(c1, c_, k, s, None, g, act)
#         self.cv2 = Conv(c_, c_, 5, 1, None, c_, act)
#
#     def forward(self, x):
#         x1 = self.cv1(x)
#         x2 = torch.cat((x1, self.cv2(x1)), 1)
#         # shuffle
#         b, n, h, w = x2.data.size()
#         b_n = b * n // 2
#         y = x2.reshape(b_n, 2, h * w)
#         y = y.permute(1, 0, 2)
#         y = y.reshape(2, -1, n // 2, h, w)
#         return torch.cat((y[0], y[1]), 1)

class GSConv(nn.Module):
    # GSConv https://github.com/AlanLi1997/slim-neck-by-gsconv
    def __init__(self, c1, c2, k=1, s=1, g=1, act=True):
        super().__init__()
        c_ = c2 // 2
        self.cv1 = Conv(c1, c_, k, s, None, g, act)
        self.cv2 = Conv(c_, c_, 5, 1, None, c_, act)

    def forward(self, x):
        x1 = self.cv1(x)
        x2 = torch.cat((x1, self.cv2(x1)), 1)
        # shuffle
        # y = x2.reshape(x2.shape[0], 2, x2.shape[1] // 2, x2.shape[2], x2.shape[3])
        # y = y.permute(0, 2, 1, 3, 4)
        # return y.reshape(y.shape[0], -1, y.shape[3], y.shape[4])

        b, n, h, w = x2.data.size()
        b_n = b * n // 2
        y = x2.reshape(b_n, 2, h * w)
        y = y.permute(1, 0, 2)
        y = y.reshape(2, -1, n // 2, h, w)

        return torch.cat((y[0], y[1]), 1)

class GSBottleneck(nn.Module):
    # GS Bottleneck https://github.com/AlanLi1997/slim-neck-by-gsconv
    def __init__(self, c1, c2, k=3, s=1, e=0.5):
        super().__init__()
        c_ = int(c2*e)
        # for lighting
        self.conv_lighting = nn.Sequential(
            GSConv(c1, c_, 1, 1),
            GSConv(c_, c2, 3, 1, act=False))
        self.shortcut = Conv(c1, c2, 1, 1, act=False)

    def forward(self, x):
        return self.conv_lighting(x) + self.shortcut(x)

class VoVGSCSP(nn.Module):
    # VoVGSCSP module with GSBottleneck
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        # self.gc1 = GSConv(c_, c_, 1, 1)
        # self.gc2 = GSConv(c_, c_, 1, 1)
        # self.gsb = GSBottleneck(c_, c_, 1, 1)
        self.gsb = nn.Sequential(*(GSBottleneck(c_, c_, e=1.0) for _ in range(n)))
        self.res = Conv(c_, c_, 3, 1, act=False)
        self.cv3 = Conv(2 * c_, c2, 1)  #


    def forward(self, x):
        x1 = self.gsb(self.cv1(x))
        y = self.cv2(x)
        return self.cv3(torch.cat((y, x1), dim=1))

class BasicConv(nn.Module):

    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1, groups=1, relu=True, bn=True):
        super(BasicConv, self).__init__()
        self.out_channels = out_planes
        if bn:
            self.conv = nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding, dilation=dilation, groups=groups, bias=False)
            self.bn = nn.BatchNorm2d(out_planes, eps=1e-5, momentum=0.01, affine=True)
            self.relu = nn.ReLU(inplace=True) if relu else None
        else:
            self.conv = nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding, dilation=dilation, groups=groups, bias=True)
            self.bn = None
            self.relu = nn.ReLU(inplace=True) if relu else None

    def forward(self, x):
        x = self.conv(x)
        if self.bn is not None:
            x = self.bn(x)
        if self.relu is not None:
            x = self.relu(x)
        return x


class BasicRFB(nn.Module):

    def __init__(self, in_planes, out_planes, stride=1, scale=0.1, map_reduce=8, vision=1, groups=1):
        super(BasicRFB, self).__init__()
        self.scale = scale
        self.out_channels = out_planes
        inter_planes = in_planes // map_reduce

        self.branch0 = nn.Sequential(
            BasicConv(in_planes, inter_planes, kernel_size=1, stride=1, groups=groups, relu=False),
            BasicConv(inter_planes, 2 * inter_planes, kernel_size=(3, 3), stride=stride, padding=(1, 1), groups=groups),
            BasicConv(2 * inter_planes, 2 * inter_planes, kernel_size=3, stride=1, padding=vision, dilation=vision, relu=False, groups=groups)
        )
        self.branch1 = nn.Sequential(
            BasicConv(in_planes, inter_planes, kernel_size=1, stride=1, groups=groups, relu=False),
            BasicConv(inter_planes, 2 * inter_planes, kernel_size=(3, 3), stride=stride, padding=(1, 1), groups=groups),
            BasicConv(2 * inter_planes, 2 * inter_planes, kernel_size=3, stride=1, padding=vision + 2, dilation=vision + 2, relu=False, groups=groups)
        )
        self.branch2 = nn.Sequential(
            BasicConv(in_planes, inter_planes, kernel_size=1, stride=1, groups=groups, relu=False),
            BasicConv(inter_planes, (inter_planes // 2) * 3, kernel_size=3, stride=1, padding=1, groups=groups),
            BasicConv((inter_planes // 2) * 3, 2 * inter_planes, kernel_size=3, stride=stride, padding=1, groups=groups),
            BasicConv(2 * inter_planes, 2 * inter_planes, kernel_size=3, stride=1, padding=vision + 4, dilation=vision + 4, relu=False, groups=groups)
        )

        self.ConvLinear = BasicConv(6 * inter_planes, out_planes, kernel_size=1, stride=1, relu=False)
        self.shortcut = BasicConv(in_planes, out_planes, kernel_size=1, stride=stride, relu=False)
        self.relu = nn.ReLU(inplace=False)

    def forward(self, x):
        x0 = self.branch0(x)
        x1 = self.branch1(x)
        x2 = self.branch2(x)

        out = torch.cat((x0, x1, x2), 1)
        out = self.ConvLinear(out)
        short = self.shortcut(x)
        out = out * self.scale + short
        out = self.relu(out)

        return out


class SPPCSPC(nn.Module):
    # CSP https://github.com/WongKinYiu/CrossStagePartialNetworks
    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5, k=(5, 9, 13)):
        super(SPPCSPC, self).__init__()
        c_ = int(2 * c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c1, c_, 1, 1)
        self.cv3 = Conv(c_, c_, 3, 1)
        self.cv4 = Conv(c_, c_, 1, 1)
        self.m = nn.ModuleList([nn.MaxPool2d(kernel_size=x, stride=1, padding=x // 2) for x in k])
        self.cv5 = Conv(4 * c_, c_, 1, 1)
        self.cv6 = Conv(c_, c_, 3, 1)
        self.cv7 = Conv(2 * c_, c2, 1, 1)

    def forward(self, x):
        x1 = self.cv4(self.cv3(self.cv1(x)))
        y1 = self.cv6(self.cv5(torch.cat([x1] + [m(x1) for m in self.m], 1)))
        y2 = self.cv2(x)
        return self.cv7(torch.cat((y1, y2), dim=1))


# # without BN version
# class ASPP(nn.Module):
#     def __init__(self, in_channel=512, out_channel=256):
#         super(ASPP, self).__init__()
#         self.mean = nn.AdaptiveAvgPool2d((1, 1))  # (1,1)means ouput_dim
#         self.conv = nn.Conv2d(in_channel,out_channel, 1, 1)
#         self.atrous_block1 = nn.Conv2d(in_channel, out_channel, 1, 1)
#         self.atrous_block6 = nn.Conv2d(in_channel, out_channel, 3, 1, padding=6, dilation=6)
#         self.atrous_block12 = nn.Conv2d(in_channel, out_channel, 3, 1, padding=12, dilation=12)
#         self.atrous_block18 = nn.Conv2d(in_channel, out_channel, 3, 1, padding=18, dilation=18)
#         self.conv_1x1_output = nn.Conv2d(out_channel * 5, out_channel, 1, 1)
#
#     def forward(self, x):
#         size = x.shape[2:]
#
#         image_features = self.mean(x)
#         image_features = self.conv(image_features)
#         image_features = F.upsample(image_features, size=size, mode='bilinear')
#
#         atrous_block1 = self.atrous_block1(x)
#         atrous_block6 = self.atrous_block6(x)
#         atrous_block12 = self.atrous_block12(x)
#         atrous_block18 = self.atrous_block18(x)
#
#         net = self.conv_1x1_output(torch.cat([image_features, atrous_block1, atrous_block6,
#                                               atrous_block12, atrous_block18], dim=1))
#         return net


# without bn version
class ASPP(nn.Module):
    def __init__(self, in_channel=256,b=1):
        super(ASPP, self).__init__()
        # self.mean = nn.AdaptiveAvgPool2d((1, 1))  # (1,1)means ouput_dim
        # self.conv = nn.Conv2d(in_channel, in_channel//2, 1, 1)
        self.atrous_block1 = nn.Conv2d(in_channel, in_channel//2, 1, 1)
        # self.atrous_block11 = nn.Conv2d(in_channel//2, in_channel // 2, 1, 1)
        self.atrous_block6 = nn.Conv2d(in_channel, in_channel, 3, 1, padding=6, dilation=6,groups=in_channel)
        # self.atrous_block61 = nn.Conv2d(in_channel, in_channel // 2, 1, 1)
        self.atrous_block12 = nn.Conv2d(in_channel, in_channel, 3, 1, padding=12, dilation=12,groups=in_channel)
        # self.atrous_block121 = nn.Conv2d(in_channel, in_channel // 2, 1, 1)
        self.atrous_block18 = nn.Conv2d(in_channel, in_channel, 3, 1, padding=18, dilation=18,groups=in_channel)
        # self.atrous_block181 = nn.Conv2d(in_channel, in_channel // 2, 1, 1)
        self.conv_1x1_output = nn.Conv2d(in_channel//2 * 4, in_channel, 1, 1)

    def forward(self, x):
        # size = x.shape[2:]

        # image_features = self.mean(x)
        # image_features = self.conv(image_features)
        # image_features = F.upsample(image_features, size=size, mode='bilinear')

        atrous_block1 = self.atrous_block1(x)
        atrous_block6 = self.atrous_block1(self.atrous_block6(x))
        atrous_block12 = self.atrous_block1(self.atrous_block12(x))
        atrous_block18 = self.atrous_block1(self.atrous_block18(x))

        net = self.conv_1x1_output(torch.cat([ atrous_block1, atrous_block6,
                                              atrous_block12, atrous_block18], dim=1))
        return net

class APPF(nn.Module):
    # Spatial Pyramid Pooling - Fast (SPPF) layer for YOLOv5 by Glenn Jocher
    def __init__(self, c1, c2, k=5):  # equivalent to SPP(k=(5, 9, 13))
        super().__init__()
        c_ = c1 // 2  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.cv2 = Conv(c_ * 4, c2, 1, 1)
        # self.m = nn.MaxPool2d(kernel_size=k, stride=1, padding=k // 2)  #96
        self.m= nn.Conv2d(c_, c_, 1, 1,groups=c_)

    def forward(self, x):
        x = self.cv1(x)
        # with warnings.catch_warnings():
        #     warnings.simplefilter('ignore')  # suppress torch 1.9.0 max_pool2d() warning
        y1 = self.m(x)
        y2 = self.m(y1)
        return self.cv2(torch.cat([x, y1, y2, self.m(y2)], 1))


class VoVGSCSP2f(nn.Module):
    # VoVGSCSP module with GSBottleneck
    def __init__(self, c1, c2, n=1, shortcut=True, g=1, e=0.5):
        super().__init__()
        c_ = int(c2 * e)  # hidden channels
        self.cv1 = Conv(c1, c_, 1, 1)
        self.gsb = nn.Sequential(*(GSBottleneck(c_, c_, e=1.0) for _ in range(n)))
        self.res = Conv(c_, c_, 3, 1, act=False)
        self.cv3 = Conv(2 * c_, c2, 1)  #


    def forward(self, x):
        x1 = self.gsb(self.cv1(x))
        y = self.cv2(x)
        return self.cv3(torch.cat((y, x1), dim=1))

class Conv_CBAM1(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super(Conv_CBAM1, self).__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.Hardswish() if act else nn.Identity()
        # self.cbs = Conv(c1, c2, k, s,p)
        self.ca = ChannelAttention1(c2)
        self.sa = SpatialAttention1()

    def forward(self, x):
        x = self.act(self.bn(self.conv(x)))
        # x = self.cbs(x)
        x = self.ca(x) * x
        x = self.sa(x) * x
        return x

    def fuseforward(self, x):
        x = self.act(self.bn(self.conv(x)))
        # x = self.cbs(x)
        x = self.ca(x) * x
        x = self.sa(x) * x
        return self.act(self.conv(x))

class Conv_CBAM_xisu(nn.Module):
    # Standard convolution
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
        super(Conv_CBAM_xisu, self).__init__()
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.Hardswish() if act else nn.Identity()
        self.ca = ChannelAttention1(c2)
        self.sa = SpatialAttention1()

    def forward(self, x):
        x = self.act(self.bn(self.conv(x)))

        w1 = self.ca(x)
        x  = w1 * x
        w2 = self.sa(x)
        return w1,w2

    def fuseforward(self, x):
        x = self.act(self.bn(self.conv(x)))
        x = self.ca(x) * x
        x = self.sa(x) * x
        return self.act(self.conv(x))
class SpatialAttention1(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention1, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1

        self.conv = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv(x)
        return self.sigmoid(x)
class ChannelAttention1(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention1, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.f1 = nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False)
        self.relu = nn.ReLU()
        self.f2 = nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)
        # 写法二,亦可使用顺序容器
        # self.sharedMLP = nn.Sequential(
        # nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False), nn.ReLU(),
        # nn.Conv2d(in_planes // rotio, in_planes, 1, bias=False))

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.f2(self.relu(self.f1(self.avg_pool(x))))
        max_out = self.f2(self.relu(self.f1(self.max_pool(x))))
        out = self.sigmoid(avg_out + max_out)
        return out


###################### DSConv  ####     start   by  AI&CV  ###############################
#
# class ODConv2d_3rd(nn.Conv2d):
#
#     def __init__(self, in_channels, out_channels, kernel_size,
#                  stride=1, padding=0, dilation=1, groups=1, bias=True,
#                  K=4, r=1 / 16, save_parameters=False,
#                  padding_mode='zeros', device=None, dtype=None) -> None:
#         factory_kwargs = {'device': device, 'dtype': dtype}
#         self.K = K
#         self.r = r
#         self.save_parameters = save_parameters
#
#         super().__init__(in_channels, out_channels, kernel_size, stride,
#                          padding, dilation, groups, bias, padding_mode)
#
#         del self.weight
#         self.weight = nn.Parameter(torch.empty((
#             K,
#             out_channels,
#             in_channels // groups,
#             *self.kernel_size,
#         ), **factory_kwargs))
#
#         if bias:
#             del self.bias
#             self.bias = nn.Parameter(torch.empty(K, out_channels, **factory_kwargs))
#
#         hidden_dim = max(int(in_channels * r), 16)  #设置下限为16
#         self.gap = nn.AdaptiveAvgPool2d(1)
#         self.reduction = nn.Linear(in_channels, hidden_dim)
#         self.fc = nn.Conv2d(in_channels, hidden_dim, 1, bias = False)
#         self.bn = nn.BatchNorm2d(hidden_dim)
#         self.act = nn.ReLU(inplace=True)
#         # self.act = nn.SiLU(inplace=True)
#
#         self.fc_f = nn.Linear(hidden_dim, out_channels)
#         if not save_parameters or self.kernel_size[0] * self.kernel_size[1] > 1:
#             self.fc_s = nn.Linear(hidden_dim, self.kernel_size[0] * self.kernel_size[1])
#         if not save_parameters or in_channels // groups > 1:
#             self.fc_c = nn.Linear(hidden_dim, in_channels // groups)
#         if not save_parameters or K > 1:
#             self.fc_w = nn.Linear(hidden_dim, K)
#
#         self.reset_parameters()
#
#     def reset_parameters(self) -> None:
#         fan_out = self.kernel_size[0] * self.kernel_size[1] * self.out_channels // self.groups
#         for i in range(self.K):
#             self.weight.data[i].normal_(0, math.sqrt(2.0 / fan_out))
#         if self.bias is not None:
#             self.bias.data.zero_()
#
#     def extra_repr(self):
#         return super().extra_repr() + f', K={self.K}, r={self.r:.4}'
#
#     def get_weight_bias(self, context):
#         B, C, H, W = context.shape
#
#         if C != self.in_channels:
#             raise ValueError(
#                 f"Expected context{[B, C, H, W]} to have {self.in_channels} channels, but got {C} channels instead")
#
#         # x = self.gap(context).squeeze(-1).squeeze(-1)  # B, c_in
#         # x = self.reduction(x)  # B, hidden_dim
#         x = self.gap(context)
#         x = self.fc(x)
#         if x.size(0)>1:
#             x = self.bn(x)
#         x = x.squeeze(-1).squeeze(-1)
#         x = self.act(x)
#
#         attn_f = self.fc_f(x).sigmoid()  # B, c_out
#         attn = attn_f.view(B, 1, -1, 1, 1, 1)  # B, 1, c_out, 1, 1, 1
#         if hasattr(self, 'fc_s'):
#             attn_s = self.fc_s(x).sigmoid()  # B, k * k
#             attn = attn * attn_s.view(B, 1, 1, 1, *self.kernel_size)  # B, 1, c_out, 1, k, k
#         if hasattr(self, 'fc_c'):
#             attn_c = self.fc_c(x).sigmoid()  # B, c_in // groups
#             attn = attn * attn_c.view(B, 1, 1, -1, 1, 1)  # B, 1, c_out, c_in // groups, k, k
#         if hasattr(self, 'fc_w'):
#             attn_w = self.fc_w(x).softmax(-1)  # B, n
#             attn = attn * attn_w.view(B, -1, 1, 1, 1, 1)  # B, n, c_out, c_in // groups, k, k
#
#         weight = (attn * self.weight).sum(1)  # B, c_out, c_in // groups, k, k
#         weight = weight.view(-1, self.in_channels // self.groups, *self.kernel_size)  # B * c_out, c_in // groups, k, k
#
#         bias = None
#         if self.bias is not None:
#             if hasattr(self, 'fc_w'):
#                 bias = attn_w @ self.bias
#             else:
#                 bias = self.bias.tile(B, 1)
#             bias = bias.view(-1)  # B * c_out
#
#         return weight, bias
#
#     def forward(self, input, context=None):
#         B, C, H, W = input.shape
#
#         if C != self.in_channels:
#             raise ValueError(
#                 f"Expected input{[B, C, H, W]} to have {self.in_channels} channels, but got {C} channels instead")
#
#         weight, bias = self.get_weight_bias(context or input)
#
#         output = nn.functional.conv2d(
#             input.view(1, B * C, H, W), weight, bias,
#             self.stride, self.padding, self.dilation, B * self.groups)  # 1, B * c_out, h_out, w_out
#         output = output.view(B, self.out_channels, *output.shape[2:])
#
#         return output
#
#     def debug(self, input, context=None):
#         B, C, H, W = input.shape
#
#         if C != self.in_channels:
#             raise ValueError(
#                 f"Expected input{[B, C, H, W]} to have {self.in_channels} channels, but got {C} channels instead")
#
#         output_size = [
#             ((H, W)[i] + 2 * self.padding[i] - self.dilation[i] * (self.kernel_size[i] - 1) - 1) // self.stride[i] + 1
#             for i in range(2)
#         ]
#
#         weight, bias = self.get_weight_bias(context or input)
#
#         weight = weight.view(B, self.groups, self.out_channels // self.groups, -1)  # B, groups, c_out // groups, c_in // groups * k * k
#
#         unfold = nn.functional.unfold(
#             input, self.kernel_size, self.dilation, self.padding, self.stride)  # B, c_in * k * k, H_out * W_out
#         unfold = unfold.view(B, self.groups, -1, output_size[0] * output_size[1])  # B, groups, c_in // groups * k * k, H_out * W_out
#
#         output = weight @ unfold  # B, groups, c_out // groups, H_out * W_out
#         output = output.view(B, self.out_channels, *output_size)  # B, c_out, H_out * W_out
#
#         if bias is not None:
#             output = output + bias.view(B, self.out_channels, 1, 1)
#
#         return output
#
# class ODConv_3rd(nn.Module):
#     # Standard convolution
#     def __init__(self, c1, c2, k=1, s=1, kerNums=1, g=1, p=None, act=True):  # ch_in, ch_out, kernel, stride, padding, groups
#         super().__init__()
#         self.conv = ODConv2d_3rd(c1, c2, k, s, autopad(k, p), groups=g, K=kerNums)
#         self.bn = nn.BatchNorm2d(c2)
#         self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())
#
#     def forward(self, x):
#         return self.act(self.bn(self.conv(x)))
#
#     def forward_fuse(self, x):
#         return self.act(self.conv(x))



import torch
import torch.nn as nn

import torch.autograd

class ODConv(nn.Sequential):
    def __init__(self, in_planes, out_planes, kernel_size=3, stride=1, groups=1, norm_layer=nn.BatchNorm2d,
                 reduction=0.0625, kernel_num=1):
        padding = (kernel_size - 1) // 2
        super(ODConv, self).__init__(
            ODConv2d(in_planes, out_planes, kernel_size, stride, padding, groups=groups,
                     reduction=reduction, kernel_num=kernel_num),
            norm_layer(out_planes),
            nn.SiLU()
        )

class Attentionod(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size,
    groups=1,
    reduction=0.0625,
    kernel_num=4,
    min_channel=16):
        super(Attentionod, self).__init__()
        attention_channel = max(int(in_planes * reduction), min_channel)
        self.kernel_size = kernel_size
        self.kernel_num = kernel_num
        self.temperature = 1.0

        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Conv2d(in_planes, attention_channel, 1, bias=False)
        self.bn = nn.BatchNorm2d(attention_channel)
        self.relu = nn.ReLU(inplace=True)

        self.channel_fc = nn.Conv2d(attention_channel, in_planes, 1, bias=True)
        self.func_channel = self.get_channel_attention

        if in_planes == groups and in_planes == out_planes:  # depth-wise convolution
            self.func_filter = self.skip
        else:
            self.filter_fc = nn.Conv2d(attention_channel, out_planes, 1, bias=True)
            self.func_filter = self.get_filter_attention

        if kernel_size == 1:  # point-wise convolution
            self.func_spatial = self.skip
        else:
            self.spatial_fc = nn.Conv2d(attention_channel, kernel_size * kernel_size, 1, bias=True)
            self.func_spatial = self.get_spatial_attention

        if kernel_num == 1:
            self.func_kernel = self.skip
        else:
            self.kernel_fc = nn.Conv2d(attention_channel, kernel_num, 1, bias=True)
            self.func_kernel = self.get_kernel_attention
        self.bn_1 = nn.LayerNorm([attention_channel,1,1])
        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            if isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def update_temperature(self, temperature):
        self.temperature = temperature

    @staticmethod
    def skip(_):
        return 1.0

    def get_channel_attention(self, x):
        channel_attention = torch.sigmoid(self.channel_fc(x).view(x.size(0), -1, 1, 1) / self.temperature)
        return channel_attention

    def get_filter_attention(self, x):
        filter_attention = torch.sigmoid(self.filter_fc(x).view(x.size(0), -1, 1, 1) / self.temperature)
        return filter_attention

    def get_spatial_attention(self, x):
        spatial_attention = self.spatial_fc(x).view(x.size(0), 1, 1, 1, self.kernel_size, self.kernel_size)
        spatial_attention = torch.sigmoid(spatial_attention / self.temperature)
        return spatial_attention

    def get_kernel_attention(self, x):
        kernel_attention = self.kernel_fc(x).view(x.size(0), -1, 1, 1, 1, 1)
        kernel_attention = F.softmax(kernel_attention / self.temperature, dim=1)
        return kernel_attention

    def forward(self, x):
        x = self.avgpool(x)
        x = self.fc(x)
        x = self.bn_1(x)
        x = self.relu(x)
        return self.func_channel(x), self.func_filter(x), self.func_spatial(x), self.func_kernel(x)

class ODConv2d(nn.Module):
    def __init__(self,
    in_planes,
    out_planes,
    kernel_size=3,
    stride=1,
    padding=0,
    dilation=1,
    groups=1,
    reduction=0.0625,
    kernel_num=1):
        super(ODConv2d, self).__init__()
        self.in_planes = in_planes
        self.out_planes = out_planes
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.dilation = dilation
        self.groups = groups
        self.kernel_num = kernel_num
        self.attention = Attentionod(in_planes, out_planes, kernel_size, groups=groups,
                                   reduction=reduction, kernel_num=kernel_num)
        self.weight = nn.Parameter(torch.randn(kernel_num, out_planes, in_planes//groups, kernel_size, kernel_size),
                                   requires_grad=True)
        self._initialize_weights()

        if self.kernel_size == 1 and self.kernel_num == 1:
            self._forward_impl = self._forward_impl_pw1x
        else:
            self._forward_impl = self._forward_impl_common

    def _initialize_weights(self):
        for i in range(self.kernel_num):
            nn.init.kaiming_normal_(self.weight[i], mode='fan_out', nonlinearity='relu')

    def update_temperature(self, temperature):
        self.attention.update_temperature(temperature)

    def _forward_impl_common(self, x):

        channel_attention, filter_attention, spatial_attention, kernel_attention = self.attention(x)
        batch_size, in_planes, height, width = x.size()
        x = x * channel_attention
        x = x.reshape(1, -1, height, width)
        aggregate_weight = spatial_attention * kernel_attention * self.weight.unsqueeze(dim=0)
        aggregate_weight = torch.sum(aggregate_weight, dim=1).view(
            [-1, self.in_planes // self.groups, self.kernel_size, self.kernel_size])
        output = F.conv2d(x, weight=aggregate_weight, bias=None, stride=self.stride, padding=self.padding,
                          dilation=self.dilation, groups=self.groups * batch_size)
        output = output.view(batch_size, self.out_planes, output.size(-2), output.size(-1))
        output = output * filter_attention
        return output

    def _forward_impl_pw1x(self, x):
        channel_attention, filter_attention, spatial_attention, kernel_attention = self.attention(x)
        x = x * channel_attention
        output = F.conv2d(x, weight=self.weight.squeeze(dim=0), bias=None, stride=self.stride, padding=self.padding,
                          dilation=self.dilation, groups=self.groups)
        output = output * filter_attention
        return output

    def forward(self, x):
        return self._forward_impl(x)


class DecoupledHead(nn.Module):
    def __init__(self, ch=256, nc=80, anchors=()):
        super().__init__()
        self.nc = nc  # number of classes
        self.nl = len(anchors)  # number of detection layers
        self.na = len(anchors[0]) // 2  # number of anchors
        self.merge = Conv(ch, 256, 1, 1)
        self.cls_convs1 = Conv(256, 256, 3, 1, 1)
        self.cls_convs2 = Conv(256, 256, 3, 1, 1)
        self.reg_convs1 = Conv(256, 256, 3, 1, 1)
        self.reg_convs2 = Conv(256, 256, 3, 1, 1)
        self.cls_preds = nn.Conv2d(256, self.nc * self.na, 1)
        self.reg_preds = nn.Conv2d(256, 4 * self.na, 1)
        self.obj_preds = nn.Conv2d(256, 1 * self.na, 1)

    def forward(self, x):
        x = self.merge(x)
        x1 = self.cls_convs1(x)
        x1 = self.cls_convs2(x1)
        x1 = self.cls_preds(x1)
        x2 = self.reg_convs1(x)
        x2 = self.reg_convs2(x2)
        x21 = self.reg_preds(x2)
        x22 = self.obj_preds(x2)
        out = torch.cat([x21, x22, x1], 1)
        return out

def add_conv(in_ch, out_ch, ksize, stride, leaky=True):
    """
    Add a conv2d / batchnorm / leaky ReLU block.
    Args:
        in_ch (int): number of input channels of the convolution layer.
        out_ch (int): number of output channels of the convolution layer.
        ksize (int): kernel size of the convolution layer.
        stride (int): stride of the convolution layer.
    Returns:
        stage (Sequential) : Sequential layers composing a convolution block.
    """
    # stage = nn.Sequential()
    pad = (ksize - 1) // 2
    # stage.add_module('conv', nn.Conv2d(in_channels=in_ch,
    #                                    out_channels=out_ch, kernel_size=ksize, stride=stride,
    #                                    padding=pad, bias=False))
    # stage.add_module('batch_norm', nn.BatchNorm2d(out_ch))
    # if leaky:
    #     stage.add_module('leaky', nn.LeakyReLU(0.1))
    # else:
    #     stage.add_module('relu6', nn.ReLU6(inplace=True))  #可调
    stage = nn.Sequential(
    	Conv(in_ch,out_ch,ksize,stride,pad)
    )

    return stage


class ASFF3(nn.Module):
    def __init__(self, level, rfb=False, vis=False):
        super(ASFF3, self).__init__()
        self.level = level
        # 特征金字塔从上到下三层的channel数
        # 对应特征图大小(以640*640输入为例)分别为20*20, 40*40, 80*80
        self.dim = [512, 256, 128]
        self.inter_dim = self.dim[self.level]
        if level == 0:  # 特征图最小的一层，channel数512
            self.stride_level_1 = add_conv(256, self.inter_dim, 3, 2)
            self.stride_level_2 = add_conv(128, self.inter_dim, 3, 2)
            self.expand = add_conv(self.inter_dim, 512, 3, 1)
        elif level == 1:  # 特征图大小适中的一层，channel数256
            self.compress_level_0 = add_conv(512, self.inter_dim, 1, 1)
            self.stride_level_2 = add_conv(128, self.inter_dim, 3, 2)
            self.expand = add_conv(self.inter_dim, 256, 3, 1)
        elif level == 2:  # 特征图最大的一层，channel数128
            self.compress_level_0 = add_conv(512, self.inter_dim, 1, 1)
            self.compress_level_1 = add_conv(256, self.inter_dim, 1, 1)
            self.expand = add_conv(self.inter_dim, 128, 3, 1)

        compress_c = 8 if rfb else 16  # when adding rfb, we use half number of channels to save memory

        self.weight_level_0 = add_conv(self.inter_dim, compress_c, 1, 1)
        self.weight_level_1 = add_conv(self.inter_dim, compress_c, 1, 1)
        self.weight_level_2 = add_conv(self.inter_dim, compress_c, 1, 1)

        self.weight_levels = nn.Conv2d(compress_c * 3, 3, kernel_size=1, stride=1, padding=0)
        self.vis = vis

    def forward(self, x_level_0, x_level_1, x_level_2):
        if self.level == 0:
            level_0_resized = x_level_0
            level_1_resized = self.stride_level_1(x_level_1)

            level_2_downsampled_inter = F.max_pool2d(x_level_2, 3, stride=2, padding=1)
            level_2_resized = self.stride_level_2(level_2_downsampled_inter)

        elif self.level == 1:
            level_0_compressed = self.compress_level_0(x_level_0)
            level_0_resized = F.interpolate(level_0_compressed, scale_factor=2, mode='nearest')
            level_1_resized = x_level_1
            level_2_resized = self.stride_level_2(x_level_2)
        elif self.level == 2:
            level_0_compressed = self.compress_level_0(x_level_0)
            level_0_resized = F.interpolate(level_0_compressed, scale_factor=4, mode='nearest')
            level_1_compressed = self.compress_level_1(x_level_1)
            level_1_resized = F.interpolate(level_1_compressed, scale_factor=2, mode='nearest')
            level_2_resized = x_level_2

        level_0_weight_v = self.weight_level_0(level_0_resized)
        level_1_weight_v = self.weight_level_1(level_1_resized)
        level_2_weight_v = self.weight_level_2(level_2_resized)
        levels_weight_v = torch.cat((level_0_weight_v, level_1_weight_v, level_2_weight_v), 1)
        levels_weight = self.weight_levels(levels_weight_v)
        levels_weight = F.softmax(levels_weight, dim=1)

        fused_out_reduced = level_0_resized * levels_weight[:, 0:1, :, :] + \
                            level_1_resized * levels_weight[:, 1:2, :, :] + \
                            level_2_resized * levels_weight[:, 2:, :, :]

        out = self.expand(fused_out_reduced)

        if self.vis:
            return out, levels_weight, fused_out_reduced.sum(dim=1)
        else:
            return out


class ASFF(nn.Module):
    def __init__(self, level, rfb=False, vis=False):
        super(ASFF, self).__init__()
        self.level = level
        # 特征金字塔从上到下四层的channel数
        # 对应特征图大小(以640*640输入为例)分别为20*20, 40*40, 80*80, 160*160
        self.dim = [512, 256, 128, 64]
        self.inter_dim = self.dim[self.level]
        if level == 0:  # 特征图最小的一层，channel数512
            self.stride_level_1 = add_conv(256, self.inter_dim, 3, 2)
            self.stride_level_2 = add_conv(128, self.inter_dim, 3, 2)
            self.stride_level_3 = add_conv(64, self.inter_dim, 3, 2)
            self.expand = add_conv(self.inter_dim, 512, 3, 1)
        elif level == 1:  # 特征图大小适中的一层，channel数256
            self.compress_level_0 = add_conv(512, self.inter_dim, 1, 1)
            self.stride_level_2 = add_conv(128, self.inter_dim, 3, 2)
            self.stride_level_3 = add_conv(64, self.inter_dim, 3, 2)
            self.expand = add_conv(self.inter_dim, 256, 3, 1)
        elif level == 2:  # 特征图稍大的一层，channel数128
            self.compress_level_0 = add_conv(512, self.inter_dim, 1, 1)
            self.compress_level_1 = add_conv(256, self.inter_dim, 1, 1)
            self.stride_level_3 = add_conv(64, self.inter_dim, 3, 2)
            self.expand = add_conv(self.inter_dim, 128, 3, 1)
        elif level == 3:  # 特征图最大的一层，channel数64
            self.compress_level_0 = add_conv(512, self.inter_dim, 1, 1)
            self.compress_level_1 = add_conv(256, self.inter_dim, 1, 1)
            self.compress_level_2 = add_conv(128, self.inter_dim, 1, 1)
            self.expand = add_conv(self.inter_dim, 64, 3, 1)

        compress_c = 8 if rfb else 16  # 当添加rfb时，我们使用一半的通道数以节省内存

        self.weight_level_0 = add_conv(self.inter_dim, compress_c, 1, 1)
        self.weight_level_1 = add_conv(self.inter_dim, compress_c, 1, 1)
        self.weight_level_2 = add_conv(self.inter_dim, compress_c, 1, 1)
        self.weight_level_3 = add_conv(self.inter_dim, compress_c, 1, 1)

        self.weight_levels = nn.Conv2d(compress_c * 4, 4, kernel_size=1, stride=1, padding=0)
        self.vis = vis

    def forward(self, x_level_0, x_level_1, x_level_2, x_level_3):
        if self.level == 0:
            level_0_resized = x_level_0
            level_1_resized = self.stride_level_1(x_level_1)
            level_2_downsampled_inter = F.max_pool2d(x_level_2, 3, stride=2, padding=1)
            level_2_resized = self.stride_level_2(level_2_downsampled_inter)
            level_3_downsampled_inter = F.max_pool2d(x_level_3, 3, stride=4, padding=1)
            level_3_resized = self.stride_level_3(level_3_downsampled_inter)
        elif self.level == 1:
            level_0_compressed = self.compress_level_0(x_level_0)
            level_0_resized = F.interpolate(level_0_compressed, scale_factor=2, mode='nearest')
            level_1_resized = x_level_1
            level_2_resized = self.stride_level_2(x_level_2)
            level_3_downsampled_inter = F.max_pool2d(x_level_3, 3, stride=2, padding=1)
            level_3_resized = self.stride_level_3(level_3_downsampled_inter)
        elif self.level == 2:
            level_0_compressed = self.compress_level_0(x_level_0)
            level_0_resized = F.interpolate(level_0_compressed, scale_factor=4, mode='nearest')
            level_1_compressed = self.compress_level_1(x_level_1)
            level_1_resized = F.interpolate(level_1_compressed, scale_factor=2, mode='nearest')
            level_2_resized = x_level_2
            level_3_resized = self.stride_level_3(x_level_3)
        elif self.level == 3:
            level_0_compressed = self.compress_level_0(x_level_0)
            level_0_resized = F.interpolate(level_0_compressed, scale_factor=8, mode='nearest')
            level_1_compressed = self.compress_level_1(x_level_1)
            level_1_resized = F.interpolate(level_1_compressed, scale_factor=4, mode='nearest')
            level_2_compressed = self.compress_level_2(x_level_2)
            level_2_resized = F.interpolate(level_2_compressed, scale_factor=2, mode='nearest')
            level_3_resized = x_level_3

        level_0_weight_v = self.weight_level_0(level_0_resized)
        level_1_weight_v = self.weight_level_1(level_1_resized)
        level_2_weight_v = self.weight_level_2(level_2_resized)
        level_3_weight_v = self.weight_level_3(level_3_resized)
        levels_weight_v = torch.cat((level_0_weight_v, level_1_weight_v, level_2_weight_v, level_3_weight_v), 1)
        levels_weight = self.weight_levels(levels_weight_v)
        levels_weight = F.softmax(levels_weight, dim=1)

        fused_out_reduced = level_0_resized * levels_weight[:, 0:1, :, :] + \
                            level_1_resized * levels_weight[:, 1:2, :, :] + \
                            level_2_resized * levels_weight[:, 2:3, :, :] + \
                            level_3_resized * levels_weight[:, 3:, :, :]

        out = self.expand(fused_out_reduced)

        if self.vis:
            return out, levels_weight, fused_out_reduced.sum(dim=1)
        else:
            return out

# class ASFF(nn.Module):
#     def __init__(self, level, rfb=False, vis=False):
#         super(ASFF, self).__init__()
#         self.level = level
#         # 特征金字塔从上到下三层的channel数
#         # 对应特征图大小(以640*640输入为例)分别为20*20, 40*40, 80*80
#         self.dim = [512, 256, 128, 64]
#         self.inter_dim = self.dim[self.level]
#         if level==0: # 特征图最小的一层，channel数512
#             self.stride_level_1 = add_conv(256, self.inter_dim, 3, 2)
#             self.stride_level_2 = add_conv(128, self.inter_dim, 3, 2)
#             self.stride_level_3 = add_conv(64, self.inter_dim, 3, 2)
#             self.expand = add_conv(self.inter_dim, 512, 3, 1)
#         elif level==1: # 特征图大小适中的一层，channel数256
#             self.compress_level_0 = add_conv(512, self.inter_dim, 1, 1)
#             self.stride_level_2 = add_conv(128, self.inter_dim, 3, 2)
#             self.stride_level_3 = add_conv(64, self.inter_dim, 3, 2)
#             self.expand = add_conv(self.inter_dim, 256, 3, 1)
#         elif level==2: # 特征图最大的一层，channel数128
#             self.compress_level_0 = add_conv(512, self.inter_dim, 1, 1)
#             self.compress_level_1 = add_conv(256, self.inter_dim, 1, 1)
#             self.stride_level_3 = add_conv(64, self.inter_dim, 3, 2)
#             self.expand = add_conv(self.inter_dim, 128, 3, 1)
#         elif level==3: # 特征图最大的一层，channel数128
#             self.compress_level_0 = add_conv(512, self.inter_dim, 1, 1)
#             self.compress_level_1 = add_conv(256, self.inter_dim, 1, 1)
#             self.compress_level_2 = add_conv(128, self.inter_dim, 1, 1)
#             self.expand = add_conv(self.inter_dim, 64, 3, 1)
#
#         compress_c = 8 if rfb else 16  #when adding rfb, we use half number of channels to save memory
#
#         self.weight_level_0 = add_conv(self.inter_dim, compress_c, 1, 1)
#         self.weight_level_1 = add_conv(self.inter_dim, compress_c, 1, 1)
#         self.weight_level_2 = add_conv(self.inter_dim, compress_c, 1, 1)
#         self.weight_level_3 = add_conv(self.inter_dim, compress_c, 1, 1)
#
#         self.weight_levels = nn.Conv2d(compress_c*4, 4, kernel_size=1, stride=1, padding=0)
#         self.vis= vis
#
#
#     def forward(self, x_level_0, x_level_1, x_level_2, x_level_3):
#         if self.level==0:
#             level_0_resized = x_level_0
#
#             level_1_resized = self.stride_level_1(x_level_1)
#
#             level_2_downsampled_inter =F.max_pool2d(x_level_2, 3, stride=2, padding=1)
#             level_2_resized = self.stride_level_2(level_2_downsampled_inter)
#
#             level_3_downsampled_inter = F.max_pool2d(F.max_pool2d(x_level_3, 3, stride=2, padding=1), 3, stride=2, padding=1)
#             level_3_resized = self.stride_level_3(level_3_downsampled_inter)
#
#         elif self.level==1:
#             level_0_compressed = self.compress_level_0(x_level_0)
#             level_0_resized =F.interpolate(level_0_compressed, scale_factor=2, mode='nearest')
#
#             level_1_resized =x_level_1
#
#             level_2_resized =self.stride_level_2(x_level_2)
#
#             level_3_downsampled_inter = F.max_pool2d(x_level_3, 3, stride=2, padding=1)
#             level_3_resized = self.stride_level_3(level_3_downsampled_inter)
#
#         elif self.level==2:
#             level_0_compressed = self.compress_level_0(x_level_0)
#             level_0_resized =F.interpolate(level_0_compressed, scale_factor=4, mode='nearest')
#
#             level_1_compressed = self.compress_level_1(x_level_1)
#             level_1_resized =F.interpolate(level_1_compressed, scale_factor=2, mode='nearest')
#
#             level_2_resized =x_level_2
#
#             level_3_resized = self.stride_level_3(x_level_3)
#
#         elif self.level == 3:
#             level_0_compressed = self.compress_level_0(x_level_0)
#             level_0_resized = F.interpolate(level_0_compressed, scale_factor=8, mode='nearest')
#
#             level_1_compressed = self.compress_level_1(x_level_1)
#             level_1_resized = F.interpolate(level_1_compressed, scale_factor=4, mode='nearest')
#
#             level_2_compressed = self.compress_level_2(x_level_2)
#             level_2_resized = F.interpolate(level_2_compressed, scale_factor=2, mode='nearest')
#
#             level_3_resized = x_level_3
#
#
#
#         level_0_weight_v = self.weight_level_0(level_0_resized)
#         level_1_weight_v = self.weight_level_1(level_1_resized)
#         level_2_weight_v = self.weight_level_2(level_2_resized)
#         level_3_weight_v = self.weight_level_3(level_3_resized)
#
#         levels_weight_v = torch.cat((level_0_weight_v, level_1_weight_v, level_2_weight_v,level_3_weight_v),1)
#         levels_weight = self.weight_levels(levels_weight_v)
#         levels_weight = F.softmax(levels_weight, dim=1)
#
#         fused_out_reduced = level_0_resized * levels_weight[:,0:1,:,:]+\
#                             level_1_resized * levels_weight[:,1:2,:,:]+\
#                             level_2_resized * levels_weight[:,2:3,:,:]+ \
#                             level_2_resized * levels_weight[:, 3:, :, :]
#
#         out = self.expand(fused_out_reduced)
#
#         if self.vis:
#             return out, levels_weight, fused_out_reduced.sum(dim=1)
#         else:
#             return out

def add_dwconv(in_ch, out_ch, ksize, stride, leaky=True):
    """
    Add a conv2d / batchnorm / leaky ReLU block.
    Args:
        in_ch (int): number of input channels of the convolution layer.
        out_ch (int): number of output channels of the convolution layer.
        ksize (int): kernel size of the convolution layer.
        stride (int): stride of the convolution layer.
    Returns:
        stage (Sequential) : Sequential layers composing a convolution block.
    """
    # stage = nn.Sequential()
    pad = (ksize - 1) // 2
    # stage.add_module('conv', nn.Conv2d(in_channels=in_ch,
    #                                    out_channels=out_ch, kernel_size=ksize, stride=stride,
    #                                    padding=pad, bias=False))
    # stage.add_module('batch_norm', nn.BatchNorm2d(out_ch))
    # if leaky:
    #     stage.add_module('leaky', nn.LeakyReLU(0.1))
    # else:
    #     stage.add_module('relu6', nn.ReLU6(inplace=True))  #可调
    stage = nn.Sequential(
    	DWConv(in_ch,out_ch,ksize,stride)
    )

    return stage


# class ASFF(nn.Module):
#     def __init__(self, level, rfb=False, vis=False):
#         super(ASFF, self).__init__()
#         self.level = level
#         # 特征金字塔从上到下三层的channel数
#         # 对应特征图大小(以640*640输入为例)分别为20*20, 40*40, 80*80
#         self.dim = [512, 256, 128, 64]
#         self.inter_dim = self.dim[self.level]
#         if level==0: # 特征图最小的一层，channel数512
#             self.stride_level_1 = add_dwconv(256, self.inter_dim, 3, 2)
#             self.stride_level_2 = add_dwconv(128, self.inter_dim, 3, 2)
#             self.stride_level_3 = add_dwconv(64, self.inter_dim, 3, 2)
#             self.expand = add_conv(self.inter_dim, 512, 3, 1)
#         elif level==1: # 特征图大小适中的一层，channel数256
#             self.compress_level_0 = add_dwconv(512, self.inter_dim, 1, 1)
#             self.stride_level_2 = add_dwconv(128, self.inter_dim, 3, 2)
#             self.stride_level_3 = add_dwconv(64, self.inter_dim, 3, 2)
#             self.expand = add_conv(self.inter_dim, 256, 3, 1)
#         elif level==2: # 特征图最大的一层，channel数128
#             self.compress_level_0 = add_dwconv(512, self.inter_dim, 1, 1)
#             self.compress_level_1 = add_dwconv(256, self.inter_dim, 1, 1)
#             self.stride_level_3 = add_dwconv(64, self.inter_dim, 3, 2)
#             self.expand = add_conv(self.inter_dim, 128, 3, 1)
#         elif level==3: # 特征图最大的一层，channel数128
#             self.compress_level_0 = add_dwconv(512, self.inter_dim, 1, 1)
#             self.compress_level_1 = add_dwconv(256, self.inter_dim, 1, 1)
#             self.compress_level_2 = add_dwconv(128, self.inter_dim, 1, 1)
#             self.expand = add_conv(self.inter_dim, 64, 3, 1)
#
#         compress_c = 8 if rfb else 16  #when adding rfb, we use half number of channels to save memory
#
#         self.weight_level_0 = add_conv(self.inter_dim, compress_c, 1, 1)
#         self.weight_level_1 = add_conv(self.inter_dim, compress_c, 1, 1)
#         self.weight_level_2 = add_conv(self.inter_dim, compress_c, 1, 1)
#         self.weight_level_3 = add_conv(self.inter_dim, compress_c, 1, 1)
#
#         self.weight_levels = nn.Conv2d(compress_c*4, 4, kernel_size=1, stride=1, padding=0)
#         self.vis= vis
#
#
#     def forward(self, x_level_0, x_level_1, x_level_2, x_level_3):
#         if self.level==0:
#             level_0_resized = x_level_0
#
#             level_1_resized = self.stride_level_1(x_level_1)
#
#             level_2_downsampled_inter =F.max_pool2d(x_level_2, 3, stride=2, padding=1)
#             level_2_resized = self.stride_level_2(level_2_downsampled_inter)
#
#             level_3_downsampled_inter = F.max_pool2d(F.max_pool2d(x_level_3, 3, stride=2, padding=1), 3, stride=2, padding=1)
#             level_3_resized = self.stride_level_3(level_3_downsampled_inter)
#
#         elif self.level==1:
#             level_0_compressed = self.compress_level_0(x_level_0)
#             level_0_resized =F.interpolate(level_0_compressed, scale_factor=2, mode='nearest')
#
#             level_1_resized =x_level_1
#
#             level_2_resized =self.stride_level_2(x_level_2)
#
#             level_3_downsampled_inter = F.max_pool2d(x_level_3, 3, stride=2, padding=1)
#             level_3_resized = self.stride_level_3(level_3_downsampled_inter)
#
#         elif self.level==2:
#             level_0_compressed = self.compress_level_0(x_level_0)
#             level_0_resized =F.interpolate(level_0_compressed, scale_factor=4, mode='nearest')
#
#             level_1_compressed = self.compress_level_1(x_level_1)
#             level_1_resized =F.interpolate(level_1_compressed, scale_factor=2, mode='nearest')
#
#             level_2_resized =x_level_2
#
#             level_3_resized = self.stride_level_3(x_level_3)
#
#         elif self.level == 3:
#             level_0_compressed = self.compress_level_0(x_level_0)
#             level_0_resized = F.interpolate(level_0_compressed, scale_factor=8, mode='nearest')
#
#             level_1_compressed = self.compress_level_1(x_level_1)
#             level_1_resized = F.interpolate(level_1_compressed, scale_factor=4, mode='nearest')
#
#             level_2_compressed = self.compress_level_2(x_level_2)
#             level_2_resized = F.interpolate(level_2_compressed, scale_factor=2, mode='nearest')
#
#             level_3_resized = x_level_3
#
#
#
#         level_0_weight_v = self.weight_level_0(level_0_resized)
#         level_1_weight_v = self.weight_level_1(level_1_resized)
#         level_2_weight_v = self.weight_level_2(level_2_resized)
#         level_3_weight_v = self.weight_level_3(level_3_resized)
#
#         levels_weight_v = torch.cat((level_0_weight_v, level_1_weight_v, level_2_weight_v,level_3_weight_v),1)
#         levels_weight = self.weight_levels(levels_weight_v)
#         levels_weight = F.softmax(levels_weight, dim=1)
#
#         fused_out_reduced = level_0_resized * levels_weight[:,0:1,:,:]+\
#                             level_1_resized * levels_weight[:,1:2,:,:]+\
#                             level_2_resized * levels_weight[:,2:3,:,:]+ \
#                             level_2_resized * levels_weight[:, 3:, :, :]
#
#         out = self.expand(fused_out_reduced)
#
#         if self.vis:
#             return out, levels_weight, fused_out_reduced.sum(dim=1)
#         else:
#             return out


class IALayer(nn.Module):
    def __init__(self, channel, reduction=4):
        super(IALayer, self).__init__()
        self.interc = channel*4

        self.maxpool = nn.AdaptiveMaxPool2d(1)
        self.avgpool = nn.AdaptiveAvgPool2d(1)

        self.fcm1 = nn.Linear(self.interc, self.interc // reduction)
        self.fcm2 = nn.Linear(self.interc // reduction, self.interc)

        self.fca1 = nn.Linear(self.interc, self.interc // reduction)
        self.fca2 = nn.Linear(self.interc // reduction, self.interc)

        self.relu = nn.ReLU(inplace=True)
        self.sigmoid = nn.Sigmoid()
        self.outfc = nn.Linear(self.interc, channel)

    def forward(self, x):
        x1 = torch.cat([x[..., ::2, ::2], x[..., 1::2, ::2], x[..., ::2, 1::2], x[..., 1::2, 1::2]], 1) #进行focus增强全局池化后的通道信息含量
        b1, c1, _, _ = x1.size()
        b, c, _, _ = x.size()
        ya = self.avgpool(x1).view(b1, c1)
        ym = self.maxpool(x1).view(b1, c1)

        ya1 = self.fca1(ya)
        ym1 = self.fcm1(ym)

        y2 = ya1+ym1
        y2 = self.relu(y2)

        ya2 = self.fca2(y2)
        ym2 = self.fcm2(y2)

        y3 = ya2+ym2

        yout = self.outfc(y3)

        y = yout.view(b, c, 1, 1)

        return x * y


class WYT2(nn.Module):
    def __init__(self, c1, c2, k=1, s=1, p=None, g=1, act=True):
        super().__init__()
        c_ = c1 * 3  # 设定输出通道数的一半，用于后续操作
        cc_ = c1 * 6

        self.conv = Conv(cc_, c2, k, s, p, g, act)
        self.se = SELayer(cc_)
        self.additional_conv = Conv(c_, c_, 5, 1, None, c_, act)  # 用于处理筛选后的通道

        self.avg_pool = nn.AvgPool2d(2, 2)
        self.max_pool = nn.MaxPool2d(2, 2)
    def forward(self, x):
        # x = self.conv(x)
        # print(x.shape)
        h, w = x.shape[2] // 2, x.shape[3] // 2
        x_avg = self.avg_pool(x)
        x_max = self.max_pool(x)
        h_mid_start, h_mid_end = x.shape[2] // 4, 3 * x.shape[2] // 4
        w_mid_start, w_mid_end = x.shape[3] // 4, 3 * x.shape[3] // 4
        x_mid = x[:, :, h_mid_start:h_mid_end, w_mid_start:w_mid_end]
        # print(x_max.shape)
        # print(x_avg.shape)
        #h, w = x.shape[2] // 2, x.shape[3] // 2  # 计算宽度和高度的一半
        # 正确组织torch.cat的输入参数
        x = torch.cat([
            x[..., ::2, ::2],
            x[..., 1::2, ::2],
            x[..., ::2, 1::2],
            x[..., 1::2, 1::2],
            # x[:, :, :h, :w],
            # x[:, :, :h, w:],
            # x[:, :, h:, :w],
            # x[:, :, h:, w:],
            x_avg,
            x_max,
            #x_max,
        ], 1)
        # print(x.shape)
        x = self.se(x)  # 应用SE注意力机制
        # 获取权重并排序，选择前50%
        weights = self.se.fc[3](self.se.fc[:3](self.se.avg_pool(x).view(x.shape[0], -1)))
        _, idx = weights.sort(descending=True)
        idx_high = idx[:, :x.shape[1]//2]  # 选择权重高的前50%
        # print(idx_high.shape)
        idxs=idx_high.squeeze()
        # print(idxs)
        idxs = idxs.cpu().numpy()
        # print(idxs.shape)
        x_high = x[: , idxs, :, :]  # 筛选出权重高的前50%的通道
        # print(x_high)
        x_high = torch.cat([x[i, idx_high[i], :, :].unsqueeze(0) for i in range(x.shape[0])], 0)
        # print("Shape of x_high:", x_high.shape)
        x_low = self.additional_conv(x_high)  # 对这部分通道应用额外的卷积

        x = torch.cat([x_high, x_low], 1)  # 拼接卷积后的输出和原始高权重通道
        return self.conv(x)
